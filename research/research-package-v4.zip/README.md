# Morrow — Research Artefacts Package (v4, 23 November 2026)

**Published on Zenodo — DOI: https://doi.org/10.5281/zenodo.XXXXXXX** (replace XXXXXXX with the real record number; record: https://zenodo.org/records/XXXXXXX). Publication / Preprint, v4, Open Access, CC BY 4.0, author Pawan (Kurukshetra University). This package is the reproducibility companion to the paper below. The paper (36-page full + 8-page short) is in `../paper/` in the repository and on the Zenodo record.

This package contains everything needed to check, and to re-run, the results in
*Morrow: Natural-Language-to-SQL with a Small Local LLM on a Synthetic Sales Database —
What the Evidence Actually Supports* (working paper, revision v4, author Pawan,
Kurukshetra University). It is a **system evaluation**, not a new NL-to-SQL algorithm:
Morrow is a local Streamlit prototype that prompts one small local LLM to write SQLite;
the paper evaluates that system on an author-written benchmark. No new algorithm,
model, or benchmark method is claimed.

## What is in here

| Directory | Contents |
| --- | --- |
| `benchmarks/` | The exact 90 benchmark questions with reference SQL, v1, v2 and v3 (`.json` + `.csv`), the v2 and v3 changelogs, and `build_v3.py` (rebuilds v3 from v2, asserting the v2 questions and tie-breaks first). v1 and v2 are frozen. v3 changes only six question wordings — it states the tie-break the v2 reference SQL already used (J05 customer_id ASC, J08 product_id ASC, R07 city ASC, R11 product name ASC, R14 order_id ASC, X08 city ASC). No reference SQL changed, no case was removed. Ground truth: 90/90 executed, 498 total rows (v1: 509; the difference is X09's 20 → 9 in v2). |
| `database/` | `create_database.py` (the repository's own synthetic-database generator, seed 42), `requirements.txt` / `requirements-dev.txt`, and the independent standard-library-only rebuild (`rebuild_db.py`) and verification (`verify_db.py`) scripts. The generated database used for the model runs has SHA-256 `fe81fd8655da44f29c99648a77697e48a289522e7686d252942c9fbfb8408cd2` (20 customers, 10 products, 500 orders, 927 order items). The database file itself is not in the package — generate it with the script. |
| `scoring/` | The benchmark scoring implementation (`run_sql_benchmark.py`: `rows_equal`, `values_equal`, column matching; strict execution-result scoring — exact column names in order, ordered rows, numeric tolerance rel 1e-9 / abs 1e-6) and its tests (`test_benchmark_scoring.py`, 30 new tests). Full suite: **210 passed, 27 subtests passed** (`runs/2026-11-23-ollama-run/pytest_full_v4.log`). One real bug was found and fixed in v4: the unordered branch of `rows_equal` used greedy first-fit matching and could return False when a perfect matching existed at numeric-tolerance edges; it now uses maximum bipartite matching (Kuhn's algorithm). Effect on earlier scores: **none** — every benchmark case has `ordered=True`, so the unordered branch never executes in scoring. |
| `runs/` | All raw model-run reports, checkpoint files, logs and per-run analyses. Original 30 re-run: 27/30 = 90.0% (`07_original30_run1.json`). Expanded 90, v1 run 1 and run 2: both 77/90 = 85.56%, identical, same 13 failures (`08_`, `09_`). Expanded 90, v2 run 1: 77/90 = 85.56%, same 13 failing IDs, only X09 flipped status (`15_`). Expanded 90, v3 run 1, Qwen `qwen3.5:4b-q4_K_M`: 79/90 = 87.78% (`16_`). Expanded 90, v3 run 1, Llama `llama3.2:3b`: 40/90 = 44.44% (`17_`). Expanded 90, v3 run 2, Qwen: 79/90 = 87.78%, identical to run 1 in every respect — same 11 failures, byte-identical SQL for 90/90 questions, zero flips (`18_`). Expanded 90, v3 run 2, Llama: 37/90 = 41.11%, 3 points below run 1, 7 questions flipping (`19_`). Each 85.56% belongs to its version — report per version, never mixed. The v3 Qwen figure carries a caveat: the v3 wording is part of the prompt, so the +2 net confounds the tie-break fix with prompt-change effects on generation; a v3 run 2 was done for both models — Qwen reproduced 79/90 exactly, so run-to-run variation is not the source of the +2, but both v3 runs used the v3 wording, so only a controlled prompt A/B would separate the wording effect from the fix. The Qwen run 2 was interrupted twice by virtual-machine restarts and resumed from its checkpoint; a faulty first resume recorded 71 bogus failures while the model server was unreachable, and those lines were removed from the checkpoint before the genuine resume (see `18_..._analysis.md`). Ollama serve logs are redacted (proxy credential masked with `***`; see `redact_log.py`). |
| `validation/` | Blind reference validation, first and second. First (v1/v2): 84/90 CONFIRMED, 0 DISCREPANCY, 6 AMBIGUOUS per version (`reference_validation_v1_v2.md/.json`, blind SQL `reference_validation_blind_v1_v2.json`). Second (v3, fresh separate agent, blind file saved before comparison): **90 CONFIRMED, 0 DISCREPANCY, 0 AMBIGUOUS** (`reference_validation_v3_second_blind.json`, comparison `blind_validation_v3/compare_blind_v3_output.json`, inputs and comparison script alongside). State honestly: the second validation is a second independent derivation by a separate agent, NOT an external human reviewer — true human validation still needs a person with SQL knowledge and remains open work. |
| `reports/` | `CODE_INSPECTION.md` (line-level verification of the repository) and `EXPERIMENTS.md` (database rebuild, benchmark construction and execution), plus `experiment-outputs/` logs. |
| `code_README.md` | The Morrow repository README (source of the system description and of the author-reported 28/30 and 27/30 figures, which are REPO-REPORTED, not re-run). |
| `MANIFEST.md` | Every file in this package with size and SHA-256. |

## Headline results (for orientation only — the paper is the record)

- Original 30 re-run (Qwen): 27/30 = 90.0%.
- Expanded 90, v1 run 1 / run 2 (Qwen): 77/90 = 85.56% each, identical.
- Expanded 90, v2 run 1 (Qwen): 77/90 = 85.56%.
- Expanded 90, v3 run 1 (Qwen): 79/90 = 87.78% (basic 15/15, aggregation 15/15, filtering 14/15, joins 14/15, ranking 10/15, advanced 11/15; 8 generation failures + 3 incorrect; accuracy among executed 96.34%; ex-X03 78/89 = 87.64%). V3 sensitivities, recomputed from the run report by re-executing generated and reference SQL: tie-insensitive 79/90 = 87.78% (no rescues — the v3 failures are generation failures or wrong values, not tie-order errors); excluding the six formerly ambiguous questions 74/84 = 88.10%.
- Expanded 90, v3 run 1 (Llama `llama3.2:3b`): 40/90 = 44.44% (basic 8/15, aggregation 8/15, filtering 8/15, joins 5/15, ranking 9/15, advanced 2/15; 26 generation failures + 24 incorrect; accuracy among executed 62.5%; ex-X03 39/89 = 43.82%). V3 sensitivities: tie-insensitive 40/90 = 44.44% (no rescues); excluding the six formerly ambiguous questions 37/84 = 44.05%. Llama was ~2.2x faster per question (mean generation 18.3 s vs Qwen 40.1 s) at roughly half the accuracy. 36 cases correct on both models; llama-only correct: J04, R03, R04, R12.
- Expanded 90, v3 run 2 (Qwen): 79/90 = 87.78%, identical to run 1 — same 11 failures, same per-category accuracy, generated SQL byte-identical for 90/90 questions, zero flips. Latency higher (mean 83.14 s) on a slower post-restart machine; the run was interrupted twice by virtual-machine restarts and resumed from its checkpoint, after 71 bogus failures from a faulty first resume (model server unreachable) were removed from the checkpoint.
- Expanded 90, v3 run 2 (Llama `llama3.2:3b`): 37/90 = 41.11%, 3 points below run 1, 7 flips (B07, J13 wrong→correct; R03, R05, J08, R13, R14 correct→wrong), generated SQL differing on 20/90 questions; ranking fell 9/15 to 5/15. A single Llama run does not pin its accuracy to better than a few questions. Against Qwen run 2, 34 cases correct on both; Llama alone on J04, R04, R12; Qwen alone on 45. V3 sensitivities (run 2): tie-insensitive 37/90 = 41.11% (no rescues); excluding the six formerly ambiguous questions 36/84 = 42.86%.
- Scope, in one sentence: every accuracy above is the score on this 90-question author-written benchmark, on one synthetic database; it is not an estimate of accuracy on real business databases, other schemas, or other models.

## Reproduction instructions

1. Python 3.12.3. Create a virtual environment and install the pinned versions:
   `pip install -r database/requirements.txt -r database/requirements-dev.txt`
   (streamlit 1.66.1, pandas 3.1.0, plotly 7.1.0, openpyxl 3.1.5, pytest 9.2.0).
2. Generate the database: `python3 database/create_database.py` (seed 42). Verify its
   SHA-256 is `fe81fd86…` (full hash in `runs/2026-11-23-ollama-run/16_expanded90_v3_qwen_run1.json`).
   Or rebuild it independently with `database/rebuild_db.py` and check it with
   `database/verify_db.py` — all documented invariants and aggregate checks should match
   (0 verification failures). This wording is deliberate: the checks cover the documented
   invariants and aggregates, not a complete row-by-row identity proof.
3. Install Ollama 0.40.17, then `ollama pull qwen3.5:4b-q4_K_M` (digest `d8b0f5e9760c`)
   and/or `ollama pull llama3.2:3b` (digest `a80c4f17acd55265feec403c7aef86be0c25983ab279d83f3bcd3abbcb5b8b72`).
   Serve on `localhost:11434`. Temperature 0 in every call.
4. Run the benchmark with the repository harness (`scoring/run_sql_benchmark.py`, the
   production pipeline) pointed at `benchmarks/expanded_benchmark_v3.json`, or with the
   checkpointing runner `runs/2026-11-23-ollama-run/run_expanded_checkpoint_v3.py`, which
   saves a partial summary after every question. Save the JSON report — that report, with
   per-case SQL, columns, row counts and statuses, is what classifies the failures.
5. Run the tests: `pytest` in the repository root — expect 210 passed, 27 subtests passed.
   No test calls a live model.
6. Re-run the blind validation: use `validation/blind_validation_v3/` — write SQL from
   `blind_inputs_v3.json` (question text only) before reading any reference SQL, execute
   both, compare with `compare_blind.py`.

## Publication

Published on Zenodo — DOI: https://doi.org/10.5281/zenodo.XXXXXXX (replace XXXXXXX
with the real record number). All seven approval items are resolved: Pawan approved
publication (23 Nov 2026); licences are MIT (code) and CC BY 4.0 (paper, benchmark,
dataset); the package lives as `research/` inside the existing Morrow repository;
the Zenodo record describes v4; authorship is Pawan only, Kurukshetra University;
the v3 run-2 caveat is published as written in the paper; the Ollama serve logs were
redacted (proxy credential masked as `***`) and checked — no live credential remains
in this package.
