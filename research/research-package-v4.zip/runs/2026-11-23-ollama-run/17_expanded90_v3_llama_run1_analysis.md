# v3 run 1 — llama3.2:3b — analysis (23 Nov 2026)

**Result: 40/90 = 44.44%** (qwen3.5:4b-q4_K_M on the same v3 benchmark:
79/90 = 87.78%). Accuracy among executed: 62.5% (40/64). Excluding the
0-row case X03: 39/89 = 43.82%.

**Files:** `17_expanded90_v3_llama_run1.json` (full report, copy of the
checkpoint summary), `17_expanded90_v3_llama_run1_checkpoint.jsonl`,
`17_expanded90_v3_llama_run1.log`, `17_ollama_pull_llama3.2-3b.log`,
`17_ollama_show_llama3.2-3b.txt`.
Model: llama3.2:3b, digest `a80c4f17acd55265feec403c7aef86be0c25983ab279d83f3bcd3abbcb5b8b72`,
size 2.0 GB, 3.2B params, Q4_K_M, context 131072. Ollama 0.40.17, same DB
(SHA-256 `fe81fd86…`), same v3 case file (`cd91a4dc…`), same prompts,
same scoring, temperature 0. Mean generation latency 18.3 s (median 14.5 s,
p95 39.7 s); total generation time 1646.0 s (~27 min) — ~2.2x faster per
question than qwen (40.1 s mean), at roughly half the accuracy.

**Per-category:** basic 8/15, aggregation 8/15, filtering 8/15, joins
5/15, ranking 9/15, advanced 2/15 (qwen advanced: 11/15).

**Failing 50:** 26 generation failures + 24 incorrect answers.
- Generation failures (26): A03, A04, A12, A13, A14, F09, F10, F11, J01,
  J06, J07, J12, J14, R07, R09, R10, R11, X02, X04, X06, X07, X08, X10,
  X11, X14, X15. Dominant causes: SQL syntax errors ("near FROM",
  "near .", "near to"), misuse of aggregates/window functions
  (SUM(), AVG(), DISTINCT in window functions), unqualified/ambiguous
  columns, "malformed SQL formatting" (F09, F11 — the model returned
  non-SQL text the extractor rejected).
- Incorrect answers (24): systematic patterns, not one-offs:
  - **Status literals capitalised:** `status = 'Cancelled'`,
    `'Shipped'`, `'Processing'` (B03, B06, B07, X01, F08) — the data
    uses lowercase ('cancelled', 'shipped', 'processing'). Qwen got
    these right.
  - **Wrong date formats:** `LIKE '%/%/2026'` (F01), `LIKE '%10-2026%'`
    (B15) — dates are ISO `YYYY-MM-DD`.
  - **DISTINCT instead of COUNT(DISTINCT …):** B10, B11 returned the
    distinct values instead of the count.
  - Other semantic errors: F03, J03, R02, X05, X09, X12, A11, A15, J10,
    J11, J13, J15, R15, F12, B14.

**Overlap with qwen:** 36 cases correct on both models. Llama-only
correct: J04, R03, R04, R12 — exactly four of the cases qwen fails on
generation (ambiguous/no-such-column errors) that llama answers correctly.
Qwen-only correct: 43 cases. The models fail differently, so a simple
majority/ensemble is not available from these two runs alone.

**The six formerly-ambiguous cases under llama:** J05 correct, J08
correct, R14 correct, R07 generation failure ("no such column: city" —
the same error qwen makes on v3), R11 generation failure (syntax error
near "."), X08 generation failure (syntax error near "to"). The v3
tie-break wording does not by itself make these answerable for llama;
its failures are SQL-construction errors, not tie-order errors.

**Resource check:** pull of llama3.2:3b took ~10 min at ~2.6 MB/s through
the egress proxy (2.0 GB total); no resource failure. The model fits the
VM (loaded alone, qwen unloaded after its 5-min keep-alive expired).
No pull of a >4 GB model was attempted.
