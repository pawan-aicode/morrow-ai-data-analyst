#!/usr/bin/env python3
"""Redact credentials from a stream (stdin -> stdout), line by line.

Ollama's startup log dumps the process environment, which includes the
egress-proxy URL with an embedded credential. This filter masks any
`://user:password@` authority and any `hatch-runtime:<secret>@` token
before the text reaches a log file. Nothing else is changed.
"""
import re
import sys

PATTERNS = [
    # scheme://anything-containing-a-colon@  ->  scheme://***@
    (re.compile(r"(://)[^/\s:@]+:[^/\s@]+@"), r"\1***@"),
    # hatch-runtime:<secret>@ (in case the scheme form is split)
    (re.compile(r"(hatch-runtime:)[^@\s]+@"), r"\1***@"),
]


def redact(line):
    for pattern, replacement in PATTERNS:
        line = pattern.sub(replacement, line)
    return line


def main():
    for line in sys.stdin:
        sys.stdout.write(redact(line))
        sys.stdout.flush()


if __name__ == "__main__":
    main()
