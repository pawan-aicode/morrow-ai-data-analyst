# v3 run 1 — qwen3.5:4b-q4_K_M — analysis (23 Nov 2026)

**Result: 79/90 = 87.78%** (v2 run 1, same model: 77/90 = 85.56%). Net +2.
Accuracy among executed: 96.34% (79/82). Excluding the 0-row case X03:
78/89 = 87.64%.

**Files:** `16_expanded90_v3_qwen_run1.json` (full report, copy of the
checkpoint summary), `16_expanded90_v3_qwen_run1_checkpoint.jsonl`
(per-question, checkpointed), `16_expanded90_v3_qwen_run1.log`,
`16_ollama_list.txt`, `16_ollama_show_qwen.txt`.
Model digest `d8b0f5e9760cd1682034f292d7ef72ec46f432149be0df7574bf2d6e92e38c04`,
Ollama 0.40.17, DB SHA-256 `fe81fd86…`, case file v3 SHA-256 `cd91a4dc…`.
Mean generation latency 40.1 s, median 37.4 s, p95 65.2 s; total generation
time 3608.9 s (~60 min). Execution latency mean 0.004 s.

**Per-category:** basic 15/15, aggregation 15/15, filtering 14/15,
joins 14/15, ranking 10/15 (v2: 9/15), advanced 11/15 (v2: 10/15).

**Failing 11 (v2 run 1 failed 13):**
- Generation failures (8, all SQL the model produced but the harness
  rejected on execution): J04 (ambiguous column order_id), R03 (no such
  column: name), R04 (no such column: order_items.quantity), R07 (no such
  column: city), R10 (no such column: name), R12 (no such column:
  order_items.quantity), X09 (no such column: p.category), X11 (misuse of
  window function AVG()).
- Incorrect answers (3): F11 (counted customers in Delhi/Mumbai instead
  of orders), X06 (averaged per-order totals instead of per-customer
  totals), X12 (wrong top-two-per-category result).

**The three formerly-ambiguous cases that changed vs v2 run 1:**
- R14: FAIL (generation failure, ambiguous column) → CORRECT. The model
  now qualifies `order_items.order_id` and returns orders 1, 18, 32, 80,
  214 at 225000.0 with `ORDER BY order_value DESC, order_id ASC`.
- X08: FAIL (incorrect_answer) → CORRECT. The model's cancellation-rate
  query now matches the reference order including the city tie-break.
- R07: FAIL (incorrect_answer) → still FAIL, now as generation_failure
  ("no such column: city"). The v3 question changed the prompt, and the
  model generated a different, broken query (it referenced a `city`
  column that does not exist in the table it selected from).

**Honest caveat:** the v3 question texts are part of the prompt, so the
v2→v3 comparison confounds two things — (a) the tie-break fix making the
reference uniquely correct, and (b) the changed prompt changing what the
model generates at temperature 0. R14 and X08 flipping to correct is
consistent with the fix helping, and R07 flipping to a different failure
mode shows prompt sensitivity. The +2 net is the observed effect on this
run, not proof the tie-break wording alone caused it. A same-prompt
repeat (v3 run 2) would be needed to separate run-to-run variation from
the wording effect; it was not run in this phase.

**Incident during this run:** the VM restarted at ~07:22 UTC (uptime reset
to 0) while case 89/90 was in flight; Ollama and the runner died. The
checkpoint held 88/90, so after reinstalling Ollama 0.40.17 from the
cached tarball (binary + zstd are wiped by restarts; blobs in ~/.ollama
survive) and restarting the server, the same runner command resumed and
completed cases 89–90. No results were lost. Ollama serve logs are
redacted (proxy credential masked); see `redact_log.py`.
