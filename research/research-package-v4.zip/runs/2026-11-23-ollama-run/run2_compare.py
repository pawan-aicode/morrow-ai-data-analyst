#!/usr/bin/env python3
"""Compare a Morrow v3 run-2 report against its run-1 report, and recompute
Table 18-style sensitivities for run 2 from the run report itself.

Usage: python3 run2_compare.py <run1.json> <run2.json>
Recomputes, by re-executing generated + reference SQL read-only against
code/data/sales.db:
  - tie-insensitive accuracy (column match + row multisets, order ignored)
  - accuracy excluding X03
  - accuracy excluding the six formerly ambiguous questions
Prints headline comparison, per-category comparison, per-case flips, and
the sensitivity numbers. No writes except stdout.
"""
import json
import sqlite3
import sys
from collections import Counter

DB = "/home/hatch/workspace/research/morrow-handoff/work/code/data/sales.db"
SIX_AMBIG = {"J05", "J08", "R07", "R11", "R14", "X08"}


def load(path):
    with open(path, encoding="utf-8") as fh:
        return json.load(fh)


def exec_sql(conn, sql):
    cur = conn.execute(sql)
    cols = [d[0] for d in cur.description] if cur.description else []
    return cols, cur.fetchall()


def main():
    run1, run2 = load(sys.argv[1]), load(sys.argv[2])
    r1 = {r["id"]: r for r in run1["results"]}
    r2 = {r["id"]: r for r in run2["results"]}
    assert set(r1) == set(r2)
    assert len(r1) == len(r2) == 90, (len(r1), len(r2))

    s1, s2 = run1["summary"], run2["summary"]
    print(f"RUN 1: {run1['run_label']} completed {run1['completed_at_utc']} "
          f"correct {s1['correct_answers']}/90 = {s1['answer_accuracy_pct']}%")
    print(f"RUN 2: {run2['run_label']} completed {run2['completed_at_utc']} "
          f"correct {s2['correct_answers']}/90 = {s2['answer_accuracy_pct']}%")
    print(f"Net change run1 -> run2: {s2['correct_answers'] - s1['correct_answers']:+d}")
    print(f"Run 2 model digest {run2['model_digest']} (run 1: {run1['model_digest']})")
    print(f"Run 2 DB sha {run2['database_sha256'][:12]} case sha "
          f"{run2['case_file_sha256'][:12]} ollama {run2['ollama_version']}")
    print(f"Run 2 gen success {s2['generation_success']}/90 "
          f"({s2['generation_success_rate_pct']}%), exec success "
          f"{s2['execution_success']}/90, col matches {s2['column_schema_matches']}, "
          f"acc among executed {s2['accuracy_among_executed_pct']}%")
    print(f"Run 2 statuses: {s2['status_counts']}")
    print(f"Run 2 latency gen mean/med/p95: "
          f"{s2['generation_latency_seconds']['mean']}/"
          f"{s2['generation_latency_seconds']['median']}/"
          f"{s2['generation_latency_seconds']['p95']} s")

    print("\nPer-category (run1 -> run2):")
    for cat in sorted(s1["categories"]):
        c1, c2 = s1["categories"][cat], s2["categories"][cat]
        print(f"  {cat}: {c1['correct']}/15 ({c1['accuracy_pct']}%) -> "
              f"{c2['correct']}/15 ({c2['accuracy_pct']}%)")

    flips_up = [i for i in r1 if not r1[i]["answer_correct"] and r2[i]["answer_correct"]]
    flips_down = [i for i in r1 if r1[i]["answer_correct"] and not r2[i]["answer_correct"]]
    print(f"\nFlips wrong->correct: {flips_up or 'none'}")
    print(f"Flips correct->wrong: {flips_down or 'none'}")
    print(f"Failing run 2 ({sum(1 for r in r2.values() if not r['answer_correct'])}): "
          f"{sorted(i for i, r in r2.items() if not r['answer_correct'])}")
    print(f"Failing run 1 ({sum(1 for r in r1.values() if not r['answer_correct'])}): "
          f"{sorted(i for i, r in r1.items() if not r['answer_correct'])}")
    same_sql = sum(1 for i in r1 if r1[i].get("sql") == r2[i].get("sql"))
    print(f"Generated SQL byte-identical run1 vs run2: {same_sql}/90")
    print(f"Cases with different generated SQL: "
          f"{[i for i in r1 if r1[i].get('sql') != r2[i].get('sql')]}")

    conn = sqlite3.connect(f"file:{DB}?mode=ro", uri=True)
    tie_ok = 0
    ex_x03_ok = ex_x03_n = 0
    ex_six_ok = ex_six_n = 0
    for cid, res in r2.items():
        # Exclusion sensitivities count every case in the denominator,
        # correct = headline correctness (generation failures count as wrong).
        if cid != "X03":
            ex_x03_n += 1
            if res["answer_correct"]:
                ex_x03_ok += 1
        if cid not in SIX_AMBIG:
            ex_six_n += 1
            if res["answer_correct"]:
                ex_six_ok += 1
        if res["sql"] is None:
            continue
        try:
            acols, arows = exec_sql(conn, res["sql"])
        except Exception:
            continue
        try:
            ecols, erows = exec_sql(conn, res["reference_sql"])
        except Exception as exc:  # noqa: BLE001
            print(f"  WARNING reference exec failed {cid}: {exc}")
            continue
        if acols == ecols and Counter(map(repr, arows)) == Counter(map(repr, erows)):
            tie_ok += 1
    print("\nSensitivities run 2 (recomputed by execution):")
    print(f"  Headline (ordered scoring, as run): "
          f"{s2['correct_answers']}/90 = {s2['answer_accuracy_pct']}%")
    print(f"  Tie-insensitive: {tie_ok}/90 = {tie_ok / 90 * 100:.2f}% "
          f"({'no rescues' if tie_ok == s2['correct_answers'] else str(tie_ok - s2['correct_answers']) + ' vs headline'})")
    print(f"  Excluding X03: {ex_x03_ok}/{ex_x03_n} = {ex_x03_ok / ex_x03_n * 100:.2f}%")
    print(f"  Excluding six formerly ambiguous: {ex_six_ok}/{ex_six_n} = "
          f"{ex_six_ok / ex_six_n * 100:.2f}%")
    conn.close()


if __name__ == "__main__":
    main()
