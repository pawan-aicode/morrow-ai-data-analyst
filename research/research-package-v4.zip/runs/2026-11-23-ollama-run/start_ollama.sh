#!/bin/bash
# Start Ollama serve detached, stdout+stderr piped through the redactor.
# Log file therefore never contains the egress-proxy credential.
cd /home/hatch/workspace/research/morrow-handoff/work/experiments/2026-11-23-ollama-run
nohup bash -c '/usr/local/bin/ollama serve 2>&1 | python3 redact_log.py > 02_ollama_serve.log' >/dev/null 2>&1 &
echo "started pid $!"
