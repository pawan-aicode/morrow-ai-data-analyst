#!/bin/bash
# Wait for the v3 qwen run to finish (90 checkpoint lines) or the runner to exit.
CKPT=16_expanded90_v3_qwen_run1_checkpoint.jsonl
LOG=16_expanded90_v3_qwen_run1.log
for i in $(seq 1 100); do
  n=$(wc -l < "$CKPT" 2>/dev/null || echo 0)
  if [ "$n" -ge 90 ]; then echo "CHECKPOINT_COMPLETE n=$n"; break; fi
  if ! pgrep -f "run_expanded_checkpoint_v3.py.*expanded90_v3_run1" >/dev/null; then
    echo "RUNNER_EXITED n=$n"; break
  fi
  sleep 60
done
echo "--- final checkpoint lines: $(wc -l < $CKPT 2>/dev/null)"
tail -25 "$LOG"
