# v3 run 2 — qwen3.5:4b-q4_K_M — analysis (23 Nov 2026)

**Result: 79/90 = 87.78%** — identical to v3 run 1 (79/90 = 87.78%).
Net change 0. Zero per-case flips: no question flipped either way.
Measured run-to-run variability in accuracy on this benchmark is zero for
Qwen on v3, under these test conditions. Accuracy among executed: 96.34%
(79/82). Excluding the 0-row case X03: 78/89 = 87.64%.

**Files:** `18_expanded90_v3_qwen_run2.json` (full report, copy of the
checkpoint summary), `18_expanded90_v3_qwen_run2_checkpoint.jsonl`
(per-question, checkpointed), `18_expanded90_v3_qwen_run2.log`,
`18_expanded90_v3_qwen_run2_compare.txt` (run-1 vs run-2 comparison,
including recomputed sensitivities), `run2_compare.py` (the comparison
script). Model digest `d8b0f5e9760cd1682034f292d7ef72ec46f432149be0df7574bf2d6e92e38c04`,
Ollama 0.40.17, DB SHA-256 `fe81fd86…`, case file v3 SHA-256 `cd91a4dc…`.
Mean generation latency 83.14 s, median 84.80 s, p95 152.62 s; total
generation time 7482.2 s (~125 min). Execution latency mean 0.004 s.
Latency is much higher than run 1 (40.10/37.42/65.18 s) because the run
shared a slower post-restart virtual machine; latencies are not directly
comparable across runs and are not a model effect.

**Per-category:** basic 15/15, aggregation 15/15, filtering 14/15,
joins 14/15, ranking 10/15 (66.67%), advanced 11/15 (73.33%) — identical
to run 1 in every category.

**Failing 11 — identical to run 1, same cases, same statuses, same
errors:** generation failures (8): J04 (ambiguous column order_id),
R03 (no such column: name), R04 (no such column:
order_items.quantity), R07 (no such column: city), R10 (no such
column: name), R12 (no such column: order_items.quantity), X09 (no
such column: p.category), X11 (misuse of window function AVG()).
Incorrect answers (3): F11, X06, X12 — unchanged from every Qwen run.
Generated SQL is byte-identical to run 1 for 90/90 questions.

**Sensitivities, recomputed from this run's report by re-executing
generated and reference SQL and comparing row multisets
(`run2_compare.py`):** tie-insensitive 79/90 = 87.78% (no rescues);
excluding X03 78/89 = 87.64%; excluding the six formerly ambiguous
questions 74/84 = 88.10%. Identical to run 1's sensitivities.

**What this does to the +2 caveat:** the v3 Qwen +2 net over v2
(79/90 vs 77/90) is reproduced exactly on a same-prompt repeat — the
same 79/90, the same 11 failures, byte-identical SQL. Run-to-run
variation is therefore not the source of the +2. What the repeat does
*not* separate is the wording effect from the tie-break fix: both v3
runs used the v3 question wording, so the +2 is still confounded
between (a) the tie-break fix making the reference uniquely correct
and (b) the changed prompt changing what the model generates. Only a
controlled prompt A/B (same questions, v2 wording vs v3 wording, same
model and database) would separate those two. The caveat in the paper
is updated to say exactly this; B13 (no v3 run 2) is resolved, B3
(baseline prompt unknown, no controlled comparison) still stands.

**Incidents during this run (recorded in the log):** the virtual
machine restarted twice. First restart at ~09:18 UTC killed the
runner at case 20/90 (19 checkpointed) and wiped the Ollama binary;
the first reinstall extracted `bin/ollama` only, missing
`lib/ollama/llama-server`, so a resumed runner recorded 71 bogus
generation failures ("Could not reach Ollama", ~0.2 s each) for cases
20–90 before the fault was noticed. Those 71 lines were removed from
the checkpoint (verified: first 19 lines genuine, all 71 bogus lines
carried the connection error), the bogus summary was deleted, the full
tarball was re-extracted to `/usr/local`, the server was restarted,
and a live `/api/chat` test passed before the runner was resumed from
the 19 genuine cases. Second restart at ~11:19 UTC killed the runner
at case 87/90 (X12 in flight; 86 checkpointed, 0 bogus lines); same
recovery, resumed from 86 genuine cases, completed 11:24:16 UTC.
No genuine result was lost; no case was run twice. Ollama serve logs
are redacted (proxy credential masked); see `redact_log.py`.
