# v3 run 2 — llama3.2:3b — analysis (23 Nov 2026)

**Result: 37/90 = 41.11%** — down 3 from v3 run 1 (40/90 = 44.44%).
Net change −3. Unlike Qwen, Llama does not repeat exactly at temperature
0: 7 questions flipped (2 wrong→correct, 5 correct→wrong), and the
generated SQL differs from run 1 on 20/90 questions. Accuracy among
executed: 62.71% (37/59). Excluding the 0-row case X03: 36/89 = 40.45%.

**Files:** `19_expanded90_v3_llama_run2.json` (full report, copy of the
checkpoint summary), `19_expanded90_v3_llama_run2_checkpoint.jsonl`
(per-question, checkpointed), `19_expanded90_v3_llama_run2.log`,
`19_expanded90_v3_llama_run2_compare.txt` (run-1 vs run-2 comparison,
including recomputed sensitivities), `run2_compare.py` (the comparison
script), `19_ollama_list.txt`, `19_ollama_show_llama.txt`. Model digest
`a80c4f17acd55265feec403c7aef86be0c25983ab279d83f3bcd3abbcb5b8b72`,
Ollama 0.40.17, DB SHA-256 `fe81fd86…`, case file v3 SHA-256
`cd91a4dc…`. Mean generation latency 16.66 s, median 13.85 s, p95
36.79 s; total generation time 1499.0 s (~25 min). Execution latency
mean 0.005 s. This run was uninterrupted; it completed at 11:52:16 UTC.

**Per-category:** basic 9/15 (60.0%, run 1: 8/15), aggregation 8/15,
filtering 8/15, joins 5/15, ranking 5/15 (33.33%, run 1: 9/15),
advanced 2/15. The net −3 is concentrated in ranking (−4), partly
offset by basic (+1).

**Flips vs run 1:** wrong→correct: B07, J13. Correct→wrong: R03, R05,
J08, R13, R14. The other 13 questions whose generated SQL changed kept
their run-1 outcome. Of the six formerly ambiguous questions, only J05
is correct in run 2 (run 1: J05, J08 and R14 correct); J08 and R14
flipped to generation failures, R07, R11 and X08 fail as in run 1.
The v3 tie-break wording does not by itself make these answerable for
Llama — and, on this repeat, two of the three it had right went wrong
on SQL-construction errors, not tie-order errors.

**Failing 53:** generation failures 31 (run 1: 26), incorrect answers
22 (run 1: 24). The failure modes are the same kinds as run 1 —
capitalised status literals, wrong date formats, `DISTINCT` instead of
`COUNT(DISTINCT …)`, SQL syntax errors, aggregate and window-function
misuse, unqualified or ambiguous columns, and malformed non-SQL output
— with syntax errors the largest single group (11). Against Qwen run
2, 34 cases are correct on both models; Llama alone is correct on J04,
R04 and R12; Qwen alone is correct on 45.

**Sensitivities, recomputed from this run's report by re-executing
generated and reference SQL and comparing row multisets
(`run2_compare.py`):** tie-insensitive 37/90 = 41.11% (no rescues);
excluding X03 36/89 = 40.45%; excluding the six formerly ambiguous
questions 36/84 = 42.86%.

**What this means:** the Llama 44.44% figure from run 1 was a
single-run observation, and its repeat is 3 points lower with 7 flips.
A single Llama run does not pin the model's accuracy on this benchmark
to better than a few questions; the honest statement is that Llama
scored 40/90 and 37/90 on two runs of the same 90 cases (44.44% and
41.11%), while Qwen scored 79/90 on both of its v3 runs. The
cross-model gap is large on either run (about 40 points), but the
per-category comparison is not stable for Llama — ranking moved 9/15
to 5/15 between repeats. No incident occurred during this run.
