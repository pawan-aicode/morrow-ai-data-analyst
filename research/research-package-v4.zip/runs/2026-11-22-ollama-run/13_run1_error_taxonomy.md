# Expanded-90 run 1 — error taxonomy (EXECUTED HERE, 2026-11-22)

Source: expanded90_run1_checkpoint.summary.json (90/90, model qwen3.5:4b-q4_K_M,
DB sha fe81fd86..., case file sha 8ed0fdae...).
Overall: 77/90 = 85.56% correct. Generation success 83/90 (92.22%).
Per-category: basic 15/15, aggregation 15/15, filtering 14/15, joins 14/15,
ranking 9/15 (60.0%), advanced 10/15 (66.67%).
Latency: generation mean 36.97s, median 36.35s, p95 57.71s; execution mean 0.004s.

## Failures (13)

### A. Column-reference errors — generation_failure, 6 cases
Model produced SQL referencing a column that is ambiguous or does not exist;
the harness's EXPLAIN validation rejected it, and the invalid SQL text is
discarded by the harness (sql=None), so only the SQLite error is recorded.
- J04: ambiguous column name: order_id
- R03: no such column: name
- R04: no such column: order_items.quantity
- R10: no such column: name
- R12: no such column: order_items.quantity
- R14: ambiguous column name: order_id
Pattern: all 6 are in multi-table queries (joins/ranking) where the model
omitted a table qualifier or guessed a column name (`name` instead of
`c.name` / customer name column; `order_items.quantity` where the query's
grain made that reference invalid).

### B. Window-function misuse — generation_failure, 1 case
- X11: "misuse of window function AVG()" — AVG() used as a window function
  in a context SQLite rejects.

### C. Missing filter / dedup — 2 cases
- X12: RANK() computed correctly, but the model forgot `WHERE rank <= 2`;
  returned all 10 products instead of the top 2 per category (6 rows).
- X09: logic correct (COUNT(DISTINCT category) = 3 per customer) but no
  DISTINCT on the outer select, so one row per order-item was returned and
  the 200-row production cap rejected it -> execution_failure. The reference
  answer is 20 customers; the generated query would have returned the right
  customers with duplicates removed.

### D. Wrong grain / entity — 2 cases
- F11: counted customers (4) instead of orders (102) for Delhi/Mumbai.
- X06: average computed over per-ORDER totals instead of per-CUSTOMER
  totals, so the threshold was far too low and all 20 customers were
  returned instead of the 10 above the per-customer average.

### E. Tie-ordering — incorrect_answer, 2 cases (benchmark underspecification)
- R07: Bhopal and Goa both have 31 orders; reference orders ties by city ASC,
  generated SQL has no tiebreak and SQLite returned Goa first. Values identical.
- X08: same pattern — tied cancellation rates (20.0% Chennai/Noida;
  18.52% Chandigarh/Gurugram/Mumbai) in different order; values identical.
The questions do not specify a tiebreak, and scoring is order-sensitive, so
a semantically correct answer is penalised. These two are arguably benchmark
faults, not model faults (reviewer's Problem 3). If they were scored
order-insensitively for ties, run-1 accuracy would be 79/90 = 87.78%.

## Summary counts
- Column-reference errors: 6 | window misuse: 1 | missing filter/dedup: 2 |
  wrong grain/entity: 2 | tie-ordering: 2. Total 13.
- 0 safety_rejections, 0 reference_errors in run 1.
- Ranking is the weakest category (9/15); 5 of its 6 failures are in
  groups A/E (column refs + ties). Advanced is next (10/15).
