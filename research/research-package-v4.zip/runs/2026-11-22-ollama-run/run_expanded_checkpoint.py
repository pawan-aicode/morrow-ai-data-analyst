#!/usr/bin/env python3
"""Checkpointing runner for the Morrow expanded-90 benchmark.

Uses the repo's OWN production code path (app.agent.generate_sql /
validate_sql / execute_sql / get_schema) and the repo harness's OWN
scoring functions (scripts/run_sql_benchmark.py: fetch_reference,
rows_equal, build_summary). The only difference from
scripts/run_sql_benchmark.py is checkpointing: after EVERY question the
result is appended to a JSONL file and a partial summary JSON is rewritten,
so a VM restart loses at most the one in-flight question. This was added
because the runtime cell restarted at 2026-11-22 19:01 UTC mid-run and
killed the repo harness's in-memory run (its JSON report is only written
at the end) — 36 questions of progress were lost except for log lines.

Usage (from the repo root, with the benchmark venv):
  python -u run_expanded_checkpoint.py \
    --cases ~/workspace/research/morrow-handoff/work/research/benchmarks/expanded_benchmark_v1.json \
    --checkpoint <dir>/expanded90_run1_checkpoint.jsonl

It resumes automatically: case IDs already present in the checkpoint file
are skipped. The final summary is identical in shape to the repo harness
report, plus checkpoint metadata.
"""
import argparse
import hashlib
import json
import sys
import time
from datetime import datetime, timezone
from pathlib import Path

CODE_ROOT = Path("/home/hatch/workspace/research/morrow-handoff/work/code")
if str(CODE_ROOT) not in sys.path:
    sys.path.insert(0, str(CODE_ROOT))
if str(CODE_ROOT / "scripts") not in sys.path:
    sys.path.insert(0, str(CODE_ROOT / "scripts"))

from app.agent import (  # noqa: E402
    DB_PATH,
    MODEL,
    AgentError,
    execute_sql,
    generate_sql,
    get_schema,
    validate_sql,
)
from run_sql_benchmark import build_summary, fetch_reference, rows_equal  # noqa: E402


def sha256_file(path):
    digest = hashlib.sha256()
    with open(path, "rb") as fh:
        for chunk in iter(lambda: fh.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def evaluate_case(case, schema):
    result = {
        "id": case["id"],
        "category": case["category"],
        "name": case["name"],
        "question": case["question"],
        "status": "not_started",
        "generation_seconds": None,
        "execution_seconds": None,
        "sql": None,
        "expected_columns": None,
        "actual_columns": None,
        "expected_row_count": None,
        "actual_row_count": None,
        "column_match": False,
        "rows_match": False,
        "answer_correct": False,
        "error": None,
    }
    try:
        expected_columns, expected_rows = fetch_reference(case["reference_sql"])
        result["expected_columns"] = expected_columns
        result["expected_row_count"] = len(expected_rows)
    except Exception as exc:  # noqa: BLE001
        result["status"] = "reference_error"
        result["error"] = f"{type(exc).__name__}: {exc}"
        return result

    generation_start = time.perf_counter()
    try:
        sql = generate_sql(case["question"], schema)
        result["generation_seconds"] = round(time.perf_counter() - generation_start, 3)
        result["sql"] = sql
    except Exception as exc:  # noqa: BLE001
        result["generation_seconds"] = round(time.perf_counter() - generation_start, 3)
        result["status"] = "generation_failure"
        result["error"] = f"{type(exc).__name__}: {exc}"
        return result

    try:
        validate_sql(sql)
    except AgentError as exc:
        result["status"] = "safety_rejection"
        result["error"] = str(exc)
        return result

    execution_start = time.perf_counter()
    try:
        actual_columns, actual_rows = execute_sql(sql)
        result["execution_seconds"] = round(time.perf_counter() - execution_start, 3)
    except Exception as exc:  # noqa: BLE001
        result["execution_seconds"] = round(time.perf_counter() - execution_start, 3)
        result["status"] = "execution_failure"
        result["error"] = f"{type(exc).__name__}: {exc}"
        return result

    result["actual_columns"] = actual_columns
    result["actual_row_count"] = len(actual_rows)
    result["column_match"] = actual_columns == expected_columns
    result["rows_match"] = rows_equal(expected_rows, actual_rows, case["ordered"])
    result["answer_correct"] = result["column_match"] and result["rows_match"]
    result["status"] = "correct" if result["answer_correct"] else "incorrect_answer"
    return result


def main():
    parser = argparse.ArgumentParser(description="Checkpointing Morrow benchmark runner.")
    parser.add_argument("--cases", required=True)
    parser.add_argument("--checkpoint", required=True)
    parser.add_argument("--run-label", default="expanded90")
    args = parser.parse_args()

    cases_path = Path(args.cases)
    checkpoint_path = Path(args.checkpoint)
    checkpoint_path.parent.mkdir(parents=True, exist_ok=True)
    summary_path = checkpoint_path.with_suffix(".summary.json")

    cases = json.loads(cases_path.read_text(encoding="utf-8"))
    done = {}
    if checkpoint_path.is_file():
        for line in checkpoint_path.read_text(encoding="utf-8").splitlines():
            if line.strip():
                item = json.loads(line)
                done[item["id"]] = item
    print(f"Cases: {len(cases)}; already checkpointed: {len(done)}", flush=True)
    print(f"Model: {MODEL}; DB: {DB_PATH} sha256={sha256_file(DB_PATH)}", flush=True)
    print(f"Case file: {cases_path} sha256={sha256_file(cases_path)}", flush=True)

    if not DB_PATH.is_file():
        raise FileNotFoundError(f"Database not found: {DB_PATH}")

    schema = get_schema()
    results = [done[c["id"]] for c in cases if c["id"] in done]

    with checkpoint_path.open("a", encoding="utf-8") as fh:
        for index, case in enumerate(cases, 1):
            if case["id"] in done:
                print(f"[{index:02d}/{len(cases):02d}] {case['id']} SKIP (checkpointed)", flush=True)
                continue
            print(f"[{index:02d}/{len(cases):02d}] {case['id']} | {case['category']} | {case['name']}", flush=True)
            result = evaluate_case(case, schema)
            results.append(result)
            fh.write(json.dumps(result, ensure_ascii=False) + "\n")
            fh.flush()
            summary = build_summary(results, cases[: len(results)] if len(results) < len(cases) else cases)
            summary_path.write_text(
                json.dumps(
                    {
                        "run_label": args.run_label,
                        "updated_at_utc": datetime.now(timezone.utc).isoformat(),
                        "model": MODEL,
                        "database_path": str(DB_PATH),
                        "database_sha256": sha256_file(DB_PATH),
                        "case_file": str(cases_path),
                        "case_file_sha256": sha256_file(cases_path),
                        "cases_completed": len(results),
                        "cases_total": len(cases),
                        "summary_partial": summary,
                        "results": results,
                    },
                    indent=2,
                    ensure_ascii=False,
                ),
                encoding="utf-8",
            )
            print(
                f"  {result['status'].upper()} | generation={result['generation_seconds']}s "
                f"| correct-so-far={sum(r['answer_correct'] for r in results)}/{len(results)}",
                flush=True,
            )
            if result["error"]:
                print(f"  Error: {result['error']}", flush=True)

    final = build_summary(results, cases)
    print("FINAL SUMMARY", flush=True)
    print(json.dumps(final, indent=2), flush=True)
    summary_path.write_text(
        json.dumps(
            {
                "run_label": args.run_label,
                "completed_at_utc": datetime.now(timezone.utc).isoformat(),
                "model": MODEL,
                "database_path": str(DB_PATH),
                "database_sha256": sha256_file(DB_PATH),
                "case_file": str(cases_path),
                "case_file_sha256": sha256_file(cases_path),
                "cases_completed": len(results),
                "cases_total": len(cases),
                "summary": final,
                "results": results,
            },
            indent=2,
            ensure_ascii=False,
        ),
        encoding="utf-8",
    )
    print(f"Checkpoint: {checkpoint_path}", flush=True)
    print(f"Summary: {summary_path}", flush=True)


if __name__ == "__main__":
    main()
