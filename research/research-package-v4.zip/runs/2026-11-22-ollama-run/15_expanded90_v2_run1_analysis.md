# Morrow expanded-90 benchmark v2 — run 1 analysis

Run: `expanded90_v2_run1`, 23 Nov 2026, 03:38–04:39 UTC (≈61 min wall time).
Harness: repo production path (`app.agent.generate_sql` / `validate_sql` /
`execute_sql`) + repo scoring (`run_sql_benchmark.build_summary`), checkpointed
per question. Same model, temperature 0, same prompt as the v1 runs.

## Fingerprints

- Model: `qwen3.5:4b-q4_K_M`, digest
  `d8b0f5e9760cd1682034f292d7ef72ec46f432149be0df7574bf2d6e92e38c04`
  (Ollama 0.40.17, CPU). `ollama list` / `ollama show` saved as
  `15_ollama_list.txt` / `15_ollama_show.txt`.
- DB: `code/data/sales.db`,
  SHA-256 `fe81fd8655da44f29c99648a77697e48a289522e7686d252942c9fbfb8408cd2`
  (identical to the v1 run DB).
- Case file: `research/benchmarks/expanded_benchmark_v2.json`,
  SHA-256 `96afdc729a1f7097c2bfb59046cc21660cfa38d52f19f25fb939f20b5dd9140e`.
- Pre-run check: all 90 v2 reference SQL execute, 90/90, 498 total rows.

## Headline

- **77/90 correct = 85.56%** — identical headline to v1 run 1 and v1 run 2
  (both 77/90 = 85.56%).
- **Excluding X03: 76/89 = 85.39%.** X03 is correct but degenerate
  (0 expected rows vs 0 returned rows — "products never ordered" when every
  product appears in `order_items`).
- Accuracy among executed: 77/82 = 93.90%.
- Generation success: 82/90 (91.11%). Execution success: 82/90 (91.11%).
- Safety rejections: 0. Execution failures: 0.
- Generation latency: mean 40.61 s, median 38.58 s, p95 62.17 s.
  Execution latency: mean 0.005 s, median 0.001 s, p95 0.017 s.

## Per-category (each /15)

| Category    | Correct | Accuracy |
| ----------- | ------- | -------- |
| basic       | 15      | 100.00%  |
| aggregation | 15      | 100.00%  |
| filtering   | 14      | 93.33%   |
| joins       | 14      | 93.33%   |
| ranking     | 9       | 60.00%   |
| advanced    | 10      | 66.67%   |

Per-category figures are identical to v1 run 1 and run 2.

## Failing questions (13)

### Generation failures (8) — invalid SQL, caught by EXPLAIN in `_extract_sql_response`

| ID  | Error |
| --- | ----- |
| J04 | ambiguous column name: `order_id` |
| R03 | no such column: `name` |
| R04 | no such column: `order_items.quantity` |
| R10 | no such column: `name` |
| R12 | no such column: `order_items.quantity` |
| R14 | ambiguous column name: `order_id` |
| X09 | no such column: `p.category` |
| X11 | misuse of window function `AVG()` |

### Incorrect answers (5) — valid SQL, wrong rows

| ID  | What went wrong |
| --- | --------------- |
| F11 | Counted **customers** in Delhi/Mumbai instead of **orders** (wrong grain). |
| R07 | `ORDER BY order_count DESC` with no `city ASC` tie-breaker before `LIMIT 5` (tie-ordering). |
| X06 | Average computed over **per-order** totals (unfiltered subquery) instead of per-customer completed spending (wrong grain). |
| X08 | Cancellation-rate values correct; `ORDER BY` lacks the `city ASC` tie-breaker, so tied cities come out in a different order (tie-ordering). |
| X12 | `RANK()` computed correctly but the `WHERE rank_in_category <= 2` filter is missing — returns 10 rows instead of 6 (missing filter). |

## Error taxonomy (13 failures)

| Taxonomy         | Count | IDs |
| ---------------- | ----- | --- |
| column-reference | 7     | J04, R03, R04, R10, R12, R14, X09 |
| window-function  | 1     | X11 |
| missing filter   | 1     | X12 |
| wrong grain      | 2     | F11, X06 |
| tie-ordering     | 2     | R07, X08 |
| other            | 0     | — |

## X03 and X09, separately

- **X03** (products never ordered, `report_separately: true`): CORRECT —
  generated SQL uses `NOT IN (SELECT DISTINCT product_id FROM order_items)`,
  returns 0 rows, matching the 0-row reference. Degenerate pass; excluded
  from the 76/89 figure above.
- **X09** (v2 replacement: all three categories in **completed orders placed
  in 2026**, 9 expected rows): GENERATION_FAILURE — `no such column:
  p.category`. The model referenced `p.category` without a usable `products
  AS p` join in scope. In v1 the same case (20-row version) was an
  execution_failure (generated SQL returned >200 rows, tripping the
  production row cap). Either way X09 fails in all three runs so far.

## v1 vs v2 comparison

- Failing ID set is **identical** across v1 run 1, v1 run 2 and v2 run 1:
  F11, J04, R03, R04, R07, R10, R12, R14, X06, X08, X09, X11, X12.
- Only status flip vs v1: X09 `execution_failure` → `generation_failure`.
- Generated SQL is **byte-identical to v1 run 1 for 89/90** questions
  (and v1 run 2 was byte-identical to v1 run 1, so v2 run 1 matches both
  v1 runs on every unchanged case). The sole difference is X09, which
  produced no SQL in v2 (generation failed before SQL was returned).
- The v2 change therefore did not move the headline at all: the new X09
  still fails, and nothing else changed.

## Incidents

- Ollama was **not running** at task start and the `ollama` binary was gone
  from `/usr/local/bin` (VM restart wiped the ephemeral install; model blobs
  in `~/.ollama` survived). Reinstalled from the cached tarball
  `~/ollama-linux-amd64.tar.zst` (SHA-256 verified:
  `1df9d6228bac5a22e420b242708c0d10e5b886db97bab99d446a41760f4e79af`),
  which required installing `zstd` first (`apt-get update && apt-get
  install -y zstd`). Server restarted with the same proxy env as the
  11/14 serve logs, but its log (`15_ollama_serve.log`) is piped through a
  redactor so the egress proxy credential is **not** written to disk
  (unlike the 02/11/14 logs).
- No interruption during the run: 90/90 completed in a single pass, no
  checkpoint resume needed. Smoke test before the run (B01-style question)
  returned correct SQL in 62.8 s (including model load).
- No second run was done: one full run was required; a run 2 is a trivial
  re-run of the same command (checkpoint file would need a new name) and
  v1 already showed zero flips across two runs. The X09 outcome is the
  only case a run 2 could inform.

## Files (all under `work/experiments/2026-11-22-ollama-run/`)

- `15_expanded90_v2_run1.json` — full per-question report (final).
- `15_expanded90_v2_run1.log` — run log.
- `15_expanded90_v2_run1_checkpoint.jsonl` — per-question checkpoint (90 lines).
- `15_expanded90_v2_run1_checkpoint.summary.json` — identical to the final JSON.
- `run_expanded_checkpoint_v2.py` — v2 checkpoint runner (adapted from the
  v1 runner; per-question records add `reference_sql`, exact `prompt`,
  `model_digest`, `ollama_version`, `database_sha256`, `case_file_sha256`).
- `15_ollama_serve.log` (credential-redacted), `15_ollama_list.txt`,
  `15_ollama_show.txt`.
- v1 files 07/08/09 untouched; v1 case file untouched; repo `git status` clean.

## What this does NOT establish

Single synthetic database, single model, temperature 0. The 85.56% is a
v2-benchmark figure, not directly comparable to v1 as a headline (one case
changed) — report side by side with case counts, and with/without X03.
