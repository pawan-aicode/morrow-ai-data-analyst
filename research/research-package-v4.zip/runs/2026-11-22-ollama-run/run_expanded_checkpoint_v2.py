#!/usr/bin/env python3
"""Checkpointing runner for the Morrow expanded-90 benchmark v2.

Adapted from run_expanded_checkpoint.py (used for the v1 runs 08/09).
Identical harness: the repo's OWN production code path
(app.agent.generate_sql / validate_sql / execute_sql / get_schema) and the
repo harness's OWN scoring functions
(scripts/run_sql_benchmark.py: fetch_reference, rows_equal, build_summary).
Only differences vs the v1 runner:
  - cases file is expanded_benchmark_v2.json (X09 replaced, X03 flagged);
  - every per-question record additionally carries reference_sql, the exact
    prompt sent (system + user), model name/digest, Ollama version,
    database SHA-256 and case-file SHA-256, as required for the v2 report.

Usage (from the repo root, with the benchmark venv):
  python -u run_expanded_checkpoint_v2.py \
    --cases ~/workspace/research/morrow-handoff/work/research/benchmarks/expanded_benchmark_v2.json \
    --checkpoint <dir>/15_expanded90_v2_run1_checkpoint.jsonl \
    --run-label expanded90_v2_run1

It resumes automatically: case IDs already present in the checkpoint file
are skipped. The final summary is identical in shape to the repo harness
report, plus checkpoint metadata.
"""
import argparse
import hashlib
import json
import sys
import time
import urllib.request
from datetime import datetime, timezone
from pathlib import Path

CODE_ROOT = Path("/home/hatch/workspace/research/morrow-handoff/work/code")
if str(CODE_ROOT) not in sys.path:
    sys.path.insert(0, str(CODE_ROOT))
if str(CODE_ROOT / "scripts") not in sys.path:
    sys.path.insert(0, str(CODE_ROOT / "scripts"))

from app.agent import (  # noqa: E402
    DB_PATH,
    MODEL,
    OLLAMA_URL,
    AgentError,
    execute_sql,
    generate_sql,
    get_schema,
    validate_sql,
)
from run_sql_benchmark import build_summary, fetch_reference, rows_equal  # noqa: E402


def sha256_file(path):
    digest = hashlib.sha256()
    with open(path, "rb") as fh:
        for chunk in iter(lambda: fh.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def build_system_prompt(schema):
    """Reconstruct, verbatim, the system prompt generate_sql sends.

    Copied from app.agent.generate_sql so the stored prompt is exactly
    what the model received (same schema, same template).
    """
    return f"""
You are a careful business data analyst that writes SQLite SQL.

Use only tables and columns in this schema:
{schema}

Rules:
- Return exactly one read-only SELECT query, optionally using WITH.
- Never generate INSERT, UPDATE, DELETE, DROP, ALTER, CREATE,
  REPLACE, ATTACH, DETACH, PRAGMA, or multiple statements.
- Do not guess column names.
- Treat requested output column names as an exact output contract.
- If the question specifies a name for a result column, use that exact name as its SQL alias with AS.
- Do not replace requested output names with synonyms or alternative aliases.
- For example, if the question asks for "revenue", write the expression as AS revenue, not AS total_revenue.
- For revenue from orders, use order_items.quantity * order_items.unit_price.
- If the question is ambiguous, make a reasonable assumption and state it
  separately only if asked. For now return SQL only.
- Return only SQL, without Markdown fences or explanations.
""".strip()


def ollama_fingerprint():
    """Record model digest + server version from the live Ollama server."""
    base = OLLAMA_URL.rsplit("/api/chat", 1)[0]
    version = None
    digest = None
    try:
        with urllib.request.urlopen(base + "/api/version", timeout=10) as resp:
            version = json.loads(resp.read().decode("utf-8")).get("version")
    except Exception as exc:  # noqa: BLE001
        print(f"WARNING: could not read Ollama version: {exc}", flush=True)
    try:
        with urllib.request.urlopen(base + "/api/tags", timeout=10) as resp:
            models = json.loads(resp.read().decode("utf-8")).get("models", [])
        for entry in models:
            if entry.get("name") == MODEL or entry.get("model") == MODEL:
                digest = entry.get("digest")
    except Exception as exc:  # noqa: BLE001
        print(f"WARNING: could not read Ollama tags: {exc}", flush=True)
    return version, digest


def evaluate_case(case, schema, fingerprint):
    result = {
        "id": case["id"],
        "category": case["category"],
        "name": case["name"],
        "question": case["question"],
        "reference_sql": case["reference_sql"],
        "ordered": case.get("ordered"),
        "report_separately": bool(case.get("report_separately", False)),
        "model": MODEL,
        "model_digest": fingerprint["model_digest"],
        "ollama_version": fingerprint["ollama_version"],
        "database_sha256": fingerprint["database_sha256"],
        "case_file_sha256": fingerprint["case_file_sha256"],
        "prompt": {
            "system": build_system_prompt(schema),
            "user": case["question"],
            "temperature": 0,
        },
        "status": "not_started",
        "generation_seconds": None,
        "execution_seconds": None,
        "sql": None,
        "expected_columns": None,
        "actual_columns": None,
        "expected_row_count": None,
        "actual_row_count": None,
        "column_match": False,
        "rows_match": False,
        "answer_correct": False,
        "error": None,
    }
    try:
        expected_columns, expected_rows = fetch_reference(case["reference_sql"])
        result["expected_columns"] = expected_columns
        result["expected_row_count"] = len(expected_rows)
    except Exception as exc:  # noqa: BLE001
        result["status"] = "reference_error"
        result["error"] = f"{type(exc).__name__}: {exc}"
        return result

    generation_start = time.perf_counter()
    try:
        sql = generate_sql(case["question"], schema)
        result["generation_seconds"] = round(time.perf_counter() - generation_start, 3)
        result["sql"] = sql
    except Exception as exc:  # noqa: BLE001
        result["generation_seconds"] = round(time.perf_counter() - generation_start, 3)
        result["status"] = "generation_failure"
        result["error"] = f"{type(exc).__name__}: {exc}"
        return result

    try:
        validate_sql(sql)
    except AgentError as exc:
        result["status"] = "safety_rejection"
        result["error"] = str(exc)
        return result

    execution_start = time.perf_counter()
    try:
        actual_columns, actual_rows = execute_sql(sql)
        result["execution_seconds"] = round(time.perf_counter() - execution_start, 3)
    except Exception as exc:  # noqa: BLE001
        result["execution_seconds"] = round(time.perf_counter() - execution_start, 3)
        result["status"] = "execution_failure"
        result["error"] = f"{type(exc).__name__}: {exc}"
        return result

    result["actual_columns"] = actual_columns
    result["actual_row_count"] = len(actual_rows)
    result["column_match"] = actual_columns == expected_columns
    result["rows_match"] = rows_equal(expected_rows, actual_rows, case["ordered"])
    result["answer_correct"] = result["column_match"] and result["rows_match"]
    result["status"] = "correct" if result["answer_correct"] else "incorrect_answer"
    return result


def main():
    parser = argparse.ArgumentParser(description="Checkpointing Morrow benchmark v2 runner.")
    parser.add_argument("--cases", required=True)
    parser.add_argument("--checkpoint", required=True)
    parser.add_argument("--run-label", default="expanded90_v2_run1")
    args = parser.parse_args()

    cases_path = Path(args.cases)
    checkpoint_path = Path(args.checkpoint)
    checkpoint_path.parent.mkdir(parents=True, exist_ok=True)
    summary_path = checkpoint_path.with_suffix(".summary.json")

    cases = json.loads(cases_path.read_text(encoding="utf-8"))
    done = {}
    if checkpoint_path.is_file():
        for line in checkpoint_path.read_text(encoding="utf-8").splitlines():
            if line.strip():
                item = json.loads(line)
                done[item["id"]] = item
    print(f"Cases: {len(cases)}; already checkpointed: {len(done)}", flush=True)
    print(f"Model: {MODEL}; DB: {DB_PATH} sha256={sha256_file(DB_PATH)}", flush=True)
    print(f"Case file: {cases_path} sha256={sha256_file(cases_path)}", flush=True)

    if not DB_PATH.is_file():
        raise FileNotFoundError(f"Database not found: {DB_PATH}")

    ollama_version, model_digest = ollama_fingerprint()
    print(f"Ollama version: {ollama_version}; model digest: {model_digest}", flush=True)
    if model_digest is None:
        raise RuntimeError("Could not determine model digest from Ollama; refusing to run.")

    fingerprint = {
        "model_digest": model_digest,
        "ollama_version": ollama_version,
        "database_sha256": sha256_file(DB_PATH),
        "case_file_sha256": sha256_file(cases_path),
    }

    schema = get_schema()
    results = [done[c["id"]] for c in cases if c["id"] in done]

    with checkpoint_path.open("a", encoding="utf-8") as fh:
        for index, case in enumerate(cases, 1):
            if case["id"] in done:
                print(f"[{index:02d}/{len(cases):02d}] {case['id']} SKIP (checkpointed)", flush=True)
                continue
            print(f"[{index:02d}/{len(cases):02d}] {case['id']} | {case['category']} | {case['name']}", flush=True)
            result = evaluate_case(case, schema, fingerprint)
            results.append(result)
            fh.write(json.dumps(result, ensure_ascii=False) + "\n")
            fh.flush()
            summary = build_summary(results, cases[: len(results)] if len(results) < len(cases) else cases)
            summary_path.write_text(
                json.dumps(
                    {
                        "run_label": args.run_label,
                        "updated_at_utc": datetime.now(timezone.utc).isoformat(),
                        "model": MODEL,
                        "model_digest": model_digest,
                        "ollama_version": ollama_version,
                        "database_path": str(DB_PATH),
                        "database_sha256": fingerprint["database_sha256"],
                        "case_file": str(cases_path),
                        "case_file_sha256": fingerprint["case_file_sha256"],
                        "cases_completed": len(results),
                        "cases_total": len(cases),
                        "summary_partial": summary,
                        "results": results,
                    },
                    indent=2,
                    ensure_ascii=False,
                ),
                encoding="utf-8",
            )
            print(
                f"  {result['status'].upper()} | generation={result['generation_seconds']}s "
                f"| correct-so-far={sum(r['answer_correct'] for r in results)}/{len(results)}",
                flush=True,
            )
            if result["error"]:
                print(f"  Error: {result['error']}", flush=True)

    final = build_summary(results, cases)
    print("FINAL SUMMARY", flush=True)
    print(json.dumps(final, indent=2), flush=True)
    summary_path.write_text(
        json.dumps(
            {
                "run_label": args.run_label,
                "completed_at_utc": datetime.now(timezone.utc).isoformat(),
                "model": MODEL,
                "model_digest": model_digest,
                "ollama_version": ollama_version,
                "database_path": str(DB_PATH),
                "database_sha256": fingerprint["database_sha256"],
                "case_file": str(cases_path),
                "case_file_sha256": fingerprint["case_file_sha256"],
                "cases_completed": len(results),
                "cases_total": len(cases),
                "summary": final,
                "results": results,
            },
            indent=2,
            ensure_ascii=False,
        ),
        encoding="utf-8",
    )
    print(f"Checkpoint: {checkpoint_path}", flush=True)
    print(f"Summary: {summary_path}", flush=True)


if __name__ == "__main__":
    main()
