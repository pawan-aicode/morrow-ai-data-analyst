#!/bin/bash
# Morrow benchmark runs, 2026-11-22. Authorised by Pawan 2026-11-22 23:03 IST.
# Sequential: original-30 run 1, expanded-90 run 1, expanded-90 run 2, pytest.
set -u
RUN=~/workspace/research/morrow-handoff/work/experiments/2026-11-22-ollama-run
CODE=~/workspace/research/morrow-handoff/work/code
VENV=$RUN/venv/bin/python
ORIG_HASH=0026cf9b37d006051d13c4f69c70d2637259d7c19e34ad21d222c6a801bd65c7
EXP_HASH=8ed0fdae7a6289ed8cd14dfa5624fac2acd6ae48cb6f62cd68b84e4b519218eb
cd $CODE
echo "=== START $(date -u +%FT%TZ) ==="
echo "--- 1. ORIGINAL 30, run 1 ---"
$VENV scripts/run_sql_benchmark.py 2>&1 | tee $RUN/07_original30_run1.log
cp $(ls -t benchmarks/reports/sql_benchmark_*.json | head -1) $RUN/07_original30_run1.json
echo "--- 2. EXPANDED 90, run 1 ---"
cp ~/workspace/research/morrow-handoff/work/research/benchmarks/expanded_benchmark_v1.json benchmarks/sql_cases.json
sha256sum benchmarks/sql_cases.json
$VENV scripts/run_sql_benchmark.py 2>&1 | tee $RUN/08_expanded90_run1.log
cp $(ls -t benchmarks/reports/sql_benchmark_*.json | head -1) $RUN/08_expanded90_run1.json
echo "--- 3. EXPANDED 90, run 2 (variance) ---"
$VENV scripts/run_sql_benchmark.py 2>&1 | tee $RUN/09_expanded90_run2.log
cp $(ls -t benchmarks/reports/sql_benchmark_*.json | head -1) $RUN/09_expanded90_run2.json
echo "--- restore original cases ---"
cp $RUN/original30_backup.json benchmarks/sql_cases.json
sha256sum benchmarks/sql_cases.json
git status --short
echo "--- 4. PYTEST ---"
$RUN/venv/bin/python -m pytest -q 2>&1 | tee $RUN/10_pytest.log
echo "EXIT pytest: $?"
echo "=== END $(date -u +%FT%TZ) ==="
