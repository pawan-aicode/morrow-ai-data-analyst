# Authorisation record — Ollama install + Morrow benchmark run, 2026-11-22

Pawan gave explicit go-ahead in chat on 2026-11-22 23:03 IST:
"cant u download on ur own pc and run and check it ?"
Parent agent task (2026-11-22 23:03 IST): "Pawan just gave explicit go-ahead: download Ollama on this VM (my own PC) and run the Morrow 90-question benchmark and check it."

Scope of this authorisation (this task only):
- Install Ollama via the official Linux installer on this VM
- Pull qwen3.5:4b-q4_K_M (~2.6 GB)
- Build the Morrow sample DB via scripts/create_database.py (deterministic seed 42)
- Run scripts/run_sql_benchmark.py on the expanded 90-case benchmark, and the original 30-case benchmark
- Run pytest for the repo test suite
- Save all reports/logs under workspace/research/morrow-handoff/work/experiments/

NOT authorised in this task: publishing to Zenodo, GitHub, LinkedIn; editing either resume PDF; rewriting the paper PDFs.

## 2026-11-22 19:01 UTC — runtime-cell restart (incident)
systemd PID 1 and the hatch daemon both restarted at 19:01 UTC (new leader 2363, was 2358). Everything in the overlay was wiped: /usr/local/bin/ollama, zstd, the running Ollama server (PID 6450, killed mid-request at 19:01:23 with HTTP 500), and the in-flight expanded-90 run-1 (repo harness, no checkpointing). Lost: expanded-90 run 1 after 36/90 questions (log shows 32 CORRECT in the first 35 completed, 0 failures recorded; B11 in flight). The repo harness only writes its JSON report at the end, so no report survived. Home directory persisted: model blobs (~/.ollama, 3.1 GB), DB, venv, all logs and the original-30 report (07, 27/30 = 90.0%).
Recovery: reinstall Ollama binary only (blobs persist), restart manual ollama serve with proxy env, re-run expanded 90 with a NEW checkpointing runner (run_expanded_checkpoint.py) that appends each result to JSONL, so a future restart loses at most one question. sql_cases.json in work/code is currently the EXPANDED 90 set (hash 8ed0fdae) — restore the original 30 (original30_backup.json, hash 0026cf9b) after the runs.

## Killed expanded-90 run 1 — partial result (from 08 log, 2026-11-22 ~18:42-19:01 UTC)
35 questions completed before the restart: 32 CORRECT, 3 GENERATION_FAILURE = 91.4% on completed questions. The 3 failures are the SAME 3 as the original-30 re-run: J04 (ambiguous column name: order_id), R03 (no such column: name), R04 (no such column: order_items.quantity). No incorrect_answer / safety_rejection / execution_failure in the first 35. B11 was in flight when killed. These log lines are evidence only — no JSON report survived, so run 1 will be re-run in full with the checkpointing runner; do not merge log-line counts into the final report as if they were a completed run.

## 2026-11-22 21:01 UTC — SECOND runtime-cell restart (incident)
systemd PID 1 and hatch daemon restarted at 21:01 UTC (new leader 2427, was 2363). Ollama binary + zstd + server wiped again (overlay reset); tarball cache /home/hatch/ollama-linux-amd64.tar.zst and model blobs in ~/.ollama survived. Run 2 (variance) was killed at 58/90 — but the checkpointing runner saved all 58 results to expanded90_run2_checkpoint.jsonl (54 correct, fails J04/R03/R04 generation_failure + F11 incorrect_answer — identical to run 1 through 58 questions). A14 was in flight. Resume run 2 from the checkpoint after reinstall; it skips completed IDs automatically.
