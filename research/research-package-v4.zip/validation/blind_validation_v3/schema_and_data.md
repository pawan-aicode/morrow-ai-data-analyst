# Morrow database — schema and data facts (for blind derivation)

Source: live `code/data/sales.db`, read with PRAGMA / SELECT only. Database SHA-256:
fe81fd8655da44f29c99648a77697e48a289522e7686d252942c9fbfb8408cd2

## Schema

- `customers`(customer_id INTEGER, name TEXT, city TEXT) — 20 rows
- `order_items`(order_item_id INTEGER, order_id INTEGER, product_id INTEGER, quantity INTEGER, unit_price REAL) — 927 rows
- `orders`(order_id INTEGER, customer_id INTEGER, order_date TEXT, status TEXT) — 500 rows
- `products`(product_id INTEGER, product_name TEXT, category TEXT, unit_price REAL) — 10 rows

## Data facts

- order statuses: [('cancelled', 102), ('completed', 235), ('processing', 85), ('shipped', 78)]
- order_date range: [('2025-01-01', '2026-10-26')]
- product categories: [('Accessories',), ('Electronics',), ('Furniture',)]
- products: [(1, 'Laptop Pro', 'Electronics', 75000.0), (2, 'Wireless Mouse', 'Accessories', 1200.0), (3, 'Mechanical Keyboard', 'Accessories', 4500.0), (4, 'Monitor 27 inch', 'Electronics', 22000.0), (5, 'USB-C Hub', 'Accessories', 2800.0), (6, 'Office Chair', 'Furniture', 12500.0), (7, 'Standing Desk', 'Furniture', 28000.0), (8, 'Webcam HD', 'Electronics', 5500.0), (9, 'Headphones', 'Electronics', 8500.0), (10, 'Laptop Stand', 'Accessories', 1800.0)]
- cities: [('Ahmedabad',), ('Bengaluru',), ('Bhopal',), ('Chandigarh',), ('Chennai',), ('Coimbatore',), ('Delhi',), ('Goa',), ('Gurugram',), ('Hyderabad',), ('Indore',), ('Jaipur',), ('Kochi',), ('Kolkata',), ('Lucknow',), ('Mumbai',), ('Noida',), ('Pune',)]
- customers per city: [('Ahmedabad', 1), ('Bengaluru', 1), ('Bhopal', 1), ('Chandigarh', 1), ('Chennai', 1), ('Coimbatore', 1), ('Delhi', 2), ('Goa', 1), ('Gurugram', 1), ('Hyderabad', 1), ('Indore', 1), ('Jaipur', 1), ('Kochi', 1), ('Kolkata', 1), ('Lucknow', 1), ('Mumbai', 2), ('Noida', 1), ('Pune', 1)]
