# Second blind reference validation — instructions for the FRESH agent

**What this is:** you are an independent validator. You have NOT seen the
first validation report, the reference SQL, or any model outputs — and you
must keep it that way until your blind SQL is saved. Your job is to derive
reference SQL from the question texts + the database schema/data alone,
execute it, and save it BEFORE any comparison happens.

**You may read:**
- `blind_inputs_v3.json` — 90 cases: `id`, `category`, `question` ONLY.
- `blind_inputs_v1_v2.json` — the same for benchmark v1 and v2 (180 cases),
  if you are asked to check those versions too.
- `schema_and_data.md` — schema and data facts from the live database.
- The database itself, read-only: `workspace/research/morrow-handoff/work/code/data/sales.db`
  (SHA-256 `fe81fd86…` — verify before use; open with `?mode=ro` and
  `PRAGMA query_only = ON`; never write to it).

**You must NOT open, read, or search (before your blind file is saved):**
- `research/benchmarks/expanded_benchmark_v*.json` / `.csv` (they contain `reference_sql`)
- `research/reference_validation_v1_v2.md` / `.json`
- `research/reference_validation_blind_v1_v2.json`
- `research/benchmarks/expanded_benchmark_v*_CHANGELOG.md`
- `experiments/2026-11-22-ollama-run/` and `experiments/2026-11-23-ollama-run/`
  (run reports contain model-generated SQL and reference SQL)
- `paper/`, `audit/`, or any other file that could contain reference SQL.
- Do NOT use web search for these questions. Do NOT ask the parent agent
  for the reference SQL.

**Method (mirror the first validation):**
1. For every case in `blind_inputs_v3.json` (and v1/v2 if asked), write SQL
   from the question text + live schema/data only. Where the question
   under-specifies something (e.g. no tie-break for equal sort keys),
   record an explicit `blind_note` saying what you assumed — do NOT look
   for the "expected" choice.
2. Execute each blind query read-only against `sales.db`. Record columns,
   row count, all rows, and a SHA-256 of the result.
3. Save the complete blind file FIRST, before any comparison:
   `research/reference_validation_v3_second_blind.json` — one entry per
   case: `id`, `category`, `question`, `blind_sql`, `blind_note`,
   `blind_columns`, `blind_row_count`, `blind_rows`, `blind_result_sha256`.
   (Plus `reference_validation_v1_v2_second_blind.json` if v1/v2 were done.)
4. Only AFTER that file is written may you open the reference benchmark
   and run `compare_blind.py` (in this directory) to produce verdicts.
   If a blind query errors on execution, record the error and keep going;
   do not peek at the reference to fix it.

**Verdicts (per case):** CONFIRMED = same result (values, columns, and
order as determined by the question); DISCREPANCY = different result, one
side right and one wrong (state which, with evidence); AMBIGUOUS = the
question under-specifies the answer, so the reference is one of several
defensible answers (state the tie/ambiguity and the data evidence).

**Honesty note for the final report:** this is a second independent
derivation by a separate agent, NOT an external human reviewer. True
external human validation still needs a person with SQL knowledge and
remains open work.
