#!/usr/bin/env python3
"""Compare second-blind SQL against the v3 reference SQL (AFTER the blind file is saved).

Usage:
  python3 compare_blind.py --blind reference_validation_v3_second_blind.json \
      --benchmark ../benchmarks/expanded_benchmark_v3.json \
      --out ../reference_validation_v3_second

Reads the blind file (blind_sql per case) and the benchmark (reference_sql
per case), executes BOTH read-only against the seed-42 sales.db, and
compares columns + rows with a 1e-6 relative numeric tolerance. Writes
<out>.json (per-case verdicts) and prints a summary. The .md report is
written by hand from the JSON (verdicts + disagreement evidence), not
generated here, so a human/agent reads every disagreement before wording it.

Verdicts: CONFIRMED / DISCREPANCY / AMBIGUOUS (see INSTRUCTIONS_FOR_BLIND_AGENT.md).
A case is auto-marked AMBIGUOUS-CANDIDATE when values match as a multiset
but exact order differs — the reviewer then checks whether the v3 question
determines the order (it should, after the tie-break fix) or not.
"""
import argparse
import hashlib
import json
import math
import sqlite3
import sys
from pathlib import Path

WORK = Path("/home/hatch/workspace/research/morrow-handoff/work")
DB = WORK / "code" / "data" / "sales.db"


def sha256_file(path):
    d = hashlib.sha256()
    with open(path, "rb") as fh:
        for chunk in iter(lambda: fh.read(1024 * 1024), b""):
            d.update(chunk)
    return d.hexdigest()


def execute(sql):
    uri = DB.as_uri() + "?mode=ro"
    with sqlite3.connect(uri, uri=True, timeout=5) as conn:
        conn.execute("PRAGMA query_only = ON")
        cur = conn.execute(sql)
        cols = [d[0] for d in cur.description or []]
        rows = [list(r) for r in cur.fetchall()]
    return cols, rows


def values_equal(a, b):
    if a is None or b is None:
        return a is b
    if isinstance(a, (int, float)) and not isinstance(a, bool) \
            and isinstance(b, (int, float)) and not isinstance(b, bool):
        return math.isclose(a, b, rel_tol=1e-6, abs_tol=1e-6)
    return type(a) is type(b) and a == b


def rows_equal(a, b):
    return len(a) == len(b) and all(
        len(x) == len(y) and all(values_equal(p, q) for p, q in zip(x, y))
        for x, y in zip(a, b)
    )


def multiset_equal(a, b):
    if len(a) != len(b):
        return False
    rest = list(b)
    for row in a:
        idx = next((i for i, r in enumerate(rest)
                    if len(r) == len(row) and all(values_equal(p, q) for p, q in zip(row, r))), None)
        if idx is None:
            return False
        rest.pop(idx)
    return not rest


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--blind", required=True)
    ap.add_argument("--benchmark", required=True)
    ap.add_argument("--out", required=True)
    args = ap.parse_args()

    blind = {c["id"]: c for c in json.load(open(args.blind, encoding="utf-8"))}
    bench = {c["id"]: c for c in json.load(open(args.benchmark, encoding="utf-8"))}
    assert set(blind) == set(bench), (
        f"blind/benchmark ID mismatch: {set(blind) ^ set(bench)}")

    print(f"DB SHA-256: {sha256_file(DB)} (expect fe81fd86...)")
    results = []
    for cid in sorted(bench):
        ref_sql = bench[cid]["reference_sql"]
        blind_sql = blind[cid]["blind_sql"]
        entry = {"id": cid, "category": bench[cid]["category"],
                 "question": bench[cid]["question"],
                 "reference_sql": ref_sql, "blind_sql": blind_sql,
                 "blind_note": blind[cid].get("blind_note", "")}
        try:
            ref_cols, ref_rows = execute(ref_sql)
        except Exception as exc:  # noqa: BLE001
            entry.update({"verdict": "DISCREPANCY", "detail": f"reference SQL failed: {exc}"})
            results.append(entry)
            continue
        try:
            bl_cols, bl_rows = execute(blind_sql)
        except Exception as exc:  # noqa: BLE001
            entry.update({"verdict": "DISCREPANCY",
                          "detail": f"blind SQL failed to execute: {exc}",
                          "reference_columns": ref_cols, "reference_row_count": len(ref_rows)})
            results.append(entry)
            continue
        entry.update({"reference_columns": ref_cols, "blind_columns": bl_cols,
                      "reference_row_count": len(ref_rows), "blind_row_count": len(bl_rows),
                      "reference_rows": ref_rows, "blind_rows": bl_rows,
                      "columns_match": ref_cols == bl_cols,
                      "exact_order_match": rows_equal(ref_rows, bl_rows),
                      "multiset_match": multiset_equal(ref_rows, bl_rows)})
        if ref_cols == bl_cols and rows_equal(ref_rows, bl_rows):
            entry["verdict"] = "CONFIRMED"
        elif ref_cols == bl_cols and multiset_equal(ref_rows, bl_rows):
            entry["verdict"] = "AMBIGUOUS-CANDIDATE"
            entry["detail"] = ("Same values as a multiset, different exact order. "
                               "Reviewer: check whether the v3 question determines "
                               "the order; if not, verdict is AMBIGUOUS, else the "
                               "blind SQL's order is simply wrong (DISCREPANCY).")
        else:
            entry["verdict"] = "DISCREPANCY-CANDIDATE"
            entry["detail"] = ("Different values and/or columns. Reviewer: decide "
                               "which side is right per the question text, or "
                               "whether the question under-specifies it (AMBIGUOUS).")
        results.append(entry)

    counts = {}
    for r in results:
        counts[r["verdict"]] = counts.get(r["verdict"], 0) + 1
    print(f"Cases: {len(results)} | verdicts: {counts}")
    for r in results:
        if r["verdict"] != "CONFIRMED":
            print(f"  {r['id']}: {r['verdict']} — {r.get('detail', '')[:160]}")
    out = Path(args.out)
    out.with_suffix(".json").write_text(json.dumps(
        {"blind_file": str(args.blind), "benchmark_file": str(args.benchmark),
         "database_sha256": sha256_file(DB), "counts": counts,
         "results": results}, indent=2, ensure_ascii=False), encoding="utf-8")
    print(f"Wrote {out.with_suffix('.json')}")


if __name__ == "__main__":
    sys.exit(main())
