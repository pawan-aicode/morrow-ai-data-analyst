# Morrow benchmark reference-SQL validation — blind derivation vs reference

**Date:** 2026-11-23. **Validator:** blind independent derivation (no reference SQL, no model-generated SQL, and no run reports were read before the blind SQL was written and executed).

**Files:**
- Blind SQL (step 1, saved before any reference SQL was read): `workspace/research/morrow-handoff/work/research/reference_validation_blind_v1_v2.json` (180 cases)
- This report: `workspace/research/morrow-handoff/work/research/reference_validation_v1_v2.md`
- Machine-readable verdicts: `workspace/research/morrow-handoff/work/research/reference_validation_v1_v2.json`
- Benchmarks: `workspace/research/morrow-handoff/work/research/benchmarks/expanded_benchmark_v1.json`, `expanded_benchmark_v2.json` (90 cases each)
- Database: `workspace/research/morrow-handoff/work/code/data/sales.db` (SQLite; schema verified by PRAGMA, not assumed)

## Method

1. **Blind phase.** A script extracted only `id`, `category`, `question` from both benchmark files (never `reference_sql`). SQL for all 180 cases was written from the question text plus the live schema/data only, then executed against `sales.db`. Results (row count, columns, all rows, SHA-256 hash) were saved to `reference_validation_blind_v1_v2.json` **before** any reference SQL was opened. The v1/v2 run reports in `experiments/2026-11-22-ollama-run/` were never opened.
2. **Comparison phase.** Reference SQL was read and executed (360 query executions total: 180 blind + 180 reference, 0 errors). Columns and rows were compared. Numeric cells compare with a relative tolerance of 1e-6 (so `2025` vs `"2025"` and `500` vs `500.0` count as equal values; no such type difference actually occurred).
3. **Order sensitivity.** The benchmark sets `ordered: true` for **all 90 cases in both versions**, so the scorer is order-sensitive everywhere. Verdicts therefore treat row order as significant — but only where the *question* determines it. Where the question states an order ("highest first", "newest first", "ordered by …") **and** a tie-break ("breaking ties by …"), the order is fully determined. Where the question states an order but no tie-break and the data contains ties on the sort key, the reference's tie order is an unstated choice, not something the question determines — that is AMBIGUOUS, not a reference error.
4. **Verdicts.** CONFIRMED = same result (values, columns, and order as determined by the question). DISCREPANCY = different result, one side right and one wrong. AMBIGUOUS = the question under-specifies the answer, so the reference is one of several defensible answers.

## Summary counts

| Version | Cases | CONFIRMED | DISCREPANCY | AMBIGUOUS | Exact-order matches | Multiset matches | Column-name matches | Reference errors |
|---|---|---|---|---|---|---|---|---|
| v1 | 90 | 84 | 0 | 6 | 89/90 | 90/90 | 90/90 | 0 |
| v2 | 90 | 84 | 0 | 6 | 89/90 | 90/90 | 90/90 | 0 |

**Headline: no reference query is wrong on values. 0 discrepancies in either version. All 180 reference queries execute without error, all 180 return exactly the right values (multiset match 180/180) with exactly the column names the questions demand (180/180). The only problems are 6 cases per version where the question does not determine the answer uniquely — 5 order-only, 1 severe (R14, membership). The 6 ambiguous case IDs are identical in v1 and v2, and the questions, SQL and results for those 6 are byte-identical across versions (only X09 differs between v1 and v2, and X09 is CONFIRMED in both).**

## Database facts verified while deriving (all from executed queries, not assumptions)

- Schema: `customers(customer_id, name, city)`, `products(product_id, product_name, category, unit_price)`, `orders(order_id, customer_id, order_date, status)`, `order_items(order_item_id, order_id, product_id, quantity, unit_price)`. Statuses: completed 235, cancelled 102, processing 85, shipped 78 (500 orders). Dates 2025-01-01 to 2026-10-26. 20 customers, 10 products, 927 order items.
- Every order has ≥1 order item; every customer has orders and completed orders; every product appears in `order_items`.
- X15's premise ("each completed order contains items from one category only") is TRUE for completed orders (0 completed orders mix categories) but FALSE for all orders (170 orders mix categories) — the reference correctly scopes it to completed orders.
- X03: 0 products have never appeared in `order_items` — the correct answer is the empty result, which the reference returns.
- X13: exactly 3 products never appeared in a completed order (USB-C Hub 5, Webcam HD 8, Laptop Stand 10) — reference returns exactly these.
- X09 v1: all 20 customers ordered from all three categories. X09 v2: exactly 9 customers (4, 7, 8, 9, 11, 15, 17, 18, 20) in completed orders placed in 2026.
- X02: no ties at rank 2 in any city (each city has ≤2 customers; Delhi and Mumbai have 2, the rest 1) — RANK vs ROW_NUMBER makes no difference here; 20 rows.
- X12: no ties at rank 2 in any category — 6 rows.
- X06: average total completed spending across all customers = 881225.0; 10 customers above it. All 20 customers have completed orders, so "all customers" vs "customers with completed orders" makes no difference.
- X10: top order values are distinct (523000, 431000, 388500, …), so the second-highest is unambiguously order 123 at 431000.
- R13: largest order value 523000 (order 303) is unique. J04: no ties in the top 10 order values and none at the 10th/11th boundary (292200 vs 288500).

## Discrepancies and ambiguous cases — full table

There are **0 discrepancies**. The 6 ambiguous cases below are the same in v1 and v2 (same question, same blind SQL, same reference SQL, same results); the table lists each once with `Versions: v1, v2`. Full SQL and full results for each case follow in the detail sections.

| ID | Category | Question | Blind SQL | Reference SQL | Blind result | Reference result | Verdict | Which is right | Evidence |
|---|---|---|---|---|---|---|---|---|---|
| J05 | joins | Show each customer who has placed an order and their most recent order date. Return customer_id, name and latest_order_date, newest date first. | `SELECT c.customer_id, c.name, MAX(o.order_date) AS latest_order_date FROM orders o JOIN customers c ON c.customer_id = o.customer_id GROUP BY c.customer_id, c.name ORDER BY latest_order_date DESC, c.customer_id ASC;` | `SELECT c.customer_id, c.name, MAX(o.order_date) AS latest_order_date FROM customers c JOIN orders o ON o.customer_id = c.customer_id GROUP BY c.customer_id, c.name ORDER BY latest_order_date DESC, c.customer_id ASC` | 20 rows: [4, 'Customer 004', '2026-10-26']; [17, 'Customer 017', '2026-10-26']; [16, 'Customer 016', '2026-10-24']; [18, 'Customer 018', '2026-10-23']; [15, 'Customer 015', '2026-10-21']; [20, 'Customer 020', '2026-10-21']; [7, 'Customer 007', '2026-10-20']; [10, 'Customer 010', '2026-10-17']; [13, 'Customer 013', '2026-10-16']; [3, 'Customer 003', '2026-10-13']; [12, 'Customer 012', '2026-10-13']; [5, 'Customer 005', '2026-10-11']; [1, 'Customer 001', '2026-10-08']; [19, 'Customer 019', '2026-10-07']; [9, 'Customer 009', '2026-10-03']; [11, 'Customer 011', '2026-10-01']; [2, 'Customer 002', '2026-09-25']; [8, 'Customer 008', '2026-09-14']; [6, 'Customer 006', '2026-09-13']; [14, 'Customer 014', '2026-09-13'] | 20 rows: [4, 'Customer 004', '2026-10-26']; [17, 'Customer 017', '2026-10-26']; [16, 'Customer 016', '2026-10-24']; [18, 'Customer 018', '2026-10-23']; [15, 'Customer 015', '2026-10-21']; [20, 'Customer 020', '2026-10-21']; [7, 'Customer 007', '2026-10-20']; [10, 'Customer 010', '2026-10-17']; [13, 'Customer 013', '2026-10-16']; [3, 'Customer 003', '2026-10-13']; [12, 'Customer 012', '2026-10-13']; [5, 'Customer 005', '2026-10-11']; [1, 'Customer 001', '2026-10-08']; [19, 'Customer 019', '2026-10-07']; [9, 'Customer 009', '2026-10-03']; [11, 'Customer 011', '2026-10-01']; [2, 'Customer 002', '2026-09-25']; [8, 'Customer 008', '2026-09-14']; [6, 'Customer 006', '2026-09-13']; [14, 'Customer 014', '2026-09-13'] | AMBIGUOUS | Neither is wrong on values. Four pairs of customers share the same latest order date: 2026-10-26 (customers 4, 17), 2026-10-21 (15, 20), 2026-10-13 (3, 12), 2026-09-13 (6, 14). The question says "newest date first" with no tie-break, so either order within each pair is correct. The reference adds an unstated tie-break (customer_id ASC). My blind SQL added the same tie-break and matched exactly. | Executed: blind 20 rows, reference identical, e.g. rows 1-2 are [4, Customer 004, 2026-10-26], [17, Customer 017, 2026-10-26]. Ties verified in data: MAX(order_date) per customer has 4 duplicated dates. Benchmark ordered=True, so an order-sensitive scorer would mark the reverse order within a tied pair wrong even though the question permits it. |
| J08 | joins | Calculate the total quantity sold for every product across all orders. Return product_id, product_name and quantity_sold, highest quantity first. | `SELECT p.product_id, p.product_name, SUM(oi.quantity) AS quantity_sold FROM order_items oi JOIN products p ON p.product_id = oi.product_id GROUP BY p.product_id, p.product_name ORDER BY quantity_sold DESC, p.product_id ASC;` | `SELECT p.product_id, p.product_name, SUM(oi.quantity) AS quantity_sold FROM products p JOIN order_items oi ON oi.product_id = p.product_id GROUP BY p.product_id, p.product_name ORDER BY quantity_sold DESC, p.product_id ASC` | 10 rows: [4, 'Monitor 27 inch', 276]; [6, 'Office Chair', 276]; [7, 'Standing Desk', 271]; [9, 'Headphones', 232]; [1, 'Laptop Pro', 214]; [3, 'Mechanical Keyboard', 199]; [2, 'Wireless Mouse', 182]; [10, 'Laptop Stand', 141]; [8, 'Webcam HD', 129]; [5, 'USB-C Hub', 123] | 10 rows: [4, 'Monitor 27 inch', 276]; [6, 'Office Chair', 276]; [7, 'Standing Desk', 271]; [9, 'Headphones', 232]; [1, 'Laptop Pro', 214]; [3, 'Mechanical Keyboard', 199]; [2, 'Wireless Mouse', 182]; [10, 'Laptop Stand', 141]; [8, 'Webcam HD', 129]; [5, 'USB-C Hub', 123] | AMBIGUOUS | Neither is wrong on values. Monitor 27 inch and Office Chair tie at 276 units (ranks 1-2 of 10 products). The question says "highest quantity first" with no tie-break, so either order is correct. The reference adds an unstated tie-break (product_id ASC: Monitor id 4 before Office Chair id 6). My blind SQL added the same tie-break and matched exactly. | Executed: blind 10 rows, reference identical, both starting [Monitor 27 inch 276, Office Chair 276, Standing Desk 271, ...]. Tie verified in data: SUM(quantity) per product -> Monitor 276, Office Chair 276. Benchmark ordered=True, so an order-sensitive scorer would mark the reverse order wrong even though the question permits it. |
| R07 | ranking | Find the top 5 customer cities by number of orders. Return city and order_count, highest count first. | `SELECT c.city, COUNT(*) AS order_count FROM orders o JOIN customers c ON c.customer_id = o.customer_id GROUP BY c.city ORDER BY order_count DESC, c.city ASC LIMIT 5;` | `SELECT c.city, COUNT(o.order_id) AS order_count FROM customers c JOIN orders o ON o.customer_id = c.customer_id GROUP BY c.city ORDER BY order_count DESC, c.city ASC LIMIT 5` | 5 rows: ['Mumbai', 54]; ['Delhi', 48]; ['Bhopal', 31]; ['Goa', 31]; ['Lucknow', 30] | 5 rows: ['Mumbai', 54]; ['Delhi', 48]; ['Bhopal', 31]; ['Goa', 31]; ['Lucknow', 30] | AMBIGUOUS | Neither is wrong on values. Goa and Bhopal tie at 31 orders (ranks 3-4, both inside the top 5). The question says "highest count first" with no tie-break, so either order is correct. The reference adds an unstated tie-break (city ASC: Bhopal before Goa). My blind SQL added the same conventional tie-break and matched exactly. | Executed: blind 5 rows [Mumbai 54, Delhi 48, Bhopal 31, Goa 31, Lucknow 30]; reference identical, same 5 rows in the same order. Tie verified in data: SELECT city, COUNT(*) ... GROUP BY city -> Goa 31, Bhopal 31. Benchmark ordered=True for this case, so an order-sensitive scorer would mark a model answer "Goa before Bhopal" wrong even though the question permits it. |
| R11 | ranking | Show the top 5 products by total quantity sold across all orders. Return product_name and quantity_sold, highest first. | `SELECT p.product_name, SUM(oi.quantity) AS quantity_sold FROM order_items oi JOIN products p ON p.product_id = oi.product_id GROUP BY p.product_id, p.product_name ORDER BY quantity_sold DESC, p.product_id ASC LIMIT 5;` | `SELECT p.product_name, SUM(oi.quantity) AS quantity_sold FROM products p JOIN order_items oi ON oi.product_id = p.product_id GROUP BY p.product_id, p.product_name ORDER BY quantity_sold DESC, p.product_name ASC LIMIT 5` | 5 rows: ['Monitor 27 inch', 276]; ['Office Chair', 276]; ['Standing Desk', 271]; ['Headphones', 232]; ['Laptop Pro', 214] | 5 rows: ['Monitor 27 inch', 276]; ['Office Chair', 276]; ['Standing Desk', 271]; ['Headphones', 232]; ['Laptop Pro', 214] | AMBIGUOUS | Neither is wrong on values. Monitor 27 inch and Office Chair tie at 276 units (ranks 1-2). The question says "highest first" with no tie-break, so either order is correct. The reference adds an unstated tie-break (product_name ASC: Monitor before Office Chair). My blind SQL added product_id ASC, which happens to give the same order (Monitor id 4 < Office Chair id 6). | Executed: blind 5 rows [Monitor 27 inch 276, Office Chair 276, Standing Desk 271, Headphones 232, Laptop Pro 214]; reference identical. Tie verified in data: SUM(quantity) per product -> Monitor 276, Office Chair 276. Benchmark ordered=True, so an order-sensitive scorer would mark the reverse order wrong even though the question permits it. |
| R14 | ranking | Find the top 5 completed orders by total line-item value. Return order_id and order_value, highest value first. | `SELECT oi.order_id, SUM(oi.quantity * oi.unit_price) AS order_value FROM order_items oi JOIN orders o ON o.order_id = oi.order_id WHERE o.status = 'completed' GROUP BY oi.order_id ORDER BY order_value DESC, oi.order_id ASC LIMIT 5;` | `WITH order_totals AS (SELECT o.order_id, SUM(oi.quantity * oi.unit_price) AS order_value FROM orders o JOIN order_items oi ON oi.order_id = o.order_id WHERE o.status = 'completed' GROUP BY o.order_id) SELECT order_id, order_value FROM order_totals ORDER BY order_value DESC, order_id ASC LIMIT 5` | 5 rows: [1, 225000.0]; [18, 225000.0]; [32, 225000.0]; [80, 225000.0]; [214, 225000.0] | 5 rows: [1, 225000.0]; [18, 225000.0]; [32, 225000.0]; [80, 225000.0]; [214, 225000.0] | AMBIGUOUS | Neither is uniquely right. 19 completed orders all have total value exactly 225000.0, the maximum. "Top 5 by value, highest first" with no tie-break admits any 5 of the 19 (C(19,5) = 11,628 possible answer sets). The reference picks the 5 lowest order_ids (1, 18, 32, 80, 214) via an unstated ORDER BY order_value DESC, order_id ASC. My blind SQL independently made the same conventional choice and matched exactly — that agreement is an artefact of both of us guessing the same tie-break, not evidence the question determines the answer. A model returning any other 5 of the 19 tied orders is equally correct per the question and would be scored wrong against this reference. | Executed: blind 5 rows [[1, 225000.0], [18, 225000.0], [32, 225000.0], [80, 225000.0], [214, 225000.0]]; reference identical. Tie verified in data: COUNT of completed orders with total value 225000.0 = 19 (order_ids 1, 18, 32, 80, 214, 221, 235, 244, 251, 273, 311, 318, 352, 372, 405, 413, 421, 456, 468); no completed order exceeds 225000.0. Benchmark ordered=True. |
| X08 | advanced | For each customer city, calculate the cancellation rate as a percentage of that city's orders. Return city, total_orders, cancelled_orders and cancellation_rate_pct rounded to two decimal places, highest rate first. | `SELECT c.city, COUNT(*) AS total_orders, SUM(CASE WHEN o.status = 'cancelled' THEN 1 ELSE 0 END) AS cancelled_orders, ROUND(100.0 * SUM(CASE WHEN o.status = 'cancelled' THEN 1 ELSE 0 END) / COUNT(*), 2) AS cancellation_rate_pct FROM orders o JOIN customers c ON c.customer_id = o.customer_id GROUP BY c.city ORDER BY cancellation_rate_pct DESC;` | `SELECT c.city, COUNT(*) AS total_orders, SUM(CASE WHEN o.status = 'cancelled' THEN 1 ELSE 0 END) AS cancelled_orders, ROUND(100.0 * SUM(CASE WHEN o.status = 'cancelled' THEN 1 ELSE 0 END) / COUNT(*), 2) AS cancellation_rate_pct FROM customers c JOIN orders o ON o.customer_id = c.customer_id GROUP BY c.city ORDER BY cancellation_rate_pct DESC, c.city ASC` | 18 rows: ['Bengaluru', 26, 8, 30.77]; ['Coimbatore', 27, 8, 29.63]; ['Delhi', 48, 14, 29.17]; ['Jaipur', 28, 7, 25.0]; ['Bhopal', 31, 7, 22.58]; ['Ahmedabad', 9, 2, 22.22]; ['Kochi', 24, 5, 20.83]; ['Noida', 20, 4, 20.0]; ['Chennai', 20, 4, 20.0]; ['Goa', 31, 6, 19.35]; ['Kolkata', 21, 4, 19.05]; ['Mumbai', 54, 10, 18.52]; ['Gurugram', 27, 5, 18.52]; ['Chandigarh', 27, 5, 18.52]; ['Indore', 26, 4, 15.38]; ['Hyderabad', 26, 4, 15.38]; ['Lucknow', 30, 4, 13.33]; ['Pune', 25, 1, 4.0] | 18 rows: ['Bengaluru', 26, 8, 30.77]; ['Coimbatore', 27, 8, 29.63]; ['Delhi', 48, 14, 29.17]; ['Jaipur', 28, 7, 25.0]; ['Bhopal', 31, 7, 22.58]; ['Ahmedabad', 9, 2, 22.22]; ['Kochi', 24, 5, 20.83]; ['Chennai', 20, 4, 20.0]; ['Noida', 20, 4, 20.0]; ['Goa', 31, 6, 19.35]; ['Kolkata', 21, 4, 19.05]; ['Chandigarh', 27, 5, 18.52]; ['Gurugram', 27, 5, 18.52]; ['Mumbai', 54, 10, 18.52]; ['Hyderabad', 26, 4, 15.38]; ['Indore', 26, 4, 15.38]; ['Lucknow', 30, 4, 13.33]; ['Pune', 25, 1, 4.0] | AMBIGUOUS | Neither is wrong on values. Three tie groups on cancellation_rate_pct: 20.0 (Chennai, Noida), 18.52 (Mumbai, Gurugram, Chandigarh), 15.38 (Indore, Hyderabad). The question says "highest rate first" with no tie-break, so any order within each tied group is correct. The reference adds an unstated tie-break (city ASC). My blind SQL had no tie-break, so SQLite returned tied rows in group-scan order (Noida before Chennai; Mumbai, Gurugram, Chandigarh; Indore before Hyderabad). | Executed: blind 18 rows vs reference 18 rows, identical as multisets (multiset_match=True), different order only inside the three tie groups: 20.0 group blind [Noida, Chennai] vs ref [Chennai, Noida]; 18.52 group blind [Mumbai, Gurugram, Chandigarh] vs ref [Chandigarh, Gurugram, Mumbai]; 15.38 group blind [Indore, Hyderabad] vs ref [Hyderabad, Indore]. All other rows identical and in the same positions. This empirically proves the question does not determine the row order. Benchmark ordered=True. |

## Detail sections — the 6 ambiguous cases (identical in v1 and v2)

### J05 [joins] — Mild — order-only (v1 and v2)

**Question:** Show each customer who has placed an order and their most recent order date. Return customer_id, name and latest_order_date, newest date first.

**Verdict:** AMBIGUOUS

**Blind SQL:** `SELECT c.customer_id, c.name, MAX(o.order_date) AS latest_order_date FROM orders o JOIN customers c ON c.customer_id = o.customer_id GROUP BY c.customer_id, c.name ORDER BY latest_order_date DESC, c.customer_id ASC;`

**Reference SQL:** `SELECT c.customer_id, c.name, MAX(o.order_date) AS latest_order_date FROM customers c JOIN orders o ON o.customer_id = c.customer_id GROUP BY c.customer_id, c.name ORDER BY latest_order_date DESC, c.customer_id ASC`

**Blind result** (20 rows, columns ['customer_id', 'name', 'latest_order_date']): `20 rows: [4, 'Customer 004', '2026-10-26']; [17, 'Customer 017', '2026-10-26']; [16, 'Customer 016', '2026-10-24']; [18, 'Customer 018', '2026-10-23']; [15, 'Customer 015', '2026-10-21']; [20, 'Customer 020', '2026-10-21']; [7, 'Customer 007', '2026-10-20']; [10, 'Customer 010', '2026-10-17']; [13, 'Customer 013', '2026-10-16']; [3, 'Customer 003', '2026-10-13']; [12, 'Customer 012', '2026-10-13']; [5, 'Customer 005', '2026-10-11']; [1, 'Customer 001', '2026-10-08']; [19, 'Customer 019', '2026-10-07']; [9, 'Customer 009', '2026-10-03']; [11, 'Customer 011', '2026-10-01']; [2, 'Customer 002', '2026-09-25']; [8, 'Customer 008', '2026-09-14']; [6, 'Customer 006', '2026-09-13']; [14, 'Customer 014', '2026-09-13']`

**Reference result** (20 rows, columns ['customer_id', 'name', 'latest_order_date']): `20 rows: [4, 'Customer 004', '2026-10-26']; [17, 'Customer 017', '2026-10-26']; [16, 'Customer 016', '2026-10-24']; [18, 'Customer 018', '2026-10-23']; [15, 'Customer 015', '2026-10-21']; [20, 'Customer 020', '2026-10-21']; [7, 'Customer 007', '2026-10-20']; [10, 'Customer 010', '2026-10-17']; [13, 'Customer 013', '2026-10-16']; [3, 'Customer 003', '2026-10-13']; [12, 'Customer 012', '2026-10-13']; [5, 'Customer 005', '2026-10-11']; [1, 'Customer 001', '2026-10-08']; [19, 'Customer 019', '2026-10-07']; [9, 'Customer 009', '2026-10-03']; [11, 'Customer 011', '2026-10-01']; [2, 'Customer 002', '2026-09-25']; [8, 'Customer 008', '2026-09-14']; [6, 'Customer 006', '2026-09-13']; [14, 'Customer 014', '2026-09-13']`

**Which is right:** Neither is wrong on values. Four pairs of customers share the same latest order date: 2026-10-26 (customers 4, 17), 2026-10-21 (15, 20), 2026-10-13 (3, 12), 2026-09-13 (6, 14). The question says "newest date first" with no tie-break, so either order within each pair is correct. The reference adds an unstated tie-break (customer_id ASC). My blind SQL added the same tie-break and matched exactly.

**Evidence:** Executed: blind 20 rows, reference identical, e.g. rows 1-2 are [4, Customer 004, 2026-10-26], [17, Customer 017, 2026-10-26]. Ties verified in data: MAX(order_date) per customer has 4 duplicated dates. Benchmark ordered=True, so an order-sensitive scorer would mark the reverse order within a tied pair wrong even though the question permits it.

**Blind note (recorded before seeing the reference):** ASSUMPTION: question gives no tie-break for equal latest dates; added customer_id ASC for determinism.

### J08 [joins] — Mild — order-only (v1 and v2)

**Question:** Calculate the total quantity sold for every product across all orders. Return product_id, product_name and quantity_sold, highest quantity first.

**Verdict:** AMBIGUOUS

**Blind SQL:** `SELECT p.product_id, p.product_name, SUM(oi.quantity) AS quantity_sold FROM order_items oi JOIN products p ON p.product_id = oi.product_id GROUP BY p.product_id, p.product_name ORDER BY quantity_sold DESC, p.product_id ASC;`

**Reference SQL:** `SELECT p.product_id, p.product_name, SUM(oi.quantity) AS quantity_sold FROM products p JOIN order_items oi ON oi.product_id = p.product_id GROUP BY p.product_id, p.product_name ORDER BY quantity_sold DESC, p.product_id ASC`

**Blind result** (10 rows, columns ['product_id', 'product_name', 'quantity_sold']): `10 rows: [4, 'Monitor 27 inch', 276]; [6, 'Office Chair', 276]; [7, 'Standing Desk', 271]; [9, 'Headphones', 232]; [1, 'Laptop Pro', 214]; [3, 'Mechanical Keyboard', 199]; [2, 'Wireless Mouse', 182]; [10, 'Laptop Stand', 141]; [8, 'Webcam HD', 129]; [5, 'USB-C Hub', 123]`

**Reference result** (10 rows, columns ['product_id', 'product_name', 'quantity_sold']): `10 rows: [4, 'Monitor 27 inch', 276]; [6, 'Office Chair', 276]; [7, 'Standing Desk', 271]; [9, 'Headphones', 232]; [1, 'Laptop Pro', 214]; [3, 'Mechanical Keyboard', 199]; [2, 'Wireless Mouse', 182]; [10, 'Laptop Stand', 141]; [8, 'Webcam HD', 129]; [5, 'USB-C Hub', 123]`

**Which is right:** Neither is wrong on values. Monitor 27 inch and Office Chair tie at 276 units (ranks 1-2 of 10 products). The question says "highest quantity first" with no tie-break, so either order is correct. The reference adds an unstated tie-break (product_id ASC: Monitor id 4 before Office Chair id 6). My blind SQL added the same tie-break and matched exactly.

**Evidence:** Executed: blind 10 rows, reference identical, both starting [Monitor 27 inch 276, Office Chair 276, Standing Desk 271, ...]. Tie verified in data: SUM(quantity) per product -> Monitor 276, Office Chair 276. Benchmark ordered=True, so an order-sensitive scorer would mark the reverse order wrong even though the question permits it.

**Blind note (recorded before seeing the reference):** ASSUMPTION: question gives no tie-break; Monitor 27 inch and Office Chair TIE at 276 (top). Added product_id ASC for determinism — order between the tied pair is not determined by the question.

### R07 [ranking] — Mild — order-only (v1 and v2)

**Question:** Find the top 5 customer cities by number of orders. Return city and order_count, highest count first.

**Verdict:** AMBIGUOUS

**Blind SQL:** `SELECT c.city, COUNT(*) AS order_count FROM orders o JOIN customers c ON c.customer_id = o.customer_id GROUP BY c.city ORDER BY order_count DESC, c.city ASC LIMIT 5;`

**Reference SQL:** `SELECT c.city, COUNT(o.order_id) AS order_count FROM customers c JOIN orders o ON o.customer_id = c.customer_id GROUP BY c.city ORDER BY order_count DESC, c.city ASC LIMIT 5`

**Blind result** (5 rows, columns ['city', 'order_count']): `5 rows: ['Mumbai', 54]; ['Delhi', 48]; ['Bhopal', 31]; ['Goa', 31]; ['Lucknow', 30]`

**Reference result** (5 rows, columns ['city', 'order_count']): `5 rows: ['Mumbai', 54]; ['Delhi', 48]; ['Bhopal', 31]; ['Goa', 31]; ['Lucknow', 30]`

**Which is right:** Neither is wrong on values. Goa and Bhopal tie at 31 orders (ranks 3-4, both inside the top 5). The question says "highest count first" with no tie-break, so either order is correct. The reference adds an unstated tie-break (city ASC: Bhopal before Goa). My blind SQL added the same conventional tie-break and matched exactly.

**Evidence:** Executed: blind 5 rows [Mumbai 54, Delhi 48, Bhopal 31, Goa 31, Lucknow 30]; reference identical, same 5 rows in the same order. Tie verified in data: SELECT city, COUNT(*) ... GROUP BY city -> Goa 31, Bhopal 31. Benchmark ordered=True for this case, so an order-sensitive scorer would mark a model answer "Goa before Bhopal" wrong even though the question permits it.

**Blind note (recorded before seeing the reference):** ASSUMPTION: question gives no tie-break; Goa and Bhopal TIE at 31 (ranks 3-4, both inside top 5, so membership is unaffected but their relative order is not determined by the question). Added city ASC.

### R11 [ranking] — Mild — order-only (v1 and v2)

**Question:** Show the top 5 products by total quantity sold across all orders. Return product_name and quantity_sold, highest first.

**Verdict:** AMBIGUOUS

**Blind SQL:** `SELECT p.product_name, SUM(oi.quantity) AS quantity_sold FROM order_items oi JOIN products p ON p.product_id = oi.product_id GROUP BY p.product_id, p.product_name ORDER BY quantity_sold DESC, p.product_id ASC LIMIT 5;`

**Reference SQL:** `SELECT p.product_name, SUM(oi.quantity) AS quantity_sold FROM products p JOIN order_items oi ON oi.product_id = p.product_id GROUP BY p.product_id, p.product_name ORDER BY quantity_sold DESC, p.product_name ASC LIMIT 5`

**Blind result** (5 rows, columns ['product_name', 'quantity_sold']): `5 rows: ['Monitor 27 inch', 276]; ['Office Chair', 276]; ['Standing Desk', 271]; ['Headphones', 232]; ['Laptop Pro', 214]`

**Reference result** (5 rows, columns ['product_name', 'quantity_sold']): `5 rows: ['Monitor 27 inch', 276]; ['Office Chair', 276]; ['Standing Desk', 271]; ['Headphones', 232]; ['Laptop Pro', 214]`

**Which is right:** Neither is wrong on values. Monitor 27 inch and Office Chair tie at 276 units (ranks 1-2). The question says "highest first" with no tie-break, so either order is correct. The reference adds an unstated tie-break (product_name ASC: Monitor before Office Chair). My blind SQL added product_id ASC, which happens to give the same order (Monitor id 4 < Office Chair id 6).

**Evidence:** Executed: blind 5 rows [Monitor 27 inch 276, Office Chair 276, Standing Desk 271, Headphones 232, Laptop Pro 214]; reference identical. Tie verified in data: SUM(quantity) per product -> Monitor 276, Office Chair 276. Benchmark ordered=True, so an order-sensitive scorer would mark the reverse order wrong even though the question permits it.

**Blind note (recorded before seeing the reference):** ASSUMPTION: question gives no tie-break; Monitor 27 inch and Office Chair TIE at 276 (ranks 1-2). Added product_id ASC — their relative order is not determined by the question.

### R14 [ranking] — SEVERE — membership undetermined (v1 and v2)

**Question:** Find the top 5 completed orders by total line-item value. Return order_id and order_value, highest value first.

**Verdict:** AMBIGUOUS

**Blind SQL:** `SELECT oi.order_id, SUM(oi.quantity * oi.unit_price) AS order_value FROM order_items oi JOIN orders o ON o.order_id = oi.order_id WHERE o.status = 'completed' GROUP BY oi.order_id ORDER BY order_value DESC, oi.order_id ASC LIMIT 5;`

**Reference SQL:** `WITH order_totals AS (SELECT o.order_id, SUM(oi.quantity * oi.unit_price) AS order_value FROM orders o JOIN order_items oi ON oi.order_id = o.order_id WHERE o.status = 'completed' GROUP BY o.order_id) SELECT order_id, order_value FROM order_totals ORDER BY order_value DESC, order_id ASC LIMIT 5`

**Blind result** (5 rows, columns ['order_id', 'order_value']): `5 rows: [1, 225000.0]; [18, 225000.0]; [32, 225000.0]; [80, 225000.0]; [214, 225000.0]`

**Reference result** (5 rows, columns ['order_id', 'order_value']): `5 rows: [1, 225000.0]; [18, 225000.0]; [32, 225000.0]; [80, 225000.0]; [214, 225000.0]`

**Which is right:** Neither is uniquely right. 19 completed orders all have total value exactly 225000.0, the maximum. "Top 5 by value, highest first" with no tie-break admits any 5 of the 19 (C(19,5) = 11,628 possible answer sets). The reference picks the 5 lowest order_ids (1, 18, 32, 80, 214) via an unstated ORDER BY order_value DESC, order_id ASC. My blind SQL independently made the same conventional choice and matched exactly — that agreement is an artefact of both of us guessing the same tie-break, not evidence the question determines the answer. A model returning any other 5 of the 19 tied orders is equally correct per the question and would be scored wrong against this reference.

**Evidence:** Executed: blind 5 rows [[1, 225000.0], [18, 225000.0], [32, 225000.0], [80, 225000.0], [214, 225000.0]]; reference identical. Tie verified in data: COUNT of completed orders with total value 225000.0 = 19 (order_ids 1, 18, 32, 80, 214, 221, 235, 244, 251, 273, 311, 318, 352, 372, 405, 413, 421, 456, 468); no completed order exceeds 225000.0. Benchmark ordered=True.

**Blind note (recorded before seeing the reference):** WARNING — SEVERE TIE: 19 completed orders tie at the maximum value 225000.0. 'Top 5' membership is NOT determined by the question; any 5 of the 19 are defensible. Added order_id ASC only for determinism.

### X08 [advanced] — Mild — order-only (the only case where blind and reference order differ) (v1 and v2)

**Question:** For each customer city, calculate the cancellation rate as a percentage of that city's orders. Return city, total_orders, cancelled_orders and cancellation_rate_pct rounded to two decimal places, highest rate first.

**Verdict:** AMBIGUOUS

**Blind SQL:** `SELECT c.city, COUNT(*) AS total_orders, SUM(CASE WHEN o.status = 'cancelled' THEN 1 ELSE 0 END) AS cancelled_orders, ROUND(100.0 * SUM(CASE WHEN o.status = 'cancelled' THEN 1 ELSE 0 END) / COUNT(*), 2) AS cancellation_rate_pct FROM orders o JOIN customers c ON c.customer_id = o.customer_id GROUP BY c.city ORDER BY cancellation_rate_pct DESC;`

**Reference SQL:** `SELECT c.city, COUNT(*) AS total_orders, SUM(CASE WHEN o.status = 'cancelled' THEN 1 ELSE 0 END) AS cancelled_orders, ROUND(100.0 * SUM(CASE WHEN o.status = 'cancelled' THEN 1 ELSE 0 END) / COUNT(*), 2) AS cancellation_rate_pct FROM customers c JOIN orders o ON o.customer_id = c.customer_id GROUP BY c.city ORDER BY cancellation_rate_pct DESC, c.city ASC`

**Blind result** (18 rows, columns ['city', 'total_orders', 'cancelled_orders', 'cancellation_rate_pct']): `18 rows: ['Bengaluru', 26, 8, 30.77]; ['Coimbatore', 27, 8, 29.63]; ['Delhi', 48, 14, 29.17]; ['Jaipur', 28, 7, 25.0]; ['Bhopal', 31, 7, 22.58]; ['Ahmedabad', 9, 2, 22.22]; ['Kochi', 24, 5, 20.83]; ['Noida', 20, 4, 20.0]; ['Chennai', 20, 4, 20.0]; ['Goa', 31, 6, 19.35]; ['Kolkata', 21, 4, 19.05]; ['Mumbai', 54, 10, 18.52]; ['Gurugram', 27, 5, 18.52]; ['Chandigarh', 27, 5, 18.52]; ['Indore', 26, 4, 15.38]; ['Hyderabad', 26, 4, 15.38]; ['Lucknow', 30, 4, 13.33]; ['Pune', 25, 1, 4.0]`

**Reference result** (18 rows, columns ['city', 'total_orders', 'cancelled_orders', 'cancellation_rate_pct']): `18 rows: ['Bengaluru', 26, 8, 30.77]; ['Coimbatore', 27, 8, 29.63]; ['Delhi', 48, 14, 29.17]; ['Jaipur', 28, 7, 25.0]; ['Bhopal', 31, 7, 22.58]; ['Ahmedabad', 9, 2, 22.22]; ['Kochi', 24, 5, 20.83]; ['Chennai', 20, 4, 20.0]; ['Noida', 20, 4, 20.0]; ['Goa', 31, 6, 19.35]; ['Kolkata', 21, 4, 19.05]; ['Chandigarh', 27, 5, 18.52]; ['Gurugram', 27, 5, 18.52]; ['Mumbai', 54, 10, 18.52]; ['Hyderabad', 26, 4, 15.38]; ['Indore', 26, 4, 15.38]; ['Lucknow', 30, 4, 13.33]; ['Pune', 25, 1, 4.0]`

**Which is right:** Neither is wrong on values. Three tie groups on cancellation_rate_pct: 20.0 (Chennai, Noida), 18.52 (Mumbai, Gurugram, Chandigarh), 15.38 (Indore, Hyderabad). The question says "highest rate first" with no tie-break, so any order within each tied group is correct. The reference adds an unstated tie-break (city ASC). My blind SQL had no tie-break, so SQLite returned tied rows in group-scan order (Noida before Chennai; Mumbai, Gurugram, Chandigarh; Indore before Hyderabad).

**Evidence:** Executed: blind 18 rows vs reference 18 rows, identical as multisets (multiset_match=True), different order only inside the three tie groups: 20.0 group blind [Noida, Chennai] vs ref [Chennai, Noida]; 18.52 group blind [Mumbai, Gurugram, Chandigarh] vs ref [Chandigarh, Gurugram, Mumbai]; 15.38 group blind [Indore, Hyderabad] vs ref [Hyderabad, Indore]. All other rows identical and in the same positions. This empirically proves the question does not determine the row order. Benchmark ordered=True.

**Blind note (recorded before seeing the reference):** No tie-break specified; will check for ties in executed result.

## Flagged cases — resolution

### X03 (returns 0 rows) — reference CORRECT
Question: "Find products that have never appeared in order_items." Executed blind and reference both return 0 rows, because every one of the 10 products appears in `order_items` (verified: `COUNT(*) ... NOT EXISTS` = 0). The empty result is the correct answer, not a bug. A model answering with an empty result is right; the paper should note this case is a 0-row expected result. CONFIRMED in v1 and v2.

### X02 (ranking ties) — reference CORRECT
Question uses `RANK()` with ties at rank 2 included, sorted by city, rank_in_city, customer_id. Executed result: 20 rows. No city actually has a tie at rank 2 in this data (verified per-city: the two 2-customer cities, Delhi and Mumbai, have clearly separated revenues — Delhi 994400 vs 321900; Mumbai 1498500 vs 1092500), so the tie-handling path is untested by the data but the question specifies it correctly and the reference implements it exactly as specified. CONFIRMED in v1 and v2.

### X09 — v1 reference CORRECT; v2 reference CORRECT (the replacement works)
v1 question: customers who ordered from all three categories (any status/date). Reference returns all 20 customers; blind derivation independently returns the same 20. Note: 20 rows does not approach any 200-row cap — the cap concern does not apply to the reference result itself.
v2 question: same, restricted to completed orders placed in 2026. Reference (`WHERE o.status = 'completed' AND o.order_date >= '2026-01-01' AND o.order_date < '2027-01-01'`, `HAVING COUNT(DISTINCT p.category) = 3`) returns exactly 9 customers: 4, 7, 8, 9, 11, 15, 17, 18, 20. Blind derivation (using `strftime('%Y', order_date) = '2026'`) returns the identical 9. The v2 replacement is correct and does what the task description says (9 rows). CONFIRMED in both versions.

## Confirmed cases (84 per version)

All cases except the 6 above are CONFIRMED — blind and reference agree exactly (values, columns, and order as determined by the question), in both v1 and v2:

Basic: B01, B02, B03, B04, B05, B06, B07, B08, B09, B10, B11, B12, B13, B14, B15
Filtering: F01, F02, F03, F04, F05, F06, F07, F08, F09, F10, F11, F12, F13, F14, F15
Aggregation: A01, A02, A03, A04, A05, A06, A07, A08, A09, A10, A11, A12, A13, A14, A15
Joins: J01, J02, J03, J04, J06, J07, J09, J10, J11, J12, J13, J14, J15
Ranking: R01, R02, R03, R04, R05, R06, R08, R09, R10, R12, R13, R15
Advanced: X01, X02, X03, X04, X05, X06, X07, X09, X10, X11, X12, X13, X14, X15

(v2 confirmed set is the same 84 IDs; the only v1/v2 difference in the whole benchmark is X09, confirmed in both.)

## What this means for the paper revision (step 2) — recommendations, no files changed

1. **No reference SQL needs correcting on values.** Do not silently fix any benchmark file: nothing is wrong with the values. Re-scoring of model answers on values is not required by this validation.
2. **R14 is the one scoring-validity threat.** The question as worded admits 11,628 equally correct top-5 sets (any 5 of the 19 completed orders tied at 225000.0). Any model answer that returned a different 5 of the 19 was scored wrong against the reference although it is correct per the question. Fix options for the paper revision: (a) add an explicit tie-break to the question — e.g. "highest value first, breaking ties by order_id ascending" — which makes the current reference uniquely correct; or (b) change the question to something deterministic (e.g. "find the single largest completed order" — but that duplicates R13's shape); or (c) drop R14 / exclude it from scoring and disclose why. Whichever is chosen, model answers for R14 from the 22 Nov runs should be re-scored or excluded, and the paper must disclose this transparently.
3. **The 5 mild cases (R07, R11, J08, J05, X08) need a stated tie-break, not a new reference.** Add the tie-break the reference already uses into each question so the reference becomes uniquely determined: R07 "breaking ties alphabetically by city" (reference already orders `city ASC`); R11 "breaking ties by product_id ascending" (note: the reference orders by `product_name ASC`, which gives the same order here — pick one and state it); J08 "breaking ties by product_id ascending"; J05 "breaking ties by customer_id ascending"; X08 "breaking ties alphabetically by city". Then re-check: any model answer that differed only in tied-row order was correct per the question and should be re-scored as correct (or the cases excluded from order-sensitive scoring).
4. **X08 is the proof the ambiguity is real, not theoretical.** It is the only case where the blind derivation and the reference disagree at all — and they disagree only in the order of tied rows (20.0, 18.52, 15.38 groups). Two reasonable SQL formulations return different orders; the question cannot distinguish them.
5. **Consider making the scorer order-insensitive where the question does not determine order** — or, equivalently, keep `ordered: true` only for cases whose questions fully determine the order. As it stands `ordered` is true for all 90 cases, including the 6 where the question does not determine the order.
6. **No action needed on X02, X03, X09.** X02's RANK tie handling is specified correctly (no ties occur in the data); X03's empty result is correct; X09 v2 correctly returns 9 customers.

## Limitations

- Validation is against the current `sales.db` (seed 42). Tie findings (especially R14's 19-way tie) are properties of this dataset; a re-seeded database could change which cases are ambiguous.
- Float comparison used a 1e-6 relative tolerance; in practice blind and reference floats matched exactly (both compute the same aggregates in SQLite).
- "Year" is returned as TEXT ('2025'/'2026') by both blind (`strftime`) and reference (`SUBSTR`); treated as equal values, which they are.
- This step validates the reference SQL only. It does not re-score model answers, does not judge question quality beyond determinacy, and does not change any benchmark, paper, GitHub, LinkedIn or resume file — no files were modified except the three validation outputs listed at the top.
