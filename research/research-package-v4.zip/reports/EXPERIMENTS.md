# Morrow — Experiments Report (v1)

Date: 2026-11-22. Repo: https://github.com/pawan-aicode/morrow-ai-data-analyst (`main`,
tree SHA `7cfd2c52a05157b765345c461d3857083d8b45af` as listed by the GitHub API).
Author: experiments subagent. Nothing in this file was published, and nothing
was changed on GitHub. No numbers here are invented: every figure is either
labelled **EXECUTED HERE** (observed in this session) or **REPO-REPORTED**
(quoted from the repo's README/files, not re-run).

## 0. Execution-risk block — read this first

During this task, an `ls` of `~/workspace/research/morrow-handoff/work/code/`
showed that directory already contains a `.git` folder, and the runtime raised
a system execution-risk notice on that result. The notice forbids, without
explicit go-ahead, running / cloning / checking out / installing / building /
testing / importing / loading / sourcing that content, and forbids making
exceptions on my own say-so — including for familiar projects.

Consequences, exactly as applied:

- **NOT done:** cloning the repo (neither into `work/code/` nor into
  `work/experiments/repo-copy/`); running `pytest`; running
  `scripts/create_database.py`; running any benchmark harness
  (`run_sql_benchmark.py`, `benchmark_v2.py`, `benchmark_suite.py`,
  `benchmark_hard.py`, `benchmark_ranking.py`, `benchmark_models.py`);
  `pip install` of anything; installing Ollama; touching `work/code/` at all.
- **Done instead, by read-only means:** the repo was read as plain text via
  the GitHub API / raw file fetches (runs nothing): README, all of
  `benchmarks/sql_cases.json`, `scripts/create_database.py`,
  `scripts/run_sql_benchmark.py`, `scripts/benchmark_v2.py`,
  `scripts/benchmark_suite.py`, `scripts/benchmark_hard.py`,
  `scripts/benchmark_ranking.py`, `scripts/benchmark_models.py`,
  `app/agent.py` (all 865 lines), `requirements.txt`,
  `requirements-dev.txt`. The repo tree listing is the source for the file
  inventory in §5.
- **Done instead, with my own code only:** the sample database was rebuilt by
  an independent reimplementation I authored from the documented deterministic
  spec (seed 42, status counts, customer/product lists, completed-product
  targets, schema) — stdlib `random` + `sqlite3` only, no repo code imported,
  copied, or executed. Equivalence is *checked*, not assumed (§2: 0
  verification failures across every documented invariant). All ground-truth
  SQL was then executed against that rebuilt DB by my own read-only runner
  (§3). The ground-truth SQL itself is either quoted from
  `benchmarks/sql_cases.json` (original 30) or authored by me (new 60).

To finish the blocked items (pytest count, `create_database.py` output,
re-running the 30-case LLM benchmark, any Ollama work), the parent agent
needs Pawan's explicit go-ahead to clone/run the repo in this VM. See §7.

## 1. Environment (EXECUTED HERE)

Commands run in this session; full text in
`research/experiment-outputs/00_environment.log`.

| Check | Result |
| --- | --- |
| `which ollama` | no output — **Ollama binary NOT installed** |
| `which python3` / `python3 --version` | `/usr/bin/python3`, Python 3.12.3 |
| `which git` / `which sqlite3` | `/usr/bin/git`, `/usr/bin/sqlite3` |
| `curl -s -m 4 http://localhost:11434/api/tags` | connection refused (exit 7) — **no Ollama server running** |

Ollama install was NOT attempted: it needs the official curl|sh installer
plus a ~2.6 GB model pull, which is not quick on this VM, and the §0 block
covers installs. No second model exists anywhere in this setup, so **no
model comparison is possible here and none is claimed**.

## 2. Database rebuild and verification (EXECUTED HERE)

My scripts (authored for this task, stdlib only):

- `work/experiments/rebuild_db.py` — independent reimplementation of the
  documented deterministic generation (seed 42).
- `work/experiments/verify_db.py` — invariant checks, read-only connection.

Commands:

```bash
cd ~/workspace/research/morrow-handoff/work/experiments
python3 rebuild_db.py
python3 verify_db.py
```

Observed output (`research/experiment-outputs/01_db_rebuild.log`,
`02_db_verification.log`):

```text
Database created: /home/hatch/workspace/research/morrow-handoff/work/experiments/sales_rebuilt.db
Customers: 20
Products: 10
Orders: 500
Order items: 927
```

Verification: **0 failures.** Every documented invariant passed, including
the strongest ones — the per-product completed-order targets, which depend
on the exact RNG shuffle/sample sequence, so they effectively prove the
rebuild reproduces the repo-generated data:

| Check | Actual | Expected |
| --- | --- | --- |
| customers / products / orders | 20 / 10 / 500 | 20 / 10 / 500 |
| orders by status | cancelled 102, completed 235, processing 85, shipped 78 | same |
| completed product 1 (Laptop Pro) | 50 orders, 119 units | 50, 119 |
| completed product 7 (Standing Desk) | 45 orders, 115 units | 45, 115 |
| completed product 4 (Monitor 27 inch) | 45 orders, 141 units | 45, 141 |
| completed product 6 (Office Chair) | 35 orders, 120 units | 35, 120 |
| completed product 9 (Headphones) | 30 orders, 87 units | 30, 87 |
| completed product 2 (Wireless Mouse) | 20 orders, 40 units | 20, 40 |
| completed product 3 (Mechanical Keyboard) | 10 orders, 20 units | 10, 20 |
| completed orders with != 1 item | 0 | 0 |
| orders with zero items | 0 | 0 |
| min / max order_date | 2025-01-01 / 2026-10-26 | 2025-01-01 / ≤ 2026-10-26 |
| foreign_key_check violations | 0 | 0 |
| distinct product categories | 3 | 3 |
| products never in a completed order | [5, 8, 10] (USB-C Hub, Webcam HD, Laptop Stand) | [5, 8, 10] |

Additional facts established by execution (not in the README): 927 order
items; 18 distinct customer cities (not 17 — Delhi and Mumbai each have 2
customers, the other 16 cities 1 each); **no** product is missing from
`order_items` entirely (X03's reference answer is therefore the empty set);
**no** customer has zero orders.

## 3. Expanded benchmark — 90 questions (EXECUTED HERE)

### 3.1 What was built

- `research/benchmarks/expanded_benchmark_v1.csv` — 90 rows + header, columns
  `id, question, ground_truth_sql, category, expected_row_count, notes`.
- `research/benchmarks/expanded_benchmark_v1.json` — same 90 cases in the
  repo harness format (`id, category, name, question, reference_sql,
  ordered`), so `scripts/run_sql_benchmark.py` can run it unchanged once
  cloning/running is approved (it reads `benchmarks/sql_cases.json`; point it
  at this file or swap the file in).
- Authoring inputs kept at `work/experiments/benchmark_original30.json`
  (the 30 originals, `reference_sql` transcribed from
  `benchmarks/sql_cases.json`) and `work/experiments/benchmark_new60.json`
  (60 new, ground-truth SQL authored by me).
- Runner: `work/experiments/run_benchmark.py` (my code, read-only
  `mode=ro` + `PRAGMA query_only`, single SELECT/WITH only, rejects any
  case returning > 200 rows, the repo harness's `MAX_ROWS`).

Command:

```bash
cd ~/workspace/research/morrow-handoff/work/experiments
python3 run_benchmark.py
```

Result: **90/90 ground-truth queries executed successfully, 0 failures.**
Full per-case log (columns, row count, first row for every case) in
`research/experiment-outputs/03_benchmark_execution.log`. Row counts range
0–22; every case is within the repo harness's 200-row cap.

### 3.2 Size per category (EXECUTED HERE)

| Category | Original 30 | New 60 | Expanded total |
| --- | --- | --- | --- |
| basic | 5 | 10 | **15** |
| filtering | 5 | 10 | **15** |
| aggregation | 5 | 10 | **15** |
| joins | 5 | 10 | **15** |
| ranking | 5 | 10 | **15** |
| advanced | 5 | 10 | **15** |
| **Total** | **30** | **60** | **90** |

New-case design notes: same 6 categories and same question style as the
originals (explicit output column names as an exact contract, e.g. "Return
one column named total_orders"); new coverage includes DISTINCT counts,
MIN/MAX, date-range and month filters, per-city/per-year aggregation,
LEFT JOIN including zero-order customers, bottom-N ranking, LAG and running
totals, HAVING thresholds, relational division (customers ordering all 3
categories), and second-highest value. Every `expected_row_count` in the CSV
comes from execution against the rebuilt DB, not from guessing.

### 3.3 Verified ground-truth values worth noting (EXECUTED HERE)

- **X03 "Products never ordered" returns 0 rows.** Every one of the 10
  products appears in `order_items`. A model must return the empty set to
  pass; this case is valid but degenerate.
- **X13 "Products never in a completed order" returns 3 rows**
  (product 5 USB-C Hub, 8 Webcam HD, 10 Laptop Stand) — a non-degenerate
  replacement for X03's pattern.
- **X02 "Top two customers per city" returns 20 rows**, not 36: 16 of the
  18 cities have only one customer, so only Delhi and Mumbai contribute 2
  rows each.
- **X09 "Customers who ordered all three categories" returns 20 rows** —
  every customer qualifies.
- **X15 returns 2 rows** (Electronics, Furniture); Accessories' completed
  revenue does not exceed the 1,000,000 threshold.
- Cross-checks that hold exactly: orders 2025 (274) + 2026 (226) = 500;
  completed 2025 (131) + completed 2026 (104) = 235; cancelled 2025 (59) +
  cancelled 2026 (43) = 102; completed revenue ₹17,624,500 / 235 =
  ₹74,997.87 average completed order value (A03); total revenue
  ₹37,553,600 / 500 = ₹75,107.20 (A14); largest single order is order 303
  at ₹523,000 (J04, R13, A15 agree); second-highest is order 123 at
  ₹431,000 (X10).
- Column names were eyeballed in the log for every case: each returned
  column list matches the aliases the question asks for (e.g. B01 →
  `['total_orders']`, X01 → `['total_orders', 'cancelled_orders',
  'cancellation_rate_pct']`).

## 4. EXECUTED HERE vs REPO-REPORTED

| Claim / result | Status | Value |
| --- | --- | --- |
| Test suite: 180 passed, 27 subtests passed | **REPO-REPORTED** (README L256–258: "The latest recorded result is **180 passed, with 27 subtests passed**. This is a historical result, not a guarantee…") | NOT re-run here (§0 block). 15 test files exist in the repo tree (`tests/test_*.py`); pytest was not executed, so no count is claimed from this session. |
| Benchmark baseline 28/30 = 93.33% | **REPO-REPORTED** (README L269–275) | NOT re-run here. No Ollama/model in this VM (§1). |
| Benchmark after prompt modification 27/30 = 90% (LOWER) | **REPO-REPORTED** (README L278–282: "The second run was lower than the initial baseline; it should not be read as an improvement.") | NOT re-run here. Which questions failed in either run is **unknown** (§6). |
| Sample DB: 20 customers, 10 products, 500 orders | **EXECUTED HERE** (rebuilt + verified, §2) | 20 / 10 / 500, plus 927 order items (count recorded, not in README). |
| Expanded benchmark 90 questions, 15 per category, all ground-truth SQL executed | **EXECUTED HERE** (§3) | 90/90 executed, 0 failures, row counts 0–22. |
| Ollama `qwen3.5:4b-q4_K_M` available | **EXECUTED HERE** | NOT available: binary absent, no server on :11434. |
| Any model comparison | — | NONE. `benchmark_models.py` and `benchmark_v2.py`/`benchmark_suite.py`/`benchmark_hard.py` all list the same model twice (`MODELS = ["qwen3.5:4b-q4_K_M", "qwen3.5:4b-q4_K_M"]`), so even in-repo they compare the model against itself. |

## 5. Repo inventory (read-only; from the GitHub API tree listing)

- `README.md` (5,089 bytes), `requirements.txt`
  (`streamlit==1.66.1`, `pandas==3.1.0`, `plotly==7.1.0`,
  `openpyxl==3.1.5`), `requirements-dev.txt` (`-r requirements.txt`,
  `pytest==9.2.0`).
- `benchmarks/sql_cases.json` — the only file under `benchmarks/` in the
  repo. **No benchmark report files exist in the repo** (no
  `benchmarks/reports/`), which is why §6 is unknown.
- `scripts/`: `create_database.py`, `run_sql_benchmark.py` (the 30-case
  production harness: loads `sql_cases.json`, calls `app.agent.generate_sql`,
  requires exact column-name match AND ordered row match with numeric
  tolerance 1e-9 rel / 1e-6 abs, writes a JSON report to
  `benchmarks/reports/`), `benchmark_v2.py`, `benchmark_suite.py`,
  `benchmark_hard.py`, `benchmark_ranking.py`, `benchmark_models.py`,
  `validate_models.py`, `inspect_schema.py`.
- `app/agent.py` — production agent (`MODEL = "qwen3.5:4b-q4_K_M"`,
  `MAX_ROWS = 200`, `REQUEST_TIMEOUT = 180`, `MAX_QUERY_SECONDS = 5`).
- `tests/`: 15 test files (`test_agent.py`, `test_business_evidence.py`,
  `test_create_database.py`, `test_dashboard_builder.py`,
  `test_full_data_loaders.py`, `test_insight_explainer.py`,
  `test_insight_quality.py`, `test_insights.py`,
  `test_month_over_month.py`, `test_order_recommendations.py`,
  `test_profiling.py`, `test_recommendations.py`, `test_root_cause.py`,
  `test_sales_dashboard.py`, `test_saved_dashboards.py`).

## 6. Error classification — original 30 (UNKNOWN, by design)

The repo contains **no per-case failure details** for either run: the README
gives only the aggregate counts (28/30 and 27/30), and no report files are
in the repo tree. The commit history could not be read either (GitHub
commits API returned HTTP 403; `git log` in the flagged local directory is
prohibited by §0). Therefore:

- Which 2 questions failed at baseline and which 3 failed after the prompt
  modification: **unknown. Not invented, not guessed.**
- Error types (generation failure / safety rejection / execution failure /
  incorrect answer — the statuses `run_sql_benchmark.py` records): **unknown
  for both runs.**

What can be said from reading the harnesses: the 5 cases in
`benchmark_v2.py` and `benchmark_hard.py` are the hard subset
(X01, X02, X03, X04, R02 — plus a rank-1 variant of X02 in
`benchmark_hard.py`), which suggests those were the cases under
investigation, but the repo never states they were the failing ones, so
that is an observation, not a classification. `benchmark_ranking.py` is a
single RANK() test against a 7-row in-memory toy DB, unrelated to the
30-case benchmark.

## 7. Prompt sensitivity — baseline vs modified (repo text only)

The repo does not name or quote the earlier ("baseline") prompt, so a
before/after diff **cannot be reconstructed**. What exists in the repo are
two different prompts in current code; quoted verbatim below.

**Production prompt — `app/agent.py`, `generate_sql()` (lines 204–240).**
This is the prompt `run_sql_benchmark.py` uses (via `generate_sql`), so it
is the best candidate for the current / post-modification prompt — but the
repo never says so explicitly:

```text
You are a careful business data analyst that writes SQLite SQL.

Use only tables and columns in this schema:

{schema}   <- schema is generated live from the DB by get_schema():
            "Tables:\ncustomers(customer_id (INTEGER), name (TEXT), city (TEXT))\n
             products(product_id (INTEGER), product_name (TEXT), category (TEXT), unit_price (REAL))\n
             orders(order_id (INTEGER), customer_id (INTEGER), order_date (TEXT), status (TEXT))\n
             order_items(order_item_id (INTEGER), order_id (INTEGER), product_id (INTEGER), quantity (INTEGER), unit_price (REAL))\n
             Foreign keys:\norders.customer_id -> customers.customer_id\n
             order_items.order_id -> orders.order_id\norder_items.product_id -> products.product_id"

Rules:

- Return exactly one read-only SELECT query, optionally using WITH.
- Never generate INSERT, UPDATE, DELETE, DROP, ALTER, CREATE,
  REPLACE, ATTACH, DETACH, PRAGMA, or multiple statements.
- Do not guess column names.
- Treat requested output column names as an exact output contract.
- If the question specifies a name for a result column, use that exact name as its SQL alias with AS.
- Do not replace requested output names with synonyms or alternative aliases.
- For example, if the question asks for "revenue", write the expression as AS revenue, not AS total_revenue.
- For revenue from orders, use order_items.quantity * order_items.unit_price.
- If the question is ambiguous, make a reasonable assumption and state it
  separately only if asked. For now return SQL only.
- Return only SQL, without Markdown fences or explanations.
```

Call settings: `temperature: 0`, `num_predict: 400`, `think: false`.

**Standalone-harness prompt — `scripts/benchmark_v2.py` `SCHEMA` (and near-identical
variants in `benchmark_suite.py` / `benchmark_hard.py`).** Hardcoded schema
text, not read from the DB:

```text
SQLite schema:

customers(customer_id, name, city)
products(product_id, product_name, category, unit_price)
orders(order_id, customer_id, order_date, status)
order_items(order_item_id, order_id, product_id, quantity, unit_price)

Join keys:
orders.customer_id = customers.customer_id
order_items.order_id = orders.order_id
order_items.product_id = products.product_id

Completed-order revenue = SUM(quantity * unit_price).
Dates are stored as YYYY-MM-DD text.
Use SQLite syntax only. Return one SQL query and no explanation.
```

(`benchmark_v2.py` also tells the model "Use SQLite date/string functions"
and "in exactly YYYY-MM format" inside the X04 question itself; its call
settings are `temperature: 0`, no `num_predict` limit.)

**Analysis (from the text, no LLM run):** the two prompts differ in ways
that plausibly move accuracy in opposite directions. The production prompt
adds an explicit output-column contract ("use that exact name as its SQL
alias", "do not replace requested output names with synonyms") — that
should help the strict column-match scoring in `run_sql_benchmark.py`. But
it gives the model *less* task-specific guidance than the standalone
prompts: no explicit join keys, no revenue formula beyond the single
`quantity * unit_price` line, no date-format instruction, and it injects
the live schema (with types and FKs) rather than a compact hand-written
one. The standalone prompts instead spell out join keys, the revenue
definition, and the date format, and test only the 5 hardest cases. If the
"prompt modification" was a move from a standalone-style prompt toward the
production prompt (or vice versa), a 28 → 27 change is within noise for
n = 30: a single question flipping is 3.33 points, and the model is
nondeterministic across runs even at temperature 0 (README L282: "Model
output can vary between runs"). **No new prompt experiment was run here** —
that claim would require Ollama, which is absent (§1) — so this is analysis
of repo text only, not an experimental result.

## 8. What could NOT be run, and why

| Blocked item | Reason | What unblocks it |
| --- | --- | --- |
| `git clone` of the repo; `pytest -q` (180 passed / 27 subtests claim); `python3 scripts/create_database.py`; any benchmark harness run | §0 execution-risk block on the flagged local `.git` content; no approval to clone/run repo code | Parent agent obtains Pawan's explicit go-ahead to clone and run the repo in this VM (or runs these on his own machine and shares the logs). |
| Re-running the 30-case LLM benchmark (28/30 vs 27/30) and identifying the failing questions | No Ollama binary, no server, no model in this VM (§1); plus the §0 block | Ollama installed + `ollama pull qwen3.5:4b-q4_K_M` (~2.6 GB) + clone approval; then `python3 scripts/run_sql_benchmark.py` (writes per-case JSON report to `benchmarks/reports/`, which is what would finally classify the failures). |
| Model comparison (qwen3.5 vs another model) | No second model anywhere in the repo or VM; all "MODELS" lists in the repo contain the same model twice | A second Ollama model pulled + a harness edit to actually use two different model names. |
| Prompt A/B experiment | Requires the LLM runs above | Same as the benchmark re-run; also needs the baseline prompt text, which is not in the repo — it would have to come from git history or Pawan. |
| Git history (to find what the prompt modification was) | GitHub commits API returned HTTP 403; local `git log` prohibited by §0 | Parent agent / Pawan provides the history, or approves a clone, after which `git log -p -- app/agent.py` answers it directly. |

## 9. Files produced

- `research/EXPERIMENTS.md` — this file.
- `research/benchmarks/expanded_benchmark_v1.csv` — 90-case expanded
  benchmark (spec columns; every `expected_row_count` from execution).
- `research/benchmarks/expanded_benchmark_v1.json` — same 90 cases in
  repo-harness format.
- `research/experiment-outputs/00_environment.log` — Ollama/Python
  environment evidence.
- `research/experiment-outputs/01_db_rebuild.log` — DB rebuild output.
- `research/experiment-outputs/02_db_verification.log` — all invariant
  checks (0 failures).
- `research/experiment-outputs/03_benchmark_execution.log` — per-case
  execution log for all 90 ground-truth queries.
- `work/experiments/rebuild_db.py`, `verify_db.py`, `run_benchmark.py` —
  my own scripts (stdlib only; no repo code).
- `work/experiments/benchmark_original30.json`,
  `benchmark_new60.json` — benchmark authoring inputs.
- `work/experiments/sales_rebuilt.db` — rebuilt sample DB (SQLite,
  verified equivalent to the documented spec; NOT the repo-generated file,
  which was never created here).

## 10. Addendum 2026-11-22 — LLM runs EXECUTED HERE (Ollama install + benchmark re-runs)

Authorisation: Pawan, 2026-11-22 23:03 IST — "cant u download on ur own pc
and run and check it ?" (recorded in
`work/experiments/2026-11-22-ollama-run/AUTHORISATION.md`). This addendum
supersedes §0/§1/§4/§6/§7 for the items it covers: the §0 block no longer
applies to the runs below, because explicit go-ahead was given for THIS task
only. It does NOT authorise Zenodo/GitHub/LinkedIn publication or resume
edits — none were made.

### 10.1 Environment (EXECUTED HERE)
- VM: 4 CPUs, 7.7 GiB RAM (only ~400–850 MiB available while the model was
  loaded; swap in use), 143 GiB free on /home/hatch; overlay `/` is 7.5 GiB
  total and is WIPED on every runtime-cell restart (see §10.2).
- Ollama 0.40.17 installed via the official installer (needed zstd 1.5.5
  first, installed as a SHA256-verified .deb from the Ubuntu noble archive).
  Server run manually (`ollama serve`, PID 6450, then 7012, then 1902),
  inheriting the shell proxy env — the systemd service cannot reach the
  model registry (TLS handshake failure, proxy env missing). **Do NOT share
  `11_ollama_serve.log` / `14_ollama_serve.log` externally: Ollama's startup
  dump writes the egress proxy credential into them.**
- Model: `qwen3.5:4b-q4_K_M`, digest d8b0f5e9760c, 3,324,173,934 bytes,
  4.2B params, Q4_K_M, context 262,144. Pulled once (~23 min); blobs persist
  in ~/.ollama across restarts. Tarball cache kept at
  /home/hatch/ollama-linux-amd64.tar.zst (1.5 GB) for fast reinstalls.
- Smoke tests (curl POST /api/chat, temp 0, "Say hello in one word."):
  all HTTP 200, answer "Hello" — 101.4 s (1st), 227.1 s (2nd), 151.9 s (3rd).
  Slow CPU generation (~1.5–3.9 tok/s incl. thinking trace); no OOM.
- Python venv: `work/experiments/2026-11-22-ollama-run/venv` with
  requirements.txt + requirements-dev.txt (pytest 9.2.0, streamlit 1.66.1,
  pandas 3.1.0, plotly 7.1.0, openpyxl 3.1.5).

### 10.2 Two runtime-cell restarts (incidents)
- 19:01 UTC: systemd + hatch daemon restarted (leader 2358 -> 2363).
  Killed the repo-harness expanded-90 run 1 at 36/90 (log: 32 CORRECT in
  the first 35 completed, same 3 failures as the original-30 re-run; B11 in
  flight). The repo harness writes its JSON report only at the end, so NO
  report survived — only log lines. Overlay wiped: ollama binary, zstd,
  server. Home persisted.
- 21:01 UTC: second restart (leader 2363 -> 2427). Killed the
  checkpointing run 2 at 58/90 — but the checkpoint JSONL saved all 58
  results, and run 2 was resumed from it after reinstall.
- Lesson recorded: long model runs must checkpoint per question; the
  checkpointing runner below does that.

### 10.3 Database built with the repo script (EXECUTED HERE)
`python3 scripts/create_database.py` in `work/code/` produced
`data/sales.db` (sha256 fe81fd8655da44f29c99648a77697e48a289522e7686d252942c9fbfb8408cd2):
20 customers / 10 products / 500 orders / 927 order items; statuses
cancelled 102 / completed 235 / processing 85 / shipped 78; completed
revenue ₹17,624,500. Row-level comparison vs the §2 rebuilt DB:
customers, products, orders, order_items all IDENTICAL (SHA differs only
because of SQLite file-header/page formatting, not content).

### 10.4 Original-30 benchmark re-run (EXECUTED HERE)
Repo harness `scripts/run_sql_benchmark.py` (unchanged), 2026-11-22
18:17–18:34 UTC. Report:
`work/experiments/2026-11-22-ollama-run/07_original30_run1.json`.
- **27/30 = 90.0% correct.** Generation success 27/30 (90.0%); execution
  success 27/30; accuracy among executed 100.0% (0 incorrect answers).
- Per-category: basic 5/5, filtering 5/5, aggregation 5/5, advanced 5/5,
  joins 4/5 (80.0%), ranking 3/5 (60.0%).
- Generation latency: mean 34.06 s, median 34.11 s, p95 49.39 s.
- Failures (3, all generation_failure — invalid SQL rejected at EXPLAIN
  validation; the invalid SQL text is discarded by the harness, sql=None):
  J04 ambiguous column name: order_id; R03 no such column: name;
  R04 no such column: order_items.quantity.
- Comparison with REPO-REPORTED: our re-run matches the README's
  post-prompt-change figure (27/30 = 90%) exactly, NOT the 28/30 = 93.33%
  baseline. The baseline prompt is still unknown (not in the repo), so we
  CANNOT attribute the difference to the prompt change — the current code's
  prompt produced 27/30 here.

### 10.5 Expanded-90 benchmark, run 1 (EXECUTED HERE)
Checkpointing runner
`work/experiments/2026-11-22-ollama-run/run_expanded_checkpoint.py`
(uses the repo's own `app.agent.generate_sql/validate_sql/execute_sql`
and the harness's own `fetch_reference/rows_equal/build_summary`; only
difference is per-question checkpointing to JSONL). 2026-11-22
19:28–20:23 UTC. Report:
`work/experiments/2026-11-22-ollama-run/08_expanded90_run1.json`
(checkpoint: `expanded90_run1_checkpoint.jsonl` + `.summary.json`).
- **77/90 = 85.56% correct.** Generation success 83/90 (92.22%);
  execution success 83/90 (92.22%); accuracy among executed 92.77%.
  Status: 77 correct, 7 generation_failure, 5 incorrect_answer,
  1 execution_failure, 0 safety_rejection, 0 reference_error.
- Per-category: basic 15/15 (100%), aggregation 15/15 (100%),
  filtering 14/15 (93.33%), joins 14/15 (93.33%),
  ranking 9/15 (60.0%), advanced 10/15 (66.67%).
- Generation latency: mean 36.97 s, median 36.35 s, p95 57.71 s;
  execution mean 0.004 s.
- Failures (13): J04, R03, R04, R10, R12, R14 (generation_failure);
  F11, R07, X06, X08, X12 (incorrect_answer); X09 (execution_failure).
  Full error taxonomy in
  `work/experiments/2026-11-22-ollama-run/13_run1_error_taxonomy.md`:
  column-reference errors 6; window-function misuse 1 (X11);
  missing filter/dedup 2 (X12 no `rank <= 2` filter; X09 no DISTINCT,
  hit the 200-row cap); wrong grain/entity 2 (F11 counted customers
  instead of orders; X06 averaged per-order instead of per-customer);
  tie-ordering 2 (R07, X08 — values identical, order differs; the
  questions specify no tiebreak and scoring is order-sensitive, so these
  are arguably benchmark faults. Scored order-insensitively for ties,
  run 1 would be 79/90 = 87.78%.)

### 10.6 Expanded-90 benchmark, run 2 — variance (EXECUTED HERE)
Same checkpointing runner, fresh checkpoint, 2026-11-22 20:26–21:43 UTC
(interrupted by the 21:01 restart at 58/90, resumed from checkpoint).
Report: `work/experiments/2026-11-22-ollama-run/09_expanded90_run2.json`.
- **77/90 = 85.56% correct — IDENTICAL to run 1.** Per-category counts
  identical. Failing questions identical (same 13, same statuses).
  Per-question correctness agreement 90/90. Generated SQL identical
  90/90 (including None for generation failures).
- Latency differed only: generation mean 48.09 s (run 1: 36.97 s),
  median 41.89 s, p95 82.71 s; per-question diff run2−run1 mean +11.1 s
  (min −45.1 s, max +53.1 s) — machine-load variance, not model variance.
- Interpretation: at temperature 0, this model + prompt + DB produced
  byte-identical SQL on both runs in this setup. That is an empirical
  observation from 2 runs, not a guarantee — temperature 0 does not
  guarantee identical outputs in general, and n=2 is a small sample.

### 10.7 Test suite (EXECUTED HERE — claim now verified)
`python -m pytest -q` in `work/code/` with the benchmark venv:
**180 passed, 27 subtests passed in 4.27 s** (log:
`work/experiments/2026-11-22-ollama-run/10_pytest.log`). The historical
README claim is now reproduced. LLM calls in tests are mocked
(test_agent.py patches generate_sql/explain_results), so the suite does
not need Ollama.

### 10.8 What is STILL blocked / unknown (unchanged from §6–§7 except B1, B8)
- RESOLVED: B1 (no model run — now run, twice, 90 cases each) and B8
  (test-pass status — now reproduced, 180 passed).
- STILL OPEN: B2 failing questions — now KNOWN for both runs (the 13
  above, with error taxonomy); B3 baseline prompt unknown (git history
  still not available; the 28/30 baseline remains REPO-REPORTED and
  unattributed); B4 no model comparison (only one model exists here);
  B5 no human evaluation of explanations; B6 single synthetic DB
  (now repo-generated, not just rebuilt — DB equivalence proven in §10.3);
  B7 reference SQL not independently validated; B9 targeted, not
  systematic, background; B10 no licence; B11 package not independently
  re-run (by a third party).
- Repo state after the runs: `benchmarks/sql_cases.json` restored to the
  original 30 (sha256 0026cf9b37d006051d13c4f69c70d2637259d7c19e34ad21d222c6a801bd65c7);
  `git status` clean. Reports are in
  `work/experiments/2026-11-22-ollama-run/` (07, 08, 09, 10) and
  `work/code/benchmarks/reports/` (harness JSONs, gitignored).
- The papers were NOT rewritten in this run (per task scope); BUILD_NOTES.md
  has a matching addendum stating which numbers changed label.
