# Morrow — Code Inspection Report

**Repo:** https://github.com/pawan-aicode/morrow-ai-data-analyst
**Cloned to:** `~/workspace/research/morrow-handoff/work/code/` (shallow clone, `--depth 1`, 2026-11-22; first attempt failed with a TLS/RPC error, retry succeeded)
**Inspection date:** 2026-11-22
**Method:** read-only source inspection. No repository code was executed (no `pytest`, no benchmark run, no `streamlit run`) — the environment flagged the cloned content under an execution-risk check, and the task is inspection only. All findings below come from reading the files. Line numbers refer to the cloned copy.

---

## 1. Repository map

| Path | Lines | What it is |
| --- | --- | --- |
| `README.md` | 186 | Project doc; sole source of the 28/30 and 27/30 benchmark figures |
| `dashboard.py` | 379 | Streamlit entry point (chat + Dashboard Studio + Sales Intelligence) |
| `requirements.txt` | 4 | streamlit==1.66.1, pandas==3.1.0, plotly==7.1.0, openpyxl==3.1.5 |
| `requirements-dev.txt` | 2 | `-r requirements.txt`, pytest==9.2.0 |
| `app/agent.py` | 480 | NL→SQL agent (Ollama), validation, read-only execution, explanations |
| `app/dashboard_builder.py` | 1191 | AI dashboard builder for uploads / SQLite |
| `app/sales_dashboard.py` | 443 | Sales Intelligence dashboard (deterministic pandas/Plotly) |
| `app/profiling.py` | 303 | Dataframe profiling |
| `app/insights.py` | 341 | Factual insight calculation |
| `app/recommendations.py` | 395 | Recommendations from evidence |
| `app/root_cause.py` | 267 | Root-cause briefs |
| `app/insight_explainer.py` | 284 | LLM explanations of factual insights (Ollama) |
| `app/business_evidence.py` | 431 | Business-evidence / monthly-comparison logic |
| `app/saved_dashboards.py` | 98 | Local JSON persistence of dashboard filter presets |
| `benchmarks/sql_cases.json` | — | 30 benchmark cases with reference SQL |
| `scripts/create_database.py` | 221 | Synthetic DB generator |
| `scripts/run_sql_benchmark.py` | 444 | The 30-case benchmark harness (production pipeline) |
| `scripts/benchmark_suite.py` | 190 | Older 5-case harness, own prompt |
| `scripts/benchmark_v2.py` | 281 | Older 5-case harness, own prompt |
| `scripts/benchmark_hard.py` | 221 | Older 5-case harness, own prompt |
| `scripts/benchmark_models.py` | 76 | Single-question smoke check, 1 model listed twice |
| `scripts/benchmark_ranking.py` | 143 | Single ranking question vs in-memory DB |
| `scripts/validate_models.py` | 111 | Single-question smoke check, 1 model listed twice |
| `scripts/inspect_schema.py` | 41 | Prints schema of `data/sales.db` (top-level code, runs on import) |
| `tests/` (15 files) | — | 180 test functions + 27 subtests (see §7) |
| `data/sales.db` | — | **Not in repo** — gitignored (`.gitignore`: `data/sales.db`); generated locally |

No `benchmarks/reports/` directory exists in the repo, and no benchmark result/log JSON exists anywhere in it. `benchmarks/reports/` is gitignored (`.gitignore`).

---

## 2. Exact model configuration

Single model everywhere. No model comparison was ever wired up: every benchmark script that has a `MODELS` list contains the **same model twice** (`scripts/benchmark_suite.py:11`, `benchmark_v2.py:10`, `benchmark_hard.py:10`, `benchmark_models.py:7-10`, `validate_models.py:11-14`).

- **Model:** `qwen3.5:4b-q4_K_M` — `app/agent.py:13` (`MODEL = "qwen3.5:4b-q4_K_M"`). Imported by `app/dashboard_builder.py:14` and `app/insight_explainer.py:7`.
- **Endpoint:** `http://localhost:11434/api/chat` — `app/agent.py:12` (`OLLAMA_URL`). All Ollama calls use raw `urllib.request`; there is **no Ollama Python client** in `requirements.txt`.
- **Temperature: 0** in every Ollama call in the repo (SQL generation, explanation, dashboard plan, insight explainer, all benchmark scripts).
- **`think: False`** in every call (explicitly disables the model's thinking output).
- **`num_predict`:** 400 for SQL generation (`app/agent.py:146`); 180 for result explanation (`app/agent.py:343`); 1200 for dashboard plans (`app/dashboard_builder.py:197`); 500 for insight explanations (`app/insight_explainer.py:239`).
- **Request timeout:** 180 s for agent calls (`app/agent.py:16`); 120 s for dashboard plans; 300 s in `benchmark_models.py` / `validate_models.py`.
- **Execution guardrails (agent):** `MAX_ROWS = 200` (`app/agent.py:15`); per-query wall-clock cap `MAX_QUERY_SECONDS = 5` via `set_progress_handler` (`app/agent.py:17,402-406`); question length cap 2000 chars (`app/agent.py:425-431`).

### Embeddings / retrieval

**None.** There is no embedding model, no vector store, no RAG, no retrieval step anywhere in the repo (grep for `embed` returns nothing outside the word "embedded" in comments). The schema is read live from the actual database by `get_schema()` (`app/agent.py:24-71`, via `PRAGMA table_info` / `foreign_key_list`) and pasted verbatim into the system prompt on every call. That is the only "context" the model gets.

---

## 3. Prompts

### 3.1 Production SQL prompt — `app/agent.py:113-152` (`generate_sql`)

System prompt (schema interpolated verbatim from the live DB):

> You are a careful business data analyst that writes SQLite SQL.
>
> Use only tables and columns in this schema:
> {schema}
>
> Rules:
> - Return exactly one read-only SELECT query, optionally using WITH.
> - Never generate INSERT, UPDATE, DELETE, DROP, ALTER, CREATE,
>   REPLACE, ATTACH, DETACH, PRAGMA, or multiple statements.
> - Do not guess column names.
> - Treat requested output column names as an exact output contract.
> - If the question specifies a name for a result column, use that exact name as its SQL alias with AS.
> - Do not replace requested output names with synonyms or alternative aliases.
> - For example, if the question asks for "revenue", write the expression as AS revenue, not AS total_revenue.
> - For revenue from orders, use order_items.quantity * order_items.unit_price.
> - If the question is ambiguous, make a reasonable assumption and state it
>   separately only if asked. For now return SQL only.
> - Return only SQL, without Markdown fences or explanations.

The user message is the raw question. `temperature: 0, num_predict: 400, think: False, stream: False`.

### 3.2 Baseline vs "modified" prompt — what the code actually shows

**The repo contains no record of a baseline prompt, no record of what was modified, and no per-case results for either run.** The 28/30 (baseline) and 27/30 (after prompt modification) figures appear only in `README.md:159-160`. There is no second prompt version stored anywhere, no diff, no dated report, and no failing-case list. What the code does contain is **four different prompt wordings across the codebase**, and it is impossible from the repo alone to say which wording produced 28/30 and which produced 27/30:

| Prompt | Location | Distinguishing content |
| --- | --- | --- |
| Production prompt (§3.1, with alias-contract + revenue rules) | `app/agent.py:113-152` | Live schema injected; "exact output contract" alias rules; revenue formula rule |
| Suite prompt | `scripts/benchmark_suite.py:14-27` | Hard-coded schema text; "Revenue means SUM(...)"; "Only include completed orders when the question says completed orders" |
| V2 prompt | `scripts/benchmark_v2.py:14-27` | Hard-coded schema; "Completed-order revenue = SUM(quantity * unit_price)"; "Use SQLite syntax only. Return one SQL query and no explanation." |
| Hard prompt | `scripts/benchmark_hard.py:14-27` | Hard-coded schema; "Use SQLite syntax, not MySQL syntax"; "Return one SQL query only. Do not modify data." |

The most plausible reading — **inference, not verified** — is that the "prompt modification" was the addition of the alias-contract rules ("Treat requested output column names as an exact output contract… AS revenue, not AS total_revenue") and/or the revenue-formula rule in `app/agent.py`, and that the baseline used an earlier wording similar to the suite/v2/hard prompts. But the repo does not state this, and the 30-case harness (`run_sql_benchmark.py`) calls the production `generate_sql`, so it can only ever evaluate the *current* prompt. A paper must not present the two numbers as a controlled before/after comparison: there is no evidence the two runs differed only in the prompt, or that the database, model version, or Ollama build were held constant.

### 3.3 Other prompts in the repo

- **Result explanation** (`app/agent.py:325-344`, system message): *"You are a concise business data analyst. Explain the provided query results in plain English. Use only numbers and facts present in the supplied data. Do not invent causes, trends, or business explanations. Treat the supplied rows as the complete SQL query result. If the query asks for the top N and returns N rows, answer directly from those rows without claiming more data is needed. Do not generate SQL. Keep the answer to 2-4 sentences."* — temperature 0, num_predict 180. Note: for single-value and 2-column results the explanation is **deterministic, not LLM** (`_deterministic_scalar_summary`, `_deterministic_group_summary`, `app/agent.py:217-313`); the LLM is only called for other shapes.
- **Dashboard plan** (`app/dashboard_builder.py:143-213`): system *"You design dashboards. Return valid JSON only."*; user prompt asks for a JSON-only plan (title, summary, ≤4 KPIs, ≤6 charts) from column summaries + data profile, with `format: "json"`, temperature 0, num_predict 1200, timeout 120 s. The returned plan is then sanitised by `_safe_plan` (`app/dashboard_builder.py:222-286`): only real columns, only allowed aggregations (`sum|mean|count|min|max`), labels re-derived from the operation (model-supplied labels discarded).
- **Insight explainer** (`app/insight_explainer.py:134-239`): explains pre-computed factual insights; validated afterwards by `_validate_explanation` (checks currency symbols, granularity, and other contradictions against the supplied facts). Temperature 0, num_predict 500.

---

## 4. SQL validation / read-only guard

Three independent layers in `app/agent.py`:

1. **Response extraction** — `_extract_sql_response` (`app/agent.py:74-111`): accepts plain SQL or exactly one ```sql fenced block; rejects prose before/after SQL, multiple fences, malformed fences, empty/non-string responses, and anything not starting with `SELECT`/`WITH`. Then **compiles** the SQL against the real schema with `EXPLAIN` on a `mode=ro` + `PRAGMA query_only` connection (no authorizer on this path — minor inconsistency, see §9).
2. **Keyword validation** — `validate_sql` (`app/agent.py:179-215`): strips one optional trailing semicolon; rejects any `;` remaining (no statement chaining); requires `SELECT`/`WITH` start; denylist regex blocks `INSERT|UPDATE|DELETE|DROP|ALTER|CREATE|REPLACE|ATTACH|DETACH|PRAGMA|VACUUM|REINDEX|ANALYZE` (case-insensitive, word-boundary).
3. **Execution** — `execute_sql` (`app/agent.py:392-422`): `mode=ro` URI + `PRAGMA query_only = ON` + a SQLite **authorizer** (`_read_only_authorizer`, `app/agent.py:367-390`) that allows only `SELECT/READ/FUNCTION/RECURSIVE`, denies reads from any attached database, and denies `load_extension`, `readfile`, `writefile`. Plus a 5-second progress-handler deadline and a 200-row cap (raises `AgentError` above 200 rows).

The older benchmark scripts have their own weaker, duplicated guards (regex `SELECT|WITH` start + `;` check + `PRAGMA query_only`, 500/501-row caps; `benchmark_v2.py` / `benchmark_hard.py` use a 2,000,000-operation progress handler as a timeout proxy). `app/dashboard_builder.py:58-88` (`read_sqlite_readonly`) validates the table name against the inspected table list and quotes it before `SELECT *`.

**Caveats for a paper:** the denylist is a regex over raw SQL text (it would also fire on those words inside string literals, and it is a supplement, not the real enforcement — the real enforcement is `mode=ro` + `query_only` + authorizer). The `EXPLAIN` compile check in `_extract_sql_response` runs without the authorizer, so a query that passes `EXPLAIN` could still be refused later — fail-safe direction, but the two checks are not identical.

---

## 5. Benchmark harness and scoring

### 5.1 The 30-case harness — `scripts/run_sql_benchmark.py`

This is the only harness that runs all 30 cases against the production pipeline (`generate_sql` → `validate_sql` → `execute_sql` from `app/agent.py`).

**Scoring method: execution-result comparison, NOT exact-match SQL string.** (`evaluate_case`, lines 155-244; `rows_equal`/`values_equal`, lines 88-130.)

- The reference SQL is executed against the same database; the model-generated SQL is executed the same way.
- A case is **correct only if BOTH match**: (a) the returned **column names are exactly equal, in order** (`actual_columns == expected_columns`, line 231), and (b) the **rows match** — every case in `sql_cases.json` has `"ordered": true`, so row order matters; numeric cells compare with `math.isclose` (rel_tol 1e-9, abs_tol 1e-6, lines 29-30), non-numeric cells require identical type and value.
- Statuses recorded per case: `correct`, `incorrect_answer`, `generation_failure`, `safety_rejection`, `execution_failure`, `reference_error`.
- Summary includes generation/execution success rates, per-category accuracy, and generation/execution latency (mean/median/p95).
- **Output:** a timestamped JSON report `benchmarks/reports/sql_benchmark_<YYYYMMDD_HHMMSS>.json` (lines 402-407) containing model, DB SHA-256 fingerprint, per-case SQL, columns, row counts, timings and errors. **No such report exists in the repo** (directory absent; gitignored), so the README figures cannot be re-checked against a saved run.
- `--limit N` flag exists for smoke tests.
- The harness requires `data/sales.db` to exist (`FileNotFoundError` otherwise, lines 330-331) and a running Ollama with the model.

### 5.2 The older harnesses (5 cases each, stdout only, no files written)

| Script | Cases | Scoring | Notes |
| --- | --- | --- | --- |
| `scripts/benchmark_suite.py` | 5 (top-5 products, monthly revenue 2026, revenue by city, orders by status, top categories by quantity) | Execution-result equality; floats rounded to 2 dp; **columns not compared** | Own SCHEMA prompt; runs the same model twice |
| `scripts/benchmark_v2.py` | 5 (Sep/Oct revenue, top-10 customers, cancellation %, never-ordered products, top-2 per city) | Execution-result equality (floats 2 dp) + a `YYYY-MM` format check on the month column | Own SCHEMA prompt; runs the same model twice |
| `scripts/benchmark_hard.py` | 5 (Oct vs Sep revenue, top-10 customers, cancellation rate, never-ordered products, top customer per city) | Execution-result equality (floats 2 dp) | Own SCHEMA prompt; runs the same model twice |
| `scripts/benchmark_models.py` | 1 question | Prints response only; **no scoring at all** | Lists the same model twice; prints token counts/timing |
| `scripts/benchmark_ranking.py` | 1 question | Exact row equality vs a hand-built **in-memory** SQLite DB (7 customers, 7 orders) | Tests RANK() tie handling; no real DB needed |
| `scripts/validate_models.py` | 1 question | Exact row equality vs expected SQL run on the real DB | Lists the same model twice |

None of these five scripts is covered by tests, and none writes a results file.

### 5.3 The 30 benchmark cases (full table)

Category counts: **basic 5, filtering 5, aggregation 5, joins 5, ranking 5, advanced 5** (30 total). All have `"ordered": true`.

| ID | Category | Name | Question | Reference SQL |
| --- | --- | --- | --- | --- |
| B01 | basic | Total orders | How many orders are there? Return one column named total_orders. | `SELECT COUNT(*) AS total_orders FROM orders` |
| B02 | basic | Completed orders | How many orders have completed? Return one column named completed_orders. | `SELECT COUNT(*) AS completed_orders FROM orders WHERE status = 'completed'` |
| B03 | basic | Cancelled orders | How many orders are cancelled? Return one column named cancelled_orders. | `SELECT COUNT(*) AS cancelled_orders FROM orders WHERE status = 'cancelled'` |
| B04 | basic | Total customers | How many customers are in the database? Return one column named total_customers. | `SELECT COUNT(*) AS total_customers FROM customers` |
| B05 | basic | Total products | How many products are listed? Return one column named total_products. | `SELECT COUNT(*) AS total_products FROM products` |
| F01 | filtering | Orders in 2026 | Count orders placed in 2026. Return one column named orders_2026. | `SELECT COUNT(*) AS orders_2026 FROM orders WHERE order_date >= '2026-01-01' AND order_date < '2027-01-01'` |
| F02 | filtering | Completed orders in 2026 | Count completed orders placed in 2026. Return one column named completed_orders_2026. | `SELECT COUNT(*) AS completed_orders_2026 FROM orders WHERE status = 'completed' AND order_date >= '2026-01-01' AND order_date < '2027-01-01'` |
| F03 | filtering | Cancelled orders in 2025 | Count cancelled orders placed during 2025. Return one column named cancelled_2025. | `SELECT COUNT(*) AS cancelled_2025 FROM orders WHERE status = 'cancelled' AND order_date >= '2025-01-01' AND order_date < '2026-01-01'` |
| F04 | filtering | Orders in Delhi | Count orders placed by customers from Delhi. Return one column named delhi_orders. | `SELECT COUNT(*) AS delhi_orders FROM orders o JOIN customers c ON c.customer_id = o.customer_id WHERE c.city = 'Delhi'` |
| F05 | filtering | Processing or shipped orders | Count orders whose status is either processing or shipped. Return one column named active_orders. | `SELECT COUNT(*) AS active_orders FROM orders WHERE status IN ('processing', 'shipped')` |
| A01 | aggregation | Orders by status | Count orders for every status. Return status and order_count, highest count first, breaking ties alphabetically by status. | `SELECT status, COUNT(*) AS order_count FROM orders GROUP BY status ORDER BY order_count DESC, status ASC` |
| A02 | aggregation | Revenue by order status | Calculate total line-item revenue for each order status. Revenue is quantity multiplied by unit_price. Return status and revenue, highest revenue first. | `SELECT o.status, SUM(oi.quantity * oi.unit_price) AS revenue FROM orders o JOIN order_items oi ON oi.order_id = o.order_id GROUP BY o.status ORDER BY revenue DESC, o.status ASC` |
| A03 | aggregation | Average completed order value | Calculate the average total value per completed order. First total the line items within each order, then average those order totals. Return one column named average_order_value. | `WITH order_totals AS (SELECT o.order_id, SUM(oi.quantity * oi.unit_price) AS order_value FROM orders o JOIN order_items oi ON oi.order_id = o.order_id WHERE o.status = 'completed' GROUP BY o.order_id) SELECT AVG(order_value) AS average_order_value FROM order_totals` |
| A04 | aggregation | Monthly completed revenue | Calculate completed-order revenue for each month. Return month in YYYY-MM format and revenue, newest month first. | `SELECT SUBSTR(o.order_date, 1, 7) AS month, SUM(oi.quantity * oi.unit_price) AS revenue FROM orders o JOIN order_items oi ON oi.order_id = o.order_id WHERE o.status = 'completed' GROUP BY SUBSTR(o.order_date, 1, 7) ORDER BY month DESC` |
| A05 | aggregation | Quantity sold by category | Calculate the total quantity sold for each product category across all orders. Return category and quantity_sold, highest quantity first. | `SELECT p.category, SUM(oi.quantity) AS quantity_sold FROM products p JOIN order_items oi ON oi.product_id = p.product_id GROUP BY p.category ORDER BY quantity_sold DESC, p.category ASC` |
| J01 | joins | Revenue by customer city | Calculate revenue from completed orders for each customer city. Return city and revenue, highest revenue first. | `SELECT c.city, SUM(oi.quantity * oi.unit_price) AS revenue FROM customers c JOIN orders o ON o.customer_id = c.customer_id JOIN order_items oi ON oi.order_id = o.order_id WHERE o.status = 'completed' GROUP BY c.city ORDER BY revenue DESC, c.city ASC` |
| J02 | joins | Product revenue | Calculate total sales revenue for every product across all order statuses. Return product_id, product_name and revenue, highest revenue first. | `SELECT p.product_id, p.product_name, SUM(oi.quantity * oi.unit_price) AS revenue FROM products p JOIN order_items oi ON oi.product_id = p.product_id GROUP BY p.product_id, p.product_name ORDER BY revenue DESC, p.product_id ASC` |
| J03 | joins | Customer order counts | Show every customer who has placed at least one order. Return customer_id, name and order_count, highest count first and customer_id ascending for ties. | `SELECT c.customer_id, c.name, COUNT(o.order_id) AS order_count FROM customers c JOIN orders o ON o.customer_id = c.customer_id GROUP BY c.customer_id, c.name ORDER BY order_count DESC, c.customer_id ASC` |
| J04 | joins | Order item totals | For each order, calculate its total line-item value. Return order_id and order_value, highest value first, limited to 10 orders. | `SELECT order_id, SUM(quantity * unit_price) AS order_value FROM order_items GROUP BY order_id ORDER BY order_value DESC, order_id ASC LIMIT 10` |
| J05 | joins | Customer latest order date | Show each customer who has placed an order and their most recent order date. Return customer_id, name and latest_order_date, newest date first. | `SELECT c.customer_id, c.name, MAX(o.order_date) AS latest_order_date FROM customers c JOIN orders o ON o.customer_id = c.customer_id GROUP BY c.customer_id, c.name ORDER BY latest_order_date DESC, c.customer_id ASC` |
| R01 | ranking | Top five products by revenue | Show the top 5 products by total sales revenue across all order statuses. Return product_name and total_sales_revenue, highest first. | `SELECT p.product_name, SUM(oi.quantity * oi.unit_price) AS total_sales_revenue FROM order_items oi JOIN products p ON p.product_id = oi.product_id GROUP BY p.product_id, p.product_name ORDER BY total_sales_revenue DESC, p.product_name ASC LIMIT 5` |
| R02 | ranking | Top ten customers by completed spending | Find the top 10 customers by revenue from completed orders. Return customer_id, name and total_spending, highest first, breaking ties by customer_id ascending. | `SELECT c.customer_id, c.name, SUM(oi.quantity * oi.unit_price) AS total_spending FROM customers c JOIN orders o ON o.customer_id = c.customer_id JOIN order_items oi ON oi.order_id = o.order_id WHERE o.status = 'completed' GROUP BY c.customer_id, c.name ORDER BY total_spending DESC, c.customer_id ASC LIMIT 10` |
| R03 | ranking | Top five customers by order count | Find the top 5 customers by number of orders. Return customer_id, name and order_count, highest count first, breaking ties by customer_id ascending. | `SELECT c.customer_id, c.name, COUNT(o.order_id) AS order_count FROM customers c JOIN orders o ON o.customer_id = c.customer_id GROUP BY c.customer_id, c.name ORDER BY order_count DESC, c.customer_id ASC LIMIT 5` |
| R04 | ranking | Top categories by revenue | Rank product categories by total sales revenue across all orders. Return category and revenue, highest first. | `SELECT p.category, SUM(oi.quantity * oi.unit_price) AS revenue FROM products p JOIN order_items oi ON oi.product_id = p.product_id GROUP BY p.category ORDER BY revenue DESC, p.category ASC` |
| R05 | ranking | Top three cities by completed revenue | Find the top 3 customer cities by revenue from completed orders. Return city and revenue, highest first. | `SELECT c.city, SUM(oi.quantity * oi.unit_price) AS revenue FROM customers c JOIN orders o ON o.customer_id = c.customer_id JOIN order_items oi ON oi.order_id = o.order_id WHERE o.status = 'completed' GROUP BY c.city ORDER BY revenue DESC, c.city ASC LIMIT 3` |
| X01 | advanced | Cancellation rate | Calculate the cancellation rate as a percentage of all orders. Return total_orders, cancelled_orders and cancellation_rate_pct, rounded to two decimal places. | `SELECT COUNT(*) AS total_orders, SUM(CASE WHEN status = 'cancelled' THEN 1 ELSE 0 END) AS cancelled_orders, ROUND(100.0 * SUM(CASE WHEN status = 'cancelled' THEN 1 ELSE 0 END) / NULLIF(COUNT(*), 0), 2) AS cancellation_rate_pct FROM orders` |
| X02 | advanced | Top two customers per city with ties | For each city, find the top two customers by completed-order revenue. Return city, customer_id, name, revenue and rank_in_city. Use RANK so ties at rank 2 are included. Sort by city, rank_in_city and customer_id. | `WITH customer_revenue AS (SELECT c.city, c.customer_id, c.name, SUM(oi.quantity * oi.unit_price) AS revenue FROM customers c JOIN orders o ON o.customer_id = c.customer_id JOIN order_items oi ON oi.order_id = o.order_id WHERE o.status = 'completed' GROUP BY c.city, c.customer_id, c.name), ranked AS (SELECT city, customer_id, name, revenue, RANK() OVER (PARTITION BY city ORDER BY revenue DESC) AS rank_in_city FROM customer_revenue) SELECT city, customer_id, name, revenue, rank_in_city FROM ranked WHERE rank_in_city <= 2 ORDER BY city, rank_in_city, customer_id` |
| X03 | advanced | Products never ordered | Find products that have never appeared in order_items. Return product_id and product_name, ordered by product_id ascending. | `SELECT p.product_id, p.product_name FROM products p WHERE NOT EXISTS (SELECT 1 FROM order_items oi WHERE oi.product_id = p.product_id) ORDER BY p.product_id` |
| X04 | advanced | Monthly revenue comparison | For completed orders in September and October 2026, return month in YYYY-MM format and revenue, newest month first. | `SELECT SUBSTR(o.order_date, 1, 7) AS month, SUM(oi.quantity * oi.unit_price) AS revenue FROM orders o JOIN order_items oi ON oi.order_id = o.order_id WHERE o.status = 'completed' AND SUBSTR(o.order_date, 1, 7) IN ('2026-09', '2026-10') GROUP BY SUBSTR(o.order_date, 1, 7) ORDER BY month DESC` |
| X05 | advanced | Order status percentage | Calculate the percentage of all orders represented by each status. Return status and percentage_of_orders rounded to two decimal places, highest percentage first. | `SELECT status, ROUND(100.0 * COUNT(*) / (SELECT COUNT(*) FROM orders), 2) AS percentage_of_orders FROM orders GROUP BY status ORDER BY percentage_of_orders DESC, status ASC` |

Notes on the cases themselves (verified from `sql_cases.json` + `create_database.py`):
- Several questions pin the output column names exactly (B01–B05, F01–F05, R01) — this is why the alias-contract rules in the production prompt exist, and why scoring requires exact column-name equality.
- X03's reference query returns **zero rows** on the generated database: every one of the 10 products appears in `order_items` (completed-order targets cover products 1,2,3,4,6,7,9; the 265 non-completed orders get 1–4 random products each). An empty-vs-empty comparison still counts as correct under `rows_equal`.
- The data spans 2025-01-01 to 2026-10-26 (`create_database.py:169-174`: start 2025-01-01 + 0–663 days), so the 2026 questions (F01, F02, X04) have non-empty answers.
- The reference SQL was presumably written by the author, not independently validated — there is no test that checks the reference queries themselves except by executing them (a `reference_error` status exists for that).

### 5.4 The 28/30 and 27/30 figures — status

| Claim (README.md:155-167) | In-repo evidence |
| --- | --- |
| "Initial baseline 28/30 = 93.33%" | **None.** No report file, no log, no list of which 2 cases failed, no baseline prompt text. |
| "After prompt modification 27/30 = 90%" | **None.** No report file, no log, no list of which 3 cases failed, no description of the modification. |
| "The second run was lower… should not be read as an improvement" | README's own caveat; correct as far as it goes, but the numbers themselves are unverifiable from the repo. |
| "These results come from a small custom benchmark, not a standardized evaluation. Model output can vary between runs." | Accurate; temperature 0 reduces but does not eliminate run-to-run variation (Ollama builds, hardware, batching can change outputs). |
| Per-category breakdown for either run | **Does not exist anywhere in the repo.** |

The harness *can* reproduce a run (given Ollama + model + generated DB), but the two historical numbers cannot be audited. A paper should report them as author-reported, single-run, unaudited figures — or, better, re-run the harness and report the fresh run with its saved JSON report.

---

## 6. Database generator — verified in code

`scripts/create_database.py` (seed `RANDOM_SEED = 42`, line 8; deterministic).

**Schema** (`_create_schema`, lines 66-115) — 4 tables, 4 indexes:

- `customers(customer_id INTEGER PRIMARY KEY, name TEXT NOT NULL, city TEXT NOT NULL)`
- `products(product_id INTEGER PRIMARY KEY, product_name TEXT NOT NULL, category TEXT NOT NULL, unit_price REAL NOT NULL CHECK (unit_price >= 0))`
- `orders(order_id INTEGER PRIMARY KEY, customer_id INTEGER NOT NULL, order_date TEXT NOT NULL, status TEXT NOT NULL CHECK (status IN ('completed','shipped','processing','cancelled')), FOREIGN KEY (customer_id) REFERENCES customers(customer_id))`
- `order_items(order_item_id INTEGER PRIMARY KEY, order_id INTEGER NOT NULL, product_id INTEGER NOT NULL, quantity INTEGER NOT NULL CHECK (quantity > 0), unit_price REAL NOT NULL CHECK (unit_price >= 0), FKs to orders/products)`
- Indexes: `idx_orders_date`, `idx_orders_customer`, `idx_order_items_order`, `idx_order_items_product`.

**Counts — verified in code and cross-checked by the test assertions** (`tests/test_create_database.py:35-44`):

| Table | Claimed | In code | Test asserts |
| --- | --- | --- | --- |
| customers | 20 | `CUSTOMERS` list, 20 entries (lines 10-31) | 20 |
| products | 10 | `PRODUCTS` list, 10 entries (lines 33-44) | 10 |
| orders | 500 | `STATUS_COUNTS` 102+235+85+78 = 500 (lines 46-51) | 500 |
| order_items | — | derived; deterministic given seed 42 | **927** |

Status split: cancelled 102, completed 235, processing 85, shipped 78. Dates: 2025-01-01 + 0–663 random days (through 2026-10-26). Completed-order line items are deliberately shaped by `COMPLETED_PRODUCT_TARGETS` (lines 54-62) so the benchmark's expected top-products output is stable; remaining completed orders get products 2/3, non-completed orders get 1–4 random items. `PRAGMA foreign_keys = ON` during generation; re-running drops and recreates all four tables (idempotent, no duplication). The generator prints counts to stdout; it does not write a manifest or hash.

---

## 7. Test suite

**Counts verified by grep:** 180 `def test_*` functions across 15 files; 27 `subTest` iterations (24 in `test_agent.py` — 4 allowed actions + 8 denied actions + 3 dangerous functions + 5 aggregate functions + 4 empty/non-string responses — and 3 in `test_recommendations.py` for NaN/±inf thresholds). These counts match the README claim "180 passed, with 27 subtests passed" (`README.md:148-150`) — **but the pass status itself was not verified here**: pytest is not installed in this VM, the database does not exist here, and no repo code was executed. The README itself calls it "a historical result, not a guarantee".

| Test file | Tests | What it covers |
| --- | --- | --- |
| `test_agent.py` | 42 | Deterministic summaries (₹ formatting), SQL safety denylist, real-DB result assertions (500 orders, status counts, top-5 completed products with exact ₹ values), `ask()` with mocked LLM, empty/over-long questions, row-limit, authorizer allow/deny matrix, query deadline interrupt, SQL-response extraction edge cases |
| `test_business_evidence.py` | 24 | Monthly comparison / evidence status logic |
| `test_create_database.py` | 2 | Schema + exact counts (20/10/500/927), FK integrity, idempotent re-run (uses `tmp_path`, no real DB needed) |
| `test_dashboard_builder.py` | 4 | Dashboard profile integration |
| `test_full_data_loaders.py` | 3 | CSV/Excel upload loading (`FakeUpload`) |
| `test_insight_explainer.py` | 17 | Explanation validation logic |
| `test_insight_quality.py` | 3 | Insight quality checks |
| `test_insights.py` | 12 | Factual insight calculation |
| `test_month_over_month.py` | 15 | Month-over-month change analysis |
| `test_order_recommendations.py` | 6 | Order recommendations |
| `test_profiling.py` | 15 | Dataframe profiling |
| `test_recommendations.py` | 15 | Recommendation generation, incl. non-finite threshold rejection |
| `test_root_cause.py` | 11 | Root-cause brief building/validation |
| `test_sales_dashboard.py` | 6 | Joined sales data (needs real `data/sales.db`) |
| `test_saved_dashboards.py` | 5 | Save/list/load/delete of dashboard presets (temp dir) |

### What the tests do NOT cover

- **No live Ollama call anywhere in the suite.** `generate_sql` and `explain_results` are `@patch`-mocked in the `ask()` tests (`test_agent.py:178-180, 218-219, 227-229`); no test exercises the real model, prompt, or HTTP path. A broken prompt or a changed model would not fail any test.
- **No tests for `dashboard.py`** (the Streamlit UI) and no test imports Streamlit at all.
- **No tests for any benchmark script** — the scoring logic in `run_sql_benchmark.py` (`rows_equal`, `values_equal`, column matching) is untested.
- **No tests for the live Ollama paths** in `generate_dashboard_plan` or `explain_factual_insights`.
- **No end-to-end test** of question → SQL → results → explanation.
- **DB-dependent tests assume `data/sales.db` already exists:** `test_agent.py` `TestDatabaseResults` and `test_sales_dashboard.py` `setUpClass` read the real DB path. On a fresh clone (DB is gitignored) these fail until `python3 scripts/create_database.py` is run — the README does document that step, but there is no test fixture that creates the DB.
- **Quirk:** `tests/test_agent.py:191` has an `if __name__ == "__main__": unittest.main()` block in the *middle* of the file; the four test classes defined after it (`TestEdgeCases`, `TestReadOnlyAuthorizer`, `TestQueryDeadline`, `TestSQLResponseExtraction`) would be **skipped when running `python tests/test_agent.py` directly**. Pytest imports the whole module, so `pytest -q` runs all 42 — but the direct-run path silently drops 15 tests.

---

## 8. Application surface (what else the code does)

- **`dashboard.py`** — Streamlit chat UI: greeting handler, quick-command buttons, three "mission" buttons, per-answer result rendering (table + bar/line/area chart + CSV export + "Inspect generated SQL" expander), Dashboard Studio expander, Sales Intelligence expander. No authentication, no per-user state (Streamlit `session_state` only). The sidebar shows **static** status text — "Agent ready", "Morrow Core online · Data source ready" (`dashboard.py:282,300`) — which is hardcoded markup, not a health check; it displays even if Ollama is down or the DB is missing. The page also loads Google Fonts via `@import` (`dashboard.py:22`), i.e. the "local-first" UI still fetches fonts from the network at runtime.
- **`app/sales_dashboard.py`** — deterministic (no LLM): read-only join of the four tables (`load_sales_data`, lines 21-60), KPI cards, monthly/product/status/category charts, a monthly-vs-filtered revenue reconciliation check, CSV export. Saved filter presets via `app/saved_dashboards.py` (names validated by regex `^[\w .()-]{1,80}$` and stored under a SHA-256 filename, lines 12-24 — no path traversal).
- **`app/dashboard_builder.py`** — uploads: CSV/XLSX/XLSM only, 25 MB cap (`MAX_UPLOAD_BYTES`, line 23), 5000-row preview cap; SQLite via read-only connection with table allow-listing. Dashboard plans come from Ollama (`format: "json"`) and are sanitised by `_safe_plan` before rendering.
- **`app/profiling.py` / `insights.py` / `recommendations.py` / `root_cause.py` / `business_evidence.py` / `insight_explainer.py`** — deterministic pandas computations plus (only in `insight_explainer.py`) one LLM call whose output is validated against the supplied facts.
- **No auth, no deployment:** no login, sessions, roles, rate limiting, Dockerfile, compose file, systemd unit, or hosting config anywhere. `requirements.txt` has no web server beyond Streamlit. `.streamlit/` config does not exist in the repo. The README's Limitations section states this plainly.

---

## 9. Limitations in code / overclaim risks

1. **Benchmark figures are unaudited.** 28/30 and 27/30 exist only in the README; no report, log, failing-case list, or baseline prompt in the repo (§5.4). Do not present them as a controlled experiment.
2. **Single-run, n=30, custom cases.** The README says this; the code confirms it — one author-written case file, no held-out set, no confidence interval, no repeat runs recorded.
3. **No model comparison despite the scaffolding.** Every `MODELS = [...]` list repeats the same model twice; "benchmark_models" / "validate_models" compare the model against itself.
4. **Temperature 0 ≠ deterministic.** Scores can shift between runs / Ollama versions / hardware; the README notes output "can vary between runs".
5. **Reference SQL is author-written, not independently validated.** A wrong reference would mark correct model output as incorrect (or vice versa for X03's empty result).
6. **Scoring is strict on column names and row order.** A semantically correct query with a different alias or tie order fails. This is by design, but it means the score measures exact-output compliance, not just SQL correctness.
7. **Static "online/ready" UI text** (`dashboard.py:282,300`) overstates system state — no health check behind it.
8. **Local-only by construction.** Hardcoded `http://localhost:11434`; no auth; anyone who can reach the Streamlit port can query the local DB (read-only, but unrestricted). Not deployable as-is.
9. **DB is synthetic and small.** 500 orders, 20 customers, 10 products, seeded RNG — results say nothing about performance or accuracy on real, messy, or larger data. `MAX_ROWS = 200` and the 5-second query cap would also bite on bigger data.
10. **"AI" scope is narrow.** Only two LLM call sites do analysis (SQL generation + result explanation); the dashboards, insights, recommendations and root-cause features are deterministic pandas code, and the insight-explainer LLM output is post-validated. Calling the whole app "AI-powered" is defensible but the deterministic parts should not be described as model outputs.
11. **Minor code issues:** `test_agent.py:191` mid-file `unittest.main()` (§7); `_extract_sql_response`'s `EXPLAIN` check runs without the authorizer (§4); `scripts/inspect_schema.py` executes on import (top-level code, no `main` guard) and crashes if the DB is absent; Google Fonts `@import` in `dashboard.py:22` is an external runtime dependency; `dashboard_builder.py` truncates the user's dashboard question to 1000 chars silently (line 149).
12. **No license.** README: "No open-source license has been selected yet. All rights reserved by default." — the code cannot be redistributed or reused without permission; a paper built on it should note this.

---

## 10. Environment check (this VM)

Commands tried 2026-11-22:

| Check | Result |
| --- | --- |
| `which ollama` | **Not found** (exit 1) |
| `ollama list` | `ollama: command not found` |
| `curl -m 5 http://localhost:11434/api/tags` | **HTTP 000, exit 7 (connection refused)** — nothing listening on port 11434 |
| `qwen3.5:4b-q4_K_M` model | **Not available** — Ollama itself is absent, so no models exist here |
| Python | 3.12.3 present |
| `pip list` | pandas 2.1.4, plotly 5.15.0 installed (NOT the pinned pandas==3.1.0 / plotly==7.1.0); **streamlit and pytest are not installed** |

**Consequence:** the benchmark cannot be reproduced in this VM without installing Ollama, pulling `qwen3.5:4b-q4_K_M`, installing the pinned dependencies, and generating `data/sales.db`. Nothing in this report's numbers was re-run here.

---

## 11. Verified vs README-only

| Claim | Status |
| --- | --- |
| Model `qwen3.5:4b-q4_K_M`, local Ollama | **Verified in code** (`app/agent.py:12-13`, all benchmark scripts) |
| Temperature 0, `think: False`, `num_predict` 400/180/1200/500 | **Verified in code** |
| Read-only SQL guard (keyword denylist + `mode=ro` + `query_only` + authorizer + 200-row cap + 5 s deadline) | **Verified in code** (`app/agent.py:74-111, 179-215, 367-422`) |
| 30 benchmark cases, 6 categories × 5, with reference SQL | **Verified in code** (`benchmarks/sql_cases.json`) |
| Scoring = execution-result comparison (columns + ordered rows, numeric tolerance) | **Verified in code** (`scripts/run_sql_benchmark.py:88-130, 155-244`) |
| DB generator: 20 customers / 10 products / 500 orders; schema as documented | **Verified in code** (`scripts/create_database.py`); order_items = 927 (test assertion) |
| 180 tests + 27 subtests | **Count verified in code**; pass status not re-run here |
| "180 passed" | **README-only** (historical result; not reproduced in this VM) |
| Baseline 28/30 = 93.33% | **README-only** — no report, log, failing cases, or baseline prompt in repo |
| After prompt modification 27/30 = 90% | **README-only** — same; the modification itself is not documented in the repo |
| Per-category benchmark breakdown | **Does not exist** in repo or README |
| "Local-first / local prototype" | **Verified** — localhost Ollama, local SQLite, no deployment config; minor exception: Google Fonts fetched at runtime |
| No auth / no deployment | **Verified** — none present in code |

---

## 12. Discrepancies found vs README claims

1. **Benchmark numbers have no supporting artefacts.** README reports two runs; the repo contains no report files, no logs, and no record of which cases failed or what the prompt change was. The harness writes reports to `benchmarks/reports/`, which is gitignored — so even the author's own run outputs were never committed.
2. **No baseline prompt exists in the repo.** The README's "after prompt modification" implies a before/after, but only one production prompt is stored; the three older scripts each carry a different prompt, with no mapping to either reported run.
3. **Model-comparison scaffolding is hollow.** Scripts named `benchmark_models` / `validate_models` and the `MODELS` lists suggest multi-model evaluation, but every list contains the same model twice.
4. **README's "180 passed, 27 subtests" is plausible but stale.** The counts match the code exactly (180 `def test_*`, 27 subtests), but the pass claim is a historical result that cannot be re-run from a fresh clone without first generating the DB, and `python tests/test_agent.py` run directly would silently skip 15 tests due to the mid-file `unittest.main()` at line 191.
5. **README says "SQL generation depends on the locally configured Ollama model" — accurate, but understates the dependency:** the app cannot answer any question without Ollama running, and the sidebar nevertheless displays "Morrow Core online" unconditionally.
6. **No factual errors found in the README's structural claims** (stack, file layout, DB counts, limitations). The gaps are all about evidence for the two benchmark scores, not about what the code does.
