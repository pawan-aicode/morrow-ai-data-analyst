"""Dedicated tests for the benchmark scoring engine.

The 180-test suite covers the app and the database builders, but nothing
covered scoring itself (scripts/run_sql_benchmark.py: values_equal,
rows_equal, fetch_reference, and the column-match rule used by
evaluate_case). Added 23 Nov 2026 as part of the Morrow v4 experimental
phase, after the first blind validation found scoring-validity issues
(un-stated tie-breaks) in the benchmark questions.

What is tested here:
  - column names and column order (fetch_reference returns them in
    SELECT order; evaluate_case requires exact list equality, so a
    correct-values/wrong-alias answer is NOT correct);
  - numeric tolerance (int/float equivalence, abs/rel bounds, strict
    type checks for str-vs-int and bool-vs-int, None handling);
  - duplicate rows in ordered and unordered comparison;
  - empty result sets;
  - tied rankings: ordered comparison penalises a tie-order swap,
    unordered comparison does not;
  - ordered vs unordered results;
  - correct values with incorrect aliases (rows match, columns do not,
    so the answer is incorrect);
  - incorrect values with otherwise correct output shape.

One real bug found by these tests (23 Nov 2026, see
test_unordered_greedy_tolerance_edge): rows_equal's unordered branch
used greedy first-fit matching, which returns False when a perfect
matching exists but the first expected row consumes the only actual row
a later expected row can match (values within numeric tolerance of
each other). Fixed in run_sql_benchmark.py with maximum bipartite
matching (Kuhn's algorithm). Impact on earlier scores: NONE — every
case in the expanded benchmarks (v1, v2, v3) has ordered=True, so the
unordered branch never executes in benchmark scoring; and all stored
run results are unaffected.
"""
import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "scripts"))

from run_sql_benchmark import fetch_reference, rows_equal, values_equal


def column_match(expected_columns, actual_columns):
    """The exact rule evaluate_case uses for column_match."""
    return actual_columns == expected_columns


class TestValuesEqual(unittest.TestCase):
    def test_int_float_equivalent(self):
        self.assertTrue(values_equal(500, 500.0))
        self.assertTrue(values_equal(225000, 225000.0))

    def test_within_absolute_tolerance(self):
        # abs_tol is 1e-6: 5e-7 apart counts as equal.
        self.assertTrue(values_equal(100.0, 100.0000005))

    def test_at_absolute_tolerance_boundary(self):
        # Exactly 1e-6 apart: math.isclose treats <= tol as close.
        self.assertTrue(values_equal(100.0, 100.000001))

    def test_outside_tolerance(self):
        self.assertFalse(values_equal(100.0, 100.001))
        self.assertFalse(values_equal(100.0, 100.000002))

    def test_relative_tolerance_large_values(self):
        # rel_tol 1e-9: 1e-3 apart on ~1e6 is far outside.
        self.assertFalse(values_equal(19452100.0, 19452101.0))

    def test_str_vs_int_not_equal(self):
        # '2025' (strftime year) vs 2025 must not count as equal.
        self.assertFalse(values_equal("2025", 2025))
        self.assertFalse(values_equal(2025, "2025"))

    def test_bool_vs_int_not_equal(self):
        self.assertFalse(values_equal(True, 1))
        self.assertFalse(values_equal(1, True))
        self.assertFalse(values_equal(False, 0))

    def test_none_handling(self):
        self.assertTrue(values_equal(None, None))
        self.assertFalse(values_equal(None, 0))
        self.assertFalse(values_equal(0, None))

    def test_strings_exact(self):
        self.assertTrue(values_equal("Mumbai", "Mumbai"))
        self.assertFalse(values_equal("Mumbai", "mumbai"))
        self.assertFalse(values_equal("Mumbai", "Delhi"))

    def test_list_values_compare_by_content(self):
        # Non-numeric cells compare by exact type + equality.
        self.assertTrue(values_equal([1], [1]))
        self.assertFalse(values_equal([1], (1,)))


class TestRowsEqualOrdered(unittest.TestCase):
    def test_identical_rows(self):
        self.assertTrue(rows_equal([[1, "a"], [2, "b"]], [[1, "a"], [2, "b"]], True))

    def test_reversed_rows_fail_when_ordered(self):
        self.assertFalse(rows_equal([[1], [2]], [[2], [1]], True))

    def test_tied_ranking_swap_fails_when_ordered(self):
        # R07/R11/J08/X08 shape: tied rows in the other order are scored
        # wrong by an order-sensitive comparison. After the v3 fix the
        # question states the tie-break, so this behaviour is intended —
        # but the test pins it so a future scorer change is deliberate.
        expected = [["Monitor 27 inch", 276], ["Office Chair", 276]]
        swapped = [["Office Chair", 276], ["Monitor 27 inch", 276]]
        self.assertFalse(rows_equal(expected, swapped, True))

    def test_different_row_count_fails(self):
        self.assertFalse(rows_equal([[1], [2]], [[1]], True))
        self.assertFalse(rows_equal([[1]], [[1], [2]], True))

    def test_duplicate_rows_ordered(self):
        self.assertTrue(rows_equal([[1], [1], [2]], [[1], [1], [2]], True))
        self.assertFalse(rows_equal([[1], [1], [2]], [[1], [2], [1]], True))

    def test_numeric_tolerance_applies_per_cell(self):
        self.assertTrue(rows_equal([[100.0]], [[100.0000005]], True))
        self.assertFalse(rows_equal([[100.0]], [[100.001]], True))

    def test_ragged_rows_fail(self):
        self.assertFalse(rows_equal([[1, 2]], [[1]], True))


class TestRowsEqualUnordered(unittest.TestCase):
    def test_reversed_rows_pass_when_unordered(self):
        self.assertTrue(rows_equal([[1], [2]], [[2], [1]], False))

    def test_tied_ranking_swap_passes_when_unordered(self):
        expected = [["Monitor 27 inch", 276], ["Office Chair", 276]]
        swapped = [["Office Chair", 276], ["Monitor 27 inch", 276]]
        self.assertTrue(rows_equal(expected, swapped, False))

    def test_duplicate_rows_unordered(self):
        self.assertTrue(rows_equal([[1], [1], [2]], [[1], [2], [1]], False))
        # One duplicated value too few / too many must fail.
        self.assertFalse(rows_equal([[1], [1], [2]], [[1], [2], [2]], False))
        self.assertFalse(rows_equal([[1], [2], [2]], [[1], [1], [2]], False))

    def test_empty_result_sets(self):
        self.assertTrue(rows_equal([], [], False))
        self.assertTrue(rows_equal([], [], True))
        self.assertFalse(rows_equal([], [[1]], False))
        self.assertFalse(rows_equal([[1]], [], False))

    def test_unordered_greedy_tolerance_edge(self):
        # REGRESSION (bug found 23 Nov 2026): a perfect matching exists —
        # 100.0 -> 100.0000005 (diff 5e-7) and 100.000002 -> 100.000001
        # (diff 1e-6) — but greedy first-fit lets 100.0 consume
        # 100.000001, leaving 100.000002 with no match. Must be True.
        expected = [[100.0], [100.000002]]
        actual = [[100.000001], [100.0000005]]
        self.assertTrue(rows_equal(expected, actual, False))

    def test_unordered_no_match_still_fails(self):
        self.assertFalse(rows_equal([[100.0]], [[100.01]], False))
        self.assertFalse(rows_equal([["Mumbai"]], [["Delhi"]], False))


class TestColumnMatch(unittest.TestCase):
    def test_column_names_exact(self):
        self.assertTrue(column_match(["total_orders"], ["total_orders"]))
        self.assertFalse(column_match(["total_orders"], ["total"]))

    def test_column_order_matters(self):
        self.assertFalse(
            column_match(["city", "order_count"], ["order_count", "city"])
        )

    def test_column_case_matters(self):
        self.assertFalse(column_match(["total_orders"], ["Total_Orders"]))

    def test_correct_values_wrong_alias_is_incorrect(self):
        # Rows match, columns do not: the answer is incorrect because
        # evaluate_case requires column_match AND rows_match.
        expected_columns = ["revenue"]
        actual_columns = ["total_revenue"]
        expected_rows = [[19452100.0]]
        actual_rows = [[19452100.0]]
        self.assertTrue(rows_equal(expected_rows, actual_rows, True))
        self.assertFalse(column_match(expected_columns, actual_columns))
        self.assertFalse(
            column_match(expected_columns, actual_columns)
            and rows_equal(expected_rows, actual_rows, True)
        )

    def test_incorrect_values_correct_shape_is_incorrect(self):
        expected_columns = ["city", "order_count"]
        actual_columns = ["city", "order_count"]
        expected_rows = [["Mumbai", 54], ["Delhi", 48]]
        actual_rows = [["Mumbai", 54], ["Delhi", 47]]  # one value off
        self.assertTrue(column_match(expected_columns, actual_columns))
        self.assertFalse(rows_equal(expected_rows, actual_rows, True))


class TestFetchReference(unittest.TestCase):
    def test_columns_in_select_order(self):
        columns, rows = fetch_reference(
            "SELECT COUNT(*) AS total_orders FROM orders"
        )
        self.assertEqual(columns, ["total_orders"])
        self.assertEqual(len(rows), 1)
        self.assertEqual(rows[0][0], 500)

    def test_empty_result_set_columns_still_returned(self):
        # X03: every product appears in order_items, so 0 rows — but the
        # column names must still be reported for the column check.
        columns, rows = fetch_reference(
            "SELECT p.product_id, p.product_name FROM products p "
            "WHERE NOT EXISTS (SELECT 1 FROM order_items oi "
            "WHERE oi.product_id = p.product_id) ORDER BY p.product_id"
        )
        self.assertEqual(columns, ["product_id", "product_name"])
        self.assertEqual(rows, [])


if __name__ == "__main__":
    unittest.main()
