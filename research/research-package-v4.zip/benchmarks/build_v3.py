#!/usr/bin/env python3
"""Build Morrow expanded benchmark v3 from frozen v2.

v3 fixes the six AMBIGUOUS cases from the first blind reference validation
(research/reference_validation_v1_v2.md) by stating an explicit,
deterministic tie-break in each question text. The tie-break in every case
is the one the v2 reference SQL ALREADY uses, so NO reference SQL changes,
NO expected row changes, and NO case is removed (all 90 stay).

  J05: newest date first -> + ", breaking ties by customer_id ascending"
       (ref: ORDER BY latest_order_date DESC, c.customer_id ASC)
  J08: highest quantity first -> + ", breaking ties by product_id ascending"
       (ref: ORDER BY quantity_sold DESC, p.product_id ASC)
  R07: highest count first -> + ", breaking ties alphabetically by city"
       (ref: ORDER BY order_count DESC, c.city ASC)
  R11: highest first -> + ", breaking ties alphabetically by product name"
       (ref: ORDER BY quantity_sold DESC, p.product_name ASC)
  R14: highest value first -> + ", breaking ties by order_id ascending"
       (ref: ORDER BY order_value DESC, order_id ASC)
       SEVERE case: 19 completed orders tie at 225000.0; the stated
       order_id tie-break makes the reference's 5 (1, 18, 32, 80, 214)
       the unique correct answer.
  X08: highest rate first -> + ", breaking ties alphabetically by city"
       (ref: ORDER BY cancellation_rate_pct DESC, c.city ASC)

Verification (this script): every v3 reference SQL is executed read-only
against the seed-42 sales.db; 90/90 must execute, and every case's result
(columns + rows, exact order) must be byte-identical to the v2 result.

Outputs (v1/v2 untouched):
  research/benchmarks/expanded_benchmark_v3.json
  research/benchmarks/expanded_benchmark_v3.csv
"""
import csv
import hashlib
import json
import sqlite3
import sys
from pathlib import Path

WORK = Path("/home/hatch/workspace/research/morrow-handoff/work")
BENCH = WORK / "research" / "benchmarks"
DB = WORK / "code" / "data" / "sales.db"

CHANGES = {
    "J05": (
        "Show each customer who has placed an order and their most recent order date. "
        "Return customer_id, name and latest_order_date, newest date first.",
        "Show each customer who has placed an order and their most recent order date. "
        "Return customer_id, name and latest_order_date, newest date first, "
        "breaking ties by customer_id ascending.",
        "ORDER BY latest_order_date DESC, c.customer_id ASC",
    ),
    "J08": (
        "Calculate the total quantity sold for every product across all orders. "
        "Return product_id, product_name and quantity_sold, highest quantity first.",
        "Calculate the total quantity sold for every product across all orders. "
        "Return product_id, product_name and quantity_sold, highest quantity first, "
        "breaking ties by product_id ascending.",
        "ORDER BY quantity_sold DESC, p.product_id ASC",
    ),
    "R07": (
        "Find the top 5 customer cities by number of orders. "
        "Return city and order_count, highest count first.",
        "Find the top 5 customer cities by number of orders. "
        "Return city and order_count, highest count first, "
        "breaking ties alphabetically by city.",
        "ORDER BY order_count DESC, c.city ASC",
    ),
    "R11": (
        "Show the top 5 products by total quantity sold across all orders. "
        "Return product_name and quantity_sold, highest first.",
        "Show the top 5 products by total quantity sold across all orders. "
        "Return product_name and quantity_sold, highest first, "
        "breaking ties alphabetically by product name.",
        "ORDER BY quantity_sold DESC, p.product_name ASC",
    ),
    "R14": (
        "Find the top 5 completed orders by total line-item value. "
        "Return order_id and order_value, highest value first.",
        "Find the top 5 completed orders by total line-item value. "
        "Return order_id and order_value, highest value first, "
        "breaking ties by order_id ascending.",
        "ORDER BY order_value DESC, order_id ASC",
    ),
    "X08": (
        "For each customer city, calculate the cancellation rate as a percentage "
        "of that city's orders. Return city, total_orders, cancelled_orders and "
        "cancellation_rate_pct rounded to two decimal places, highest rate first.",
        "For each customer city, calculate the cancellation rate as a percentage "
        "of that city's orders. Return city, total_orders, cancelled_orders and "
        "cancellation_rate_pct rounded to two decimal places, highest rate first, "
        "breaking ties alphabetically by city.",
        "ORDER BY cancellation_rate_pct DESC, c.city ASC",
    ),
}

NOTE = {
    "J05": "v3 (23 Nov 2026): question now states the tie-break the reference SQL already used "
           "(customer_id ascending). Four pairs of customers share the same latest order date; "
           "previously AMBIGUOUS (first blind validation), now uniquely determined. Reference SQL unchanged.",
    "J08": "v3 (23 Nov 2026): question now states the tie-break the reference SQL already used "
           "(product_id ascending). Monitor 27 inch and Office Chair tie at 276 units; "
           "previously AMBIGUOUS, now uniquely determined. Reference SQL unchanged.",
    "R07": "v3 (23 Nov 2026): question now states the tie-break the reference SQL already used "
           "(city ascending). Bhopal and Goa tie at 31 orders; previously AMBIGUOUS, "
           "now uniquely determined. Reference SQL unchanged.",
    "R11": "v3 (23 Nov 2026): question now states the tie-break the reference SQL already used "
           "(product_name ascending). Monitor 27 inch and Office Chair tie at 276 units; "
           "previously AMBIGUOUS, now uniquely determined. Reference SQL unchanged. "
           "(product_id ascending gives the same order here.)",
    "R14": "v3 (23 Nov 2026): question now states the tie-break the reference SQL already used "
           "(order_id ascending). SEVERE case: 19 completed orders tie at the maximum value "
           "225000.0, so 'top 5' admitted any 5 of 19 (11,628 sets); the stated tie-break makes "
           "the reference's 5 (order_ids 1, 18, 32, 80, 214) the unique correct answer. "
           "Reference SQL unchanged.",
    "X08": "v3 (23 Nov 2026): question now states the tie-break the reference SQL already used "
           "(city ascending). Three tie groups on cancellation_rate_pct (20.0, 18.52, 15.38); "
           "previously AMBIGUOUS — the only case where blind and reference order differed — "
           "now uniquely determined. Reference SQL unchanged.",
}


def sha256_file(path):
    d = hashlib.sha256()
    with open(path, "rb") as fh:
        for chunk in iter(lambda: fh.read(1024 * 1024), b""):
            d.update(chunk)
    return d.hexdigest()


def execute_all(cases):
    """Execute every reference SQL read-only; return {id: (columns, rows)}."""
    uri = DB.as_uri() + "?mode=ro"
    out = {}
    with sqlite3.connect(uri, uri=True, timeout=5) as conn:
        conn.execute("PRAGMA query_only = ON")
        for case in cases:
            cur = conn.execute(case["reference_sql"])
            cols = [d[0] for d in cur.description or []]
            rows = [list(r) for r in cur.fetchall()]
            out[case["id"]] = (cols, rows)
    return out


def main():
    v2 = json.loads((BENCH / "expanded_benchmark_v2.json").read_text(encoding="utf-8"))
    assert len(v2) == 90, len(v2)
    v2_by_id = {c["id"]: c for c in v2}
    assert set(CHANGES) <= set(v2_by_id), set(CHANGES) - set(v2_by_id)

    v3 = []
    for case in v2:
        case = dict(case)
        if case["id"] in CHANGES:
            old_q, new_q, tie_sql = CHANGES[case["id"]]
            assert case["question"] == old_q, f"{case['id']}: question text drifted from v2"
            assert tie_sql in case["reference_sql"], (
                f"{case['id']}: reference SQL does not contain expected tie-break {tie_sql!r}"
            )
            case["question"] = new_q
            case["notes"] = NOTE[case["id"]]
        v3.append(case)

    assert len(v3) == 90 and [c["id"] for c in v3] == [c["id"] for c in v2]
    # Reference SQL byte-identical to v2 for all 90 cases.
    assert all(a["reference_sql"] == b["reference_sql"] for a, b in zip(v3, v2))

    # Ground-truth verification by execution.
    res_v2 = execute_all(v2)
    res_v3 = execute_all(v3)
    assert res_v2 == res_v3, "v3 results differ from v2 — reference SQL must be unchanged"
    total_rows = sum(len(rows) for _, rows in res_v3.values())
    print(f"Executed: {len(res_v3)}/90 reference SQL OK; total expected rows: {total_rows}")
    print(f"DB SHA-256: {sha256_file(DB)}")
    for cid in sorted(CHANGES):
        cols, rows = res_v3[cid]
        print(f"  {cid}: {len(rows)} rows, first row {rows[0] if rows else None}")

    (BENCH / "expanded_benchmark_v3.json").write_text(
        json.dumps(v3, indent=2, ensure_ascii=False) + "\n", encoding="utf-8"
    )
    with open(BENCH / "expanded_benchmark_v3.csv", "w", encoding="utf-8", newline="") as fh:
        w = csv.writer(fh)
        w.writerow(["id", "question", "ground_truth_sql", "category", "expected_row_count", "notes"])
        for case in v3:
            w.writerow([
                case["id"],
                case["question"],
                case["reference_sql"],
                case["category"],
                len(res_v3[case["id"]][1]),
                case.get("notes", ""),
            ])
    print("Wrote expanded_benchmark_v3.json/.csv")
    print(f"v3 JSON SHA-256: {sha256_file(BENCH / 'expanded_benchmark_v3.json')}")
    print(f"v2 JSON SHA-256 (unchanged check): {sha256_file(BENCH / 'expanded_benchmark_v2.json')}")


if __name__ == "__main__":
    sys.exit(main())
