# Expanded benchmark v2 — changelog (23 November 2026)

v1 (`expanded_benchmark_v1.json` / `.csv`, 22 Nov 2026) is the benchmark that the
90-question model run (run 1, 22–23 Nov 2026) was executed against. v1 is frozen:
do not edit it, and any repeat run meant to be compared with run 1 must use v1.

v2 changes exactly one case and annotates two others. All other 87 cases,
questions, reference SQL and expected row counts are identical to v1.

## Changed

| Case | v1 | v2 | Why |
| --- | --- | --- | --- |
| X09 | "Find customers who have ordered products from all three product categories." Reference SQL: `HAVING COUNT(DISTINCT p.category) = 3` over all orders. Returns **20 rows — every customer qualifies**, so the case cannot separate a correct query from one that returns every customer for the wrong reason. | "Find customers who have ordered products from all three product categories **in completed orders placed in 2026**." Same relational-division pattern, restricted to `status = 'completed'` and `order_date` in 2026. Returns **9 rows** (customers 4, 7, 8, 9, 11, 15, 17, 18, 20), verified by execution against the seed-42 database. | Proper-subset answer; the division pattern is preserved and now discriminates. |
| X03 | Returns 0 rows (every product appears in `order_items`). | **Unchanged.** Marked `report_separately: true` in the JSON. | Degenerate but valid; an empty-versus-empty comparison can be passed for the wrong reason, so its contribution must be stated separately in any headline figure. |
| X02 | Returns 20 rows, not 36: 16 of 18 cities have one customer, so the `RANK()` tie rule is barely exercised. | **Unchanged**, annotated in the file. | Fixing it properly needs a reshaped database (more customers per city), which would change the ground truth of the other 89 cases. Documented as a limitation in the paper (§7) instead of silently changed. |

## Verification

All 90 v2 ground-truth queries were executed against the seed-42 database with a
read-only runner: 90/90 successful, 0 failures. Total expected rows: 498
(v1: 509; the difference is exactly X09's 20 → 9).

## Comparability warning

Run 1 (v1) and any future v2 run are **not directly comparable** as headline
figures: they differ in one case (X09). Report v1 and v2 accuracies side by side
with the case counts, and report accuracy both with and without X03.
