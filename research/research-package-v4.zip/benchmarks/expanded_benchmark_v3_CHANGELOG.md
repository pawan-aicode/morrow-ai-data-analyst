# Expanded benchmark v3 — changelog (23 November 2026)

v1 (`expanded_benchmark_v1.json` / `.csv`, 22 Nov 2026) and v2
(`expanded_benchmark_v2.json` / `.csv`, 23 Nov 2026) are frozen: do not
edit them. v3 is built from v2 by `research/benchmarks/build_v3.py`
(reproducible — it asserts the v2 question texts and the tie-breaks in the
reference SQL before writing anything).

## What changed

Exactly six question texts changed. **No reference SQL changed, no expected
row changed, no case was removed** — all 90 cases stay. The change fixes the
six AMBIGUOUS cases found by the first blind reference validation
(`research/reference_validation_v1_v2.md`, 23 Nov 2026): in each case the
question stated an order ("highest first", "newest date first") but no
tie-break, while the data contains ties on the sort key, so the reference
SQL's tie order was an unstated choice and an order-sensitive scorer could
mark a correct model answer wrong. Each v3 question now states the
tie-break the v2 reference SQL **already used**, making the reference the
unique correct answer.

| Case | v2 question (ending) | v3 question (ending) | Tie-break now stated (= reference SQL) | Data fact |
| --- | --- | --- | --- | --- |
| J05 | "…newest date first." | "…newest date first, **breaking ties by customer_id ascending**." | `ORDER BY latest_order_date DESC, c.customer_id ASC` | 4 pairs share the same latest order date (2026-10-26, 2026-10-21, 2026-10-13, 2026-09-13) |
| J08 | "…highest quantity first." | "…highest quantity first, **breaking ties by product_id ascending**." | `ORDER BY quantity_sold DESC, p.product_id ASC` | Monitor 27 inch and Office Chair tie at 276 units |
| R07 | "…highest count first." | "…highest count first, **breaking ties alphabetically by city**." | `ORDER BY order_count DESC, c.city ASC` | Bhopal and Goa tie at 31 orders |
| R11 | "…highest first." | "…highest first, **breaking ties alphabetically by product name**." | `ORDER BY quantity_sold DESC, p.product_name ASC` | Monitor 27 inch and Office Chair tie at 276 units (product_id ascending gives the same order) |
| R14 | "…highest value first." | "…highest value first, **breaking ties by order_id ascending**." | `ORDER BY order_value DESC, order_id ASC` | **SEVERE:** 19 completed orders tie at the maximum value 225000.0; "top 5" admitted any 5 of 19 (11,628 sets). The stated tie-break makes the reference's 5 (order_ids 1, 18, 32, 80, 214) uniquely correct |
| X08 | "…highest rate first." | "…highest rate first, **breaking ties alphabetically by city**." | `ORDER BY cancellation_rate_pct DESC, c.city ASC` | 3 tie groups: 20.0 (Chennai, Noida), 18.52 (Mumbai, Gurugram, Chandigarh), 15.38 (Indore, Hyderabad). The only case where the first blind derivation and the reference differed in order |

Every other case — questions, reference SQL, `ordered` flags, `report_separately`
(X03), and the v2 notes on X02 / X03 / X09 — is identical to v2. (v2's X09
replacement and the X02 / X03 annotations carry over unchanged; see
`expanded_benchmark_v2_CHANGELOG.md`.)

## Verification

All 90 v3 ground-truth queries were executed read-only against the seed-42
database (`code/data/sales.db`, SHA-256
`fe81fd8655da44f29c99648a77697e48a289522e7686d252942c9fbfb8408cd2`):
**90/90 successful, 0 failures. Total expected rows: 498** — identical to v2
(498), and every case's result (columns + rows, exact order) is identical to
its v2 result, as required since no reference SQL changed.

- v3 JSON SHA-256: `cd91a4dc52c8fd92f583e9cd10c6d6d62835dcd2888ccf210bd022d621e0bb50`
- v2 JSON SHA-256 (unchanged): `96afdc729a1f7097c2bfb59046cc21660cfa38d52f19f25fb939f20b5dd9140e`
- v1 JSON SHA-256 (unchanged): `8ed0fdae7a6289ed8cd14dfa5624fac2acd6ae48cb6f62cd68b84e4b519218eb`

## Comparability warning

v2 and v3 runs are comparable on values (same reference SQL, same expected
rows) but **not identical as a test**: v3 questions are stricter — a model
answer that returns tied rows in a different order is wrong under v3 and
was defensible under v2. Report v2 and v3 accuracies side by side with the
case counts. In the v2 run 1 (22–23 Nov 2026, qwen3.5:4b-q4_K_M, 77/90),
R07 and X08 were `incorrect_answer` with column match true; their stored
model SQL had no tie-break, so they *may* have been tie-order victims, but
the run files store no actual rows, so this cannot be established
retrospectively — the v3 run settles it prospectively. R14 in v2 run 1 was a
generation failure (ambiguous column), not a tie-order victim. As in v2,
report accuracy both with and without X03 (0-row expected result).
