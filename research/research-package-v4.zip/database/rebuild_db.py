#!/usr/bin/env python3
"""Independent reimplementation of Morrow's deterministic sample-DB spec.

Provenance: written from scratch by the experiments subagent after READING
the documented data-generation spec (seed, status counts, customer/product
lists, completed-product targets, schema) as plain text from the public
repo (README + scripts/create_database.py viewed via raw.githubusercontent).
No repo code was cloned, imported, copied, or executed here, and the flagged
local work/code/ directory was not touched. Stdlib only (random, sqlite3).

Equivalence with the repo-generated DB is NOT assumed: it is checked by
verify_db.py against the spec's own invariants (status counts, per-product
completed order counts + unit totals, row counts, date range).
"""
import random
import sqlite3
from datetime import date, timedelta
from pathlib import Path

OUT = Path(__file__).resolve().parent / "sales_rebuilt.db"

SEED = 42

CUSTOMERS = [
    ("Customer 001", "Delhi"),
    ("Customer 002", "Mumbai"),
    ("Customer 003", "Bengaluru"),
    ("Customer 004", "Pune"),
    ("Customer 005", "Hyderabad"),
    ("Customer 006", "Ahmedabad"),
    ("Customer 007", "Chennai"),
    ("Customer 008", "Kochi"),
    ("Customer 009", "Jaipur"),
    ("Customer 010", "Lucknow"),
    ("Customer 011", "Delhi"),
    ("Customer 012", "Kolkata"),
    ("Customer 013", "Chandigarh"),
    ("Customer 014", "Indore"),
    ("Customer 015", "Bhopal"),
    ("Customer 016", "Mumbai"),
    ("Customer 017", "Noida"),
    ("Customer 018", "Goa"),
    ("Customer 019", "Gurugram"),
    ("Customer 020", "Coimbatore"),
]

PRODUCTS = [
    ("Laptop Pro", "Electronics", 75000.0),
    ("Wireless Mouse", "Accessories", 1200.0),
    ("Mechanical Keyboard", "Accessories", 4500.0),
    ("Monitor 27 inch", "Electronics", 22000.0),
    ("USB-C Hub", "Accessories", 2800.0),
    ("Office Chair", "Furniture", 12500.0),
    ("Standing Desk", "Furniture", 28000.0),
    ("Webcam HD", "Electronics", 5500.0),
    ("Headphones", "Electronics", 8500.0),
    ("Laptop Stand", "Accessories", 1800.0),
]

STATUS_COUNTS = {
    "cancelled": 102,
    "completed": 235,
    "processing": 85,
    "shipped": 78,
}

# product_id -> (completed-order count, total units in completed orders)
COMPLETED_PRODUCT_TARGETS = {
    1: (50, 119),
    7: (45, 115),
    4: (45, 141),
    6: (35, 120),
    9: (30, 87),
    2: (20, 40),
    3: (10, 20),
}

SCHEMA_DDL = """
CREATE TABLE customers (
    customer_id INTEGER PRIMARY KEY,
    name TEXT NOT NULL,
    city TEXT NOT NULL
);
CREATE TABLE products (
    product_id INTEGER PRIMARY KEY,
    product_name TEXT NOT NULL,
    category TEXT NOT NULL,
    unit_price REAL NOT NULL CHECK (unit_price >= 0)
);
CREATE TABLE orders (
    order_id INTEGER PRIMARY KEY,
    customer_id INTEGER NOT NULL,
    order_date TEXT NOT NULL,
    status TEXT NOT NULL CHECK (
        status IN ('completed', 'shipped', 'processing', 'cancelled')
    ),
    FOREIGN KEY (customer_id) REFERENCES customers(customer_id)
);
CREATE TABLE order_items (
    order_item_id INTEGER PRIMARY KEY,
    order_id INTEGER NOT NULL,
    product_id INTEGER NOT NULL,
    quantity INTEGER NOT NULL CHECK (quantity > 0),
    unit_price REAL NOT NULL CHECK (unit_price >= 0),
    FOREIGN KEY (order_id) REFERENCES orders(order_id),
    FOREIGN KEY (product_id) REFERENCES products(product_id)
);
CREATE INDEX idx_orders_date ON orders(order_date);
CREATE INDEX idx_orders_customer ON orders(customer_id);
CREATE INDEX idx_order_items_order ON order_items(order_id);
CREATE INDEX idx_order_items_product ON order_items(product_id);
"""


def main():
    rng = random.Random(SEED)

    statuses = [
        status for status, count in STATUS_COUNTS.items() for _ in range(count)
    ]
    rng.shuffle(statuses)

    start = date(2025, 1, 1)
    orders = []
    for order_id, status in enumerate(statuses, 1):
        customer_id = rng.randint(1, len(CUSTOMERS))
        order_date = (start + timedelta(days=rng.randint(0, 663))).isoformat()
        orders.append((order_id, customer_id, order_date, status))

    completed_ids = [oid for oid, _, _, st in orders if st == "completed"]
    available = list(completed_ids)
    rng.shuffle(available)

    items = []  # (order_id, product_id, quantity)
    for product_id, (order_count, total_units) in COMPLETED_PRODUCT_TARGETS.items():
        selected = available[:order_count]
        available = available[order_count:]
        quantities = [total_units // order_count] * order_count
        for index in rng.sample(range(order_count), total_units % order_count):
            quantities[index] += 1
        items.extend(
            (order_id, product_id, qty)
            for order_id, qty in zip(selected, quantities)
        )

    for order_id in available:  # remaining completed orders (spec: none)
        items.append((order_id, rng.choice((2, 3)), rng.randint(1, 2)))

    for order_id, _, _, status in orders:
        if status == "completed":
            continue
        for _ in range(rng.randint(1, 4)):
            items.append(
                (order_id, rng.randint(1, len(PRODUCTS)), rng.randint(1, 3))
            )

    price_by_id = {i: price for i, (_, _, price) in enumerate(PRODUCTS, 1)}

    if OUT.exists():
        OUT.unlink()
    with sqlite3.connect(OUT) as conn:
        conn.execute("PRAGMA foreign_keys = ON")
        conn.executescript(SCHEMA_DDL)
        conn.executemany(
            "INSERT INTO customers(customer_id, name, city) VALUES (?, ?, ?)",
            ((i, name, city) for i, (name, city) in enumerate(CUSTOMERS, 1)),
        )
        conn.executemany(
            "INSERT INTO products(product_id, product_name, category, unit_price)"
            " VALUES (?, ?, ?, ?)",
            (
                (i, name, category, price)
                for i, (name, category, price) in enumerate(PRODUCTS, 1)
            ),
        )
        conn.executemany(
            "INSERT INTO orders(order_id, customer_id, order_date, status)"
            " VALUES (?, ?, ?, ?)",
            orders,
        )
        conn.executemany(
            "INSERT INTO order_items(order_id, product_id, quantity, unit_price)"
            " VALUES (?, ?, ?, ?)",
            [
                (oid, pid, qty, price_by_id[pid])
                for oid, pid, qty in items
            ],
        )
        conn.commit()

    print(f"Database created: {OUT}")
    print(f"Customers: {len(CUSTOMERS)}")
    print(f"Products: {len(PRODUCTS)}")
    print(f"Orders: {len(orders)}")
    print(f"Order items: {len(items)}")


if __name__ == "__main__":
    main()
