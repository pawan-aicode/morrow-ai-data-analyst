#!/usr/bin/env python3
"""Verify the rebuilt DB against the documented spec invariants.

Stdlib only. Read-only connection. Every check prints PASS/FAIL with the
actual value, so the log is the evidence. Exit code 0 only if all pass.
"""
import sqlite3
import sys
from pathlib import Path

DB = Path(__file__).resolve().parent / "sales_rebuilt.db"

STATUS_COUNTS = {"cancelled": 102, "completed": 235, "processing": 85, "shipped": 78}
COMPLETED_PRODUCT_TARGETS = {
    1: (50, 119),
    7: (45, 115),
    4: (45, 141),
    6: (35, 120),
    9: (30, 87),
    2: (20, 40),
    3: (10, 20),
}

failures = []


def check(name, actual, expected):
    ok = actual == expected
    print(f"{'PASS' if ok else 'FAIL'} | {name} | actual={actual} | expected={expected}")
    if not ok:
        failures.append(name)


def main():
    uri = DB.as_uri() + "?mode=ro"
    with sqlite3.connect(uri, uri=True) as conn:
        conn.execute("PRAGMA query_only = ON")
        check("customers", conn.execute("SELECT COUNT(*) FROM customers").fetchone()[0], 20)
        check("products", conn.execute("SELECT COUNT(*) FROM products").fetchone()[0], 10)
        check("orders", conn.execute("SELECT COUNT(*) FROM orders").fetchone()[0], 500)
        n_items = conn.execute("SELECT COUNT(*) FROM order_items").fetchone()[0]
        print(f"INFO | order_items | count={n_items} (no fixed spec value; recorded)")
        for status, expected in sorted(STATUS_COUNTS.items()):
            actual = conn.execute(
                "SELECT COUNT(*) FROM orders WHERE status = ?", (status,)
            ).fetchone()[0]
            check(f"orders status={status}", actual, expected)
        for pid, (exp_orders, exp_units) in sorted(COMPLETED_PRODUCT_TARGETS.items()):
            row = conn.execute(
                """SELECT COUNT(DISTINCT oi.order_id), SUM(oi.quantity)
                   FROM order_items oi JOIN orders o ON o.order_id = oi.order_id
                   WHERE o.status = 'completed' AND oi.product_id = ?""",
                (pid,),
            ).fetchone()
            check(f"completed product_id={pid} distinct_orders", row[0], exp_orders)
            check(f"completed product_id={pid} total_units", row[1], exp_units)
        # Every completed order has exactly one item (targets cover all 235).
        row = conn.execute(
            """SELECT COUNT(*) FROM (
                   SELECT oi.order_id FROM order_items oi
                   JOIN orders o ON o.order_id = oi.order_id
                   WHERE o.status = 'completed'
                   GROUP BY oi.order_id HAVING COUNT(*) != 1
               )"""
        ).fetchone()[0]
        check("completed orders with != 1 item", row, 0)
        # Every order has at least one item.
        row = conn.execute(
            "SELECT COUNT(*) FROM orders o WHERE NOT EXISTS "
            "(SELECT 1 FROM order_items oi WHERE oi.order_id = o.order_id)"
        ).fetchone()[0]
        check("orders with zero items", row, 0)
        # Date range implied by start 2025-01-01 + 0..663 days.
        row = conn.execute("SELECT MIN(order_date), MAX(order_date) FROM orders").fetchone()
        check("min order_date", row[0], "2025-01-01")
        print(f"INFO | max order_date | value={row[1]} (must be <= 2026-10-26)")
        if row[1] > "2026-10-26":
            failures.append("max order_date")
        # FK integrity.
        fk = conn.execute("PRAGMA foreign_key_check").fetchall()
        check("foreign_key_check violations", len(fk), 0)
        # Distinct cities / categories (documented data facts).
        row = conn.execute("SELECT COUNT(DISTINCT city) FROM customers").fetchone()[0]
        print(f"INFO | distinct customer cities | value={row}")
        row = conn.execute("SELECT COUNT(DISTINCT category) FROM products").fetchone()[0]
        check("distinct product categories", row, 3)
        # Products never in a completed order (targets exclude 5, 8, 10).
        row = conn.execute(
            """SELECT p.product_id FROM products p WHERE NOT EXISTS (
                   SELECT 1 FROM order_items oi JOIN orders o
                   ON o.order_id = oi.order_id
                   WHERE oi.product_id = p.product_id AND o.status = 'completed'
               ) ORDER BY p.product_id"""
        ).fetchall()
        check("products never in completed order", [r[0] for r in row], [5, 8, 10])
        # Products never in any order item (X03 reference answer).
        row = conn.execute(
            """SELECT p.product_id FROM products p WHERE NOT EXISTS (
                   SELECT 1 FROM order_items oi WHERE oi.product_id = p.product_id
               ) ORDER BY p.product_id"""
        ).fetchall()
        print(f"INFO | products never in any order_item | value={[r[0] for r in row]}")
        # Customers with no orders.
        row = conn.execute(
            """SELECT c.customer_id FROM customers c WHERE NOT EXISTS (
                   SELECT 1 FROM orders o WHERE o.customer_id = c.customer_id
               ) ORDER BY c.customer_id"""
        ).fetchall()
        print(f"INFO | customers with zero orders | value={[r[0] for r in row]}")

    print(f"\nVerification: {len(failures)} failures: {failures}")
    sys.exit(1 if failures else 0)


if __name__ == "__main__":
    main()
