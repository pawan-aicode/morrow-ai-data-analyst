#!/usr/bin/env python3
"""Execute every expanded-benchmark ground-truth SQL against the rebuilt DB.

Stdlib only. Read-only connection (URI mode=ro + PRAGMA query_only).
Inputs: benchmark_original30.json + benchmark_new60.json (authored here).
Outputs: research/benchmarks/expanded_benchmark_v1.csv (spec columns),
research/benchmarks/expanded_benchmark_v1.json (repo-harness-compatible),
and a full per-case log on stdout (columns, row count, first row).
Exit code 0 only if every case executes and returns <= 200 rows.
"""
import csv
import json
import re
import sqlite3
import sys
from collections import Counter
from pathlib import Path

HERE = Path(__file__).resolve().parent
DB = HERE / "sales_rebuilt.db"
OUT_DIR = HERE.parent / "research" / "benchmarks"
CSV_OUT = OUT_DIR / "expanded_benchmark_v1.csv"
JSON_OUT = OUT_DIR / "expanded_benchmark_v1.json"


def load(name):
    with (HERE / name).open(encoding="utf-8") as f:
        return json.load(f)


def main():
    cases = load("benchmark_original30.json") + load("benchmark_new60.json")
    ids = [c["id"] for c in cases]
    assert len(ids) == len(set(ids)), "duplicate case ids"
    assert len(cases) == 90, f"expected 90 cases, got {len(cases)}"
    counts = Counter(c["category"] for c in cases)
    print(f"Cases: {len(cases)} | per category: {dict(sorted(counts.items()))}")

    uri = DB.as_uri() + "?mode=ro"
    failures = []
    rows_out = []
    with sqlite3.connect(uri, uri=True) as conn:
        conn.execute("PRAGMA query_only = ON")
        for case in cases:
            sql = case["ground_truth_sql"].strip()
            assert re.match(r"^(SELECT|WITH)\b", sql, re.I), case["id"]
            assert ";" not in sql, case["id"]
            try:
                cur = conn.execute(sql)
                columns = [d[0] for d in cur.description or []]
                rows = cur.fetchall()
            except sqlite3.Error as exc:
                print(f"FAIL | {case['id']} | {case['category']} | SQL error: {exc}")
                failures.append(case["id"])
                continue
            if len(rows) > 200:
                print(f"FAIL | {case['id']} | rows={len(rows)} exceeds repo MAX_ROWS=200")
                failures.append(case["id"])
            first = rows[0] if rows else None
            print(
                f"OK   | {case['id']} | {case['category']:<11} | "
                f"rows={len(rows):>3} | cols={columns} | first={first}"
            )
            notes = case["source"]
            if len(rows) == 0:
                notes += " | expected_row_count=0 (empty result, verified by execution)"
            rows_out.append(
                {
                    "id": case["id"],
                    "question": case["question"],
                    "ground_truth_sql": sql,
                    "category": case["category"],
                    "expected_row_count": len(rows),
                    "notes": notes,
                }
            )

    OUT_DIR.mkdir(parents=True, exist_ok=True)
    with CSV_OUT.open("w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(
            f,
            fieldnames=[
                "id",
                "question",
                "ground_truth_sql",
                "category",
                "expected_row_count",
                "notes",
            ],
        )
        writer.writeheader()
        writer.writerows(rows_out)

    harness = [
        {
            "id": c["id"],
            "category": c["category"],
            "name": c["name"],
            "question": c["question"],
            "reference_sql": c["ground_truth_sql"],
            "ordered": c["ordered"],
        }
        for c in cases
    ]
    with JSON_OUT.open("w", encoding="utf-8") as f:
        json.dump(harness, f, indent=2, ensure_ascii=False)

    print(f"\nWrote {CSV_OUT} ({len(rows_out)} rows)")
    print(f"Wrote {JSON_OUT} ({len(harness)} cases)")
    print(f"Failures: {failures}")
    sys.exit(1 if failures else 0)


if __name__ == "__main__":
    main()
